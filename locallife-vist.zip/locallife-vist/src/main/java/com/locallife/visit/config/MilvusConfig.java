package com.locallife.visit.config;

import com.locallife.visit.support.BizException;
import io.milvus.v2.client.ConnectConfig;
import io.milvus.v2.client.MilvusClientV2;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Configuration
@EnableConfigurationProperties(MilvusProperties.class)
public class MilvusConfig {
    @Bean
    @Lazy
    @ConditionalOnProperty(prefix = "visit.milvus", name = "enabled", havingValue = "true")
    public MilvusClientV2 milvusClient(MilvusProperties properties) {
        if (blank(properties.getUri())) throw new BizException("MILVUS_URI_REQUIRED", "启用 Milvus 时必须配置 MILVUS_URI");
        if (blank(properties.getUsername()) || blank(properties.getPassword()))
            throw new BizException("MILVUS_CREDENTIALS_REQUIRED", "启用 Milvus 时必须配置用户名和密码");
        ConnectConfig config = ConnectConfig.builder()
                .uri(properties.getUri())
                .username(properties.getUsername())
                .password(properties.getPassword())
                .dbName(properties.getDatabase())
                .connectTimeoutMs(properties.getConnectTimeoutMs())
                .rpcDeadlineMs(properties.getRpcDeadlineMs())
                .build();
        return new MilvusClientV2(config);
    }

    private static boolean blank(String value) { return value == null || value.trim().isEmpty(); }
}
