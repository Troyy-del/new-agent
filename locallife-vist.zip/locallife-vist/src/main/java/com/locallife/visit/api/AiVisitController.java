package com.locallife.visit.api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.domain.*;
import com.locallife.visit.service.SessionService;
import com.locallife.visit.service.VisitContractService;
import com.locallife.visit.service.VisitService;
import com.locallife.visit.support.ApiResponse;
import com.locallife.visit.support.BizException;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.annotation.Resources;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

@RestController
@RequestMapping({"/rest/apicenter/crm/web", "/rest/apicenter/visit/web"})
public class AiVisitController {
    private final SessionService sessions;
    private final VisitService visits;
    private final VisitContractService contracts;
    private final ObjectMapper json;

    public AiVisitController(SessionService sessions, VisitService visits, VisitContractService contracts, ObjectMapper json) {
        this.sessions = sessions;
        this.visits = visits;
        this.contracts = contracts;
        this.json = json;
    }

    @PostMapping("/visitCenter/getAiVisitState")
    public Map<String, Object> state(@RequestBody Map<String, Object> body, @RequestHeader(value = "X-User-Id", required = false) String headerUser) {
        BizSession s = load(body, headerUser);
        if (s.activeSkill == ActiveSkill.UPDATE && s.planId != null && s.slots.isEmpty())
            sessions.initializeSlots(s, visits.slotsFromPlan(s.planId, s.userId));
        return ApiResponse.ok(stateData(s));
    }

    @PostMapping("/visitCenter/batchResolveAiVisitSlot")
    public Map<String, Object> resolve(@RequestBody Map<String, Object> body, @RequestHeader(value = "X-User-Id", required = false) String headerUser) {
        BizSession s = load(body, headerUser);
        List<Map<String, Object>> items = items(body.get("items"));
        if (items.isEmpty() && body.get("slots") instanceof Map) {
            items = new ArrayList<>();
            for (Map.Entry<?, ?> e : ((Map<?, ?>) body.get("slots")).entrySet()) {
                Map<String, Object> i = new LinkedHashMap<>();
                i.put("slotName", String.valueOf(e.getKey()));
                i.put("raw", e.getValue());
                items.add(i);
            }
        }
        sessions.resolve(s, items, !Boolean.FALSE.equals(body.get("autoPatch")));
        return ApiResponse.ok(stateData(s));
    }

    @PostMapping("/visitCenter/queryAiVisit")
    public Map<String, Object> query(@RequestBody Map<String, Object> body, @RequestHeader(value = "X-User-Id", required = false) String headerUser) {
        String user = user(body, headerUser);
        String type = str(body, "queryType", "query_type");
        Object param = body.containsKey("param") ? body.get("param") : body.get("params");
        int limit = integer(body.get("limit"), 20);
        if ("pending_travel".equals(type) || "pending_travel_plan".equals(type))
            return ApiResponse.ok(contracts.pendingTravel(user, param, limit));
        return ApiResponse.ok(visits.query(user, type, param, limit));
    }

    @PostMapping("/visitCenter/executeAiVisitAction")
    public Map<String, Object> execute(@RequestBody Map<String, Object> body, @RequestHeader(value = "X-User-Id", required = false) String headerUser) {
        BizSession s = load(body, headerUser);
        if (s.activeSkill == ActiveSkill.UPDATE && s.planId != null && s.slots.isEmpty())
            sessions.initializeSlots(s, visits.slotsFromPlan(s.planId, s.userId));
        if (s.fsmState == FsmState.CONFIRMING) sessions.confirm(s);
        Map<String, Object> params = params(body);
        String action = str(body, "action", "actionName");
        if (action == null) action = action(s.activeSkill);
        Object data = visits.execute(s, str(body, "turnId", "clientActionId"), action, params);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("status", "done");
        result.put("planId", s.planId);
        result.put("result", data);
        return ApiResponse.ok(result);
    }

    @PostMapping("/visitCenter/createVisitPlanV")
    public Map<String, Object> create(@RequestBody Map<String, Object> body, @RequestHeader(value = "X-User-Id", required = false) String headerUser) {
        VisitPlan p = visits.directCreate(user(body, headerUser), legacySlots(body));
        return ApiResponse.ok(planData(p));
    }

    @PostMapping("/visitCenter/updateVisitPlan")
    public Map<String, Object> update(@RequestBody Map<String, Object> body, @RequestHeader(value = "X-User-Id", required = false) String headerUser) {
        long id = longVal(first(body, "visitPlanIdStr", "visitPlanId", "planId", "id"));
        VisitPlan p = visits.directUpdate(user(body, headerUser), id, legacySlots(body));
        return ApiResponse.ok(planData(p));
    }

    @PostMapping("/visitCenter/searchCustomerV")
    public Map<String, Object> customers(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(Collections.singletonMap("list", visits.searchCustomers(str(body, "keyword", "query"), str(body, "objectType", "visitObjectType"), integer(body.get("limit"), 10))));
    }

    @PostMapping("/visitCenter/listTravelApplyV")
    public Map<String, Object> travel(@RequestBody(required = false) Map<String, Object> body,
                                      @RequestHeader(value = "X-User-Id", required = false) String headerUser) {
        if (body == null) body = Collections.emptyMap();
        List<Map<String, Object>> list = contracts.travelApplications(user(body, headerUser));
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("total", list.size()); result.put("tips", list.isEmpty() ? "暂无已审批差旅申请" : ""); result.put("list", list);
        return ApiResponse.ok(result);
    }

    @PostMapping("/visitCenter/searchAccompanyUserV")
    public Map<String, Object> companions(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(Collections.singletonMap("list", contracts.employees(str(body, "keyword"), integer(body.get("limit"), 30))));
    }

    @PostMapping("/visitNew/queryVisitPlanDetails")
    public Map<String, Object> detail(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(contracts.detail(longVal(first(body, "id", "visitPlanId"))));
    }

    @PostMapping("/visitNew/queryVisitPlanList")
    public Map<String, Object> list(@RequestBody Map<String, Object> body, @RequestHeader(value = "X-User-Id", required = false) String headerUser) {
        String user = user(body, headerUser);
        return ApiResponse.ok(contracts.list(user, body));
    }

    private BizSession load(Map<String, Object> b, String h) {
        String chat = str(b, "chatId", "chat_id");
        ActiveSkill skill = ActiveSkill.parse(first(b, "activeSkill", "active_skill"));
        Long plan = nullableLong(first(b, "planId", "visitPlanId", "visit_plan_id"));
        Long created = nullableLong(first(b, "sessionCreatedAt", "session_created_at"));
        return sessions.load(chat, user(b, h), skill, plan, created);
    }

    private Map<String, Object> stateData(BizSession s) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("sessionKey", s.sessionKey);
        m.put("chatId", s.chatId);
        m.put("activeSkill", s.activeSkill == null ? null : s.activeSkill.name().toLowerCase(Locale.ROOT));
        m.put("fsmState", s.fsmState);
        m.put("planId", s.planId);
        m.put("slots", s.slots);
        m.put("waitingFor", s.waitingFor);
        m.put("ambiguous", s.ambiguous);
        m.put("askRound", s.askRound);
        m.put("lastProgress", s.lastProgress);
        m.put("expiresAt", s.expiresAt);
        return m;
    }

    private Map<String, Object> planData(VisitPlan p) {
        Map<String, Object> m = json.convertValue(p, new TypeReference<Map<String, Object>>() {
        });
        m.put("visitPlanId", String.valueOf(p.id));
        m.put("visitId", String.valueOf(p.id));
        m.put("visitType", p.visitForm);
        m.put("visitObjectType", p.objectType);
        m.put("visitObjectName", p.customerName);
        m.put("planVisitTime", p.planTime == null ? null : p.planTime.toEpochMilli());
        m.put("planVisitAddress", p.planAddress);
        m.put("checkinStatus", p.status == PlanStatus.CHECKED_IN ? "1" : p.status == PlanStatus.CHECKED_OUT || p.status == PlanStatus.LOGGED ? "2" : "0");
        return m;
    }

    private Map<String, Object> legacySlots(Map<String, Object> b) {
        Map<String, Object> s = new LinkedHashMap<>();
        Object visitForm = first(b, "visitForm", "visitType");
        if (visitForm != null) s.put("visitForm", normalizeVisitForm(visitForm));
        Object objectType = first(b, "objectType", "visitObjectType", "visitObject");
        if (objectType != null) s.put("objectType", objectType);
        Object info = first(b, "customer", "visitObjectInfo");
        if (info instanceof Map) {
            Map<String, Object> c = new LinkedHashMap<>((Map<String, Object>) info);
            if (c.get("id") == null) c.put("id", first(c, "licenseId", "licenseCode", "businessLicenseCode", "storePoiId", "agentId", "providerId"));
            if (c.get("name") == null)
                c.put("name", first(c, "licenseName", "storePoiName", "agentName", "providerName"));
            s.put("customer", c);
            Object ct = first(c, "customerType", "customer_type");
            if (ct != null) s.put("customerType", ct);
        } else if (info != null) {
            s.put("customer", info);
        }
        Object ct = first(b, "customerType", "customer_type");
        if (ct != null) s.put("customerType", ct);
        Object target = first(b, "adIsTarget", "isTargetCustomer");
        if (target != null) s.put("adIsTarget", target);
        Object purposeCode = first(b, "purposeCode", "visitPurpose");
        if (purposeCode != null) {
            Map<String, Object> purpose = new LinkedHashMap<>();
            purpose.put("code", String.valueOf(purposeCode));
            purpose.put("label", String.valueOf(purposeCode));
            s.put("purpose", purpose);
        }
        Object planTime = first(b, "planTime", "planVisitTime");
        if (planTime != null) s.put("planTime", parseLegacyTime(planTime));
        Object planAddress = first(b, "planAddress", "planVisitAddress");
        if (planAddress != null || b.get("longitude") != null || b.get("planVisitLongitude") != null) {
            Map<String, Object> a = planAddress instanceof Map
                    ? new LinkedHashMap<>((Map<String, Object>) planAddress) : new LinkedHashMap<>();
            if (a.get("text") == null) a.put("text", planAddress instanceof Map ? first(a, "address", "name") : planAddress);
            if (a.get("longitude") == null) a.put("longitude", first(b, "longitude", "planVisitLongitude"));
            if (a.get("latitude") == null) a.put("latitude", first(b, "latitude", "planVisitLatitude"));
            s.put("planAddress", a);
        }
        if (b.containsKey("companions")) s.put("companions", b.get("companions"));
        Object travel = first(b, "travelApplyId", "travelApplyNo");
        if (travel != null) s.put("travelApplyId", travel);
        return s;
    }

    private static Object parseLegacyTime(Object v) {
        if (v instanceof Number) return Instant.ofEpochMilli(((Number) v).longValue());
        String x = String.valueOf(v);
        try {
            return Instant.parse(x);
        } catch (Exception ignore) {
        }
        return LocalDateTime.parse(x, DateTimeFormatter.ofPattern(x.length() == 16 ? "yyyy-MM-dd HH:mm" : "yyyy-MM-dd HH:mm:ss")).atZone(ZoneId.of("Asia/Shanghai")).toInstant();
    }

    private Map<String, Object> params(Map<String, Object> b) {
        Map<String, Object> p = new LinkedHashMap<>();
        if (b.get("params") instanceof Map) p.putAll((Map<String, Object>) b.get("params"));
        Object pj = b.get("paramsJson");
        if (pj != null && !String.valueOf(pj).trim().isEmpty()) try {
            p.putAll(json.readValue(String.valueOf(pj), new TypeReference<Map<String, Object>>() {
            }));
        } catch (Exception e) {
            throw new BizException("INVALID_PARAMS_JSON", "paramsJson 不是合法 JSON");
        }
        p.putAll(b);
        return p;
    }

    private static List<Map<String, Object>> items(Object v) {
        if (!(v instanceof List)) return Collections.emptyList();
        return (List<Map<String, Object>>) v;
    }

    private static String action(ActiveSkill s) {
        if (s == null) throw new BizException("MISSING_ACTIVE_SKILL", "activeSkill 不能为空");
        switch (s) {
            case CREATE:
                return "create";
            case UPDATE:
                return "update";
            case CANCEL:
                return "cancel";
            case CHECKIN:
                return "checkin";
            case CHECKOUT:
                return "checkout";
            case FILL_LOG:
                return "fill_log";
            case RECORD:
                return "start_recording";
            default:
                throw new BizException("UNSUPPORTED_ACTION", "当前流程没有写操作");
        }
    }

    private static String user(Map<String, Object> b, String h) {
        String u = h != null ? h : str(b, "userId", "creatorEmail", "creatorId");
        if (u == null && b.get("baseRequest") instanceof Map) {
            Object nested = first((Map<?, ?>) b.get("baseRequest"), "user_name", "userName", "userId");
            if (nested != null) u = String.valueOf(nested);
        }
        return u == null ? "demo-user" : u;
    }

    private static String normalizeVisitForm(Object v) {
        String x = String.valueOf(v);
        return x.contains("出差") || x.equalsIgnoreCase("travel") || x.equals("2") ? "travel" : "local";
    }

    private static Object first(Map<?, ?> m, String... k) {
        for (String x : k) if (m.get(x) != null) return m.get(x);
        return null;
    }

    private static String str(Map<String, Object> m, String... k) {
        Object v = first(m, k);
        return v == null ? null : String.valueOf(v);
    }

    private static int integer(Object v, int d) {
        try {
            return v == null ? d : Integer.parseInt(String.valueOf(v));
        } catch (Exception e) {
            return d;
        }
    }

    private static long longVal(Object v) {
        if (v == null) throw new BizException("MISSING_ID", "ID 不能为空");
        return Long.parseLong(String.valueOf(v));
    }

    private static Long nullableLong(Object v) {
        return v == null || String.valueOf(v).isEmpty() ? null : longVal(v);
    }
}
