package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.PlanStatus;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.VisitPlanRepository;
import com.locallife.visit.service.VisitContractService;
import com.locallife.visit.support.BizException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

@Component
public class CheckoutVisitHandler implements VisitActionHandler {
    private final VisitPlanRepository plans;
    private final VisitHandlerSupport support;
    private final VisitContractService contracts;

    public CheckoutVisitHandler(VisitPlanRepository plans, VisitHandlerSupport support, VisitContractService contracts) {
        this.plans = plans;
        this.support = support;
        this.contracts = contracts;
    }

    public Set<String> actions() {
        return Collections.singleton("checkout");
    }

    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.CHECKOUT);
        VisitPlan plan = support.detail(support.requiredPlan(session));
        support.owner(plan, session.userId);
        if (plan.status != PlanStatus.CHECKED_IN) throw VisitHandlerSupport.transition("只有已签到未签退的计划可签退");
        Double longitude = VisitHandlerSupport.number(params, "longitude");
        Double latitude = VisitHandlerSupport.number(params, "latitude");
        if (longitude == null) longitude = plan.checkinLongitude;
        if (latitude == null) latitude = plan.checkinLatitude;
        Map<String, Object> request = new java.util.LinkedHashMap<>(params);
        request.put("visitPlanId", plan.id);
        request.put("longitude", longitude);
        request.put("latitude", latitude);
        Map<String, Object> check = contracts.preCheckCheckout(request);
        if (!Boolean.TRUE.equals(check.get("canCheckout")))
            throw new BizException("CHECKOUT_PRECHECK_FAILED", String.valueOf(check.get("abnormalReason")), HttpStatus.CONFLICT);
        plans.markStatus(plan.id, plan.version, PlanStatus.CHECKED_IN, PlanStatus.CHECKED_OUT,
                VisitHandlerSupport.text(params, "address", "currentAddress"), longitude, latitude);
        return support.detail(plan.id);
    }
}
