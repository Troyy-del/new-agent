package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.PlanStatus;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.VisitPlanRepository;
import com.locallife.visit.support.BizException;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

@Component
public class CheckinVisitHandler implements VisitActionHandler {
    private final VisitPlanRepository plans;
    private final VisitHandlerSupport support;

    public CheckinVisitHandler(VisitPlanRepository plans, VisitHandlerSupport support) { this.plans = plans; this.support = support; }
    public Set<String> actions() { return Collections.singleton("checkin"); }
    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.CHECKIN);
        VisitPlan plan = support.detail(support.requiredPlan(session));
        support.owner(plan, session.userId);
        if (plan.status != PlanStatus.PLANNED) throw VisitHandlerSupport.transition("当前计划不可签到");
        VisitHandlerSupport.requireTodayCheckin(plan);
        Double longitude = VisitHandlerSupport.number(params, "longitude");
        Double latitude = VisitHandlerSupport.number(params, "latitude");
        if (longitude == null || latitude == null) throw new BizException("LOCATION_REQUIRED", "签到需要经纬度");
        String abnormalReason = null;
        if (plan.longitude != null && plan.latitude != null
                && VisitHandlerSupport.distance(latitude, longitude, plan.latitude, plan.longitude) > support.checkinRadius()) {
            abnormalReason = VisitHandlerSupport.text(params, "abnormalReason", "checkinAbnormalReason");
            if (abnormalReason == null) abnormalReason = "当前位置超出计划地址" + (int) support.checkinRadius() + "米";
        }
        plans.markCheckin(plan.id, plan.version,
                VisitHandlerSupport.text(params, "address", "currentAddress"), longitude, latitude,
                abnormalReason, VisitHandlerSupport.text(params, "photoUrl", "checkinPhotoUrl"));
        return support.detail(plan.id);
    }
}
