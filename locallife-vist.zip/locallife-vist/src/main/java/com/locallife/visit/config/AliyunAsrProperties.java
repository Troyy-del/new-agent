package com.locallife.visit.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "visit.asr")
public class AliyunAsrProperties {
    private boolean enabled;
    private String appKey;
    private String accessKeyId;
    private String accessKeySecret;
    private String region = "cn-beijing";
    private String filetransDomain = "filetrans.cn-beijing.aliyuncs.com";
    private String tokenDomain = "nls-meta.cn-shanghai.aliyuncs.com";
    private String websocketUrl = "wss://nls-gateway-cn-shanghai.aliyuncs.com/ws/v1";
    private long pollIntervalMs = 2000;
    private long pollTimeoutMs = 600000;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getAppKey() { return appKey; }
    public void setAppKey(String appKey) { this.appKey = appKey; }
    public String getAccessKeyId() { return accessKeyId; }
    public void setAccessKeyId(String accessKeyId) { this.accessKeyId = accessKeyId; }
    public String getAccessKeySecret() { return accessKeySecret; }
    public void setAccessKeySecret(String accessKeySecret) { this.accessKeySecret = accessKeySecret; }
    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }
    public String getFiletransDomain() { return filetransDomain; }
    public void setFiletransDomain(String filetransDomain) { this.filetransDomain = filetransDomain; }
    public String getTokenDomain() { return tokenDomain; }
    public void setTokenDomain(String tokenDomain) { this.tokenDomain = tokenDomain; }
    public String getWebsocketUrl() { return websocketUrl; }
    public void setWebsocketUrl(String websocketUrl) { this.websocketUrl = websocketUrl; }
    public long getPollIntervalMs() { return pollIntervalMs; }
    public void setPollIntervalMs(long pollIntervalMs) { this.pollIntervalMs = pollIntervalMs; }
    public long getPollTimeoutMs() { return pollTimeoutMs; }
    public void setPollTimeoutMs(long pollTimeoutMs) { this.pollTimeoutMs = pollTimeoutMs; }
}
