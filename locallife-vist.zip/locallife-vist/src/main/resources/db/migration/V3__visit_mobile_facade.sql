ALTER TABLE visit_plan
    ADD COLUMN ad_is_target BOOLEAN NULL AFTER customer_type;

CREATE TABLE visit_conversation (
    id VARCHAR(64) NOT NULL PRIMARY KEY,
    owner_id VARCHAR(128) NOT NULL,
    title VARCHAR(256) NOT NULL,
    active_session_key VARCHAR(256),
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    KEY idx_visit_conversation_owner_time (owner_id, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE visit_conversation_message (
    id VARCHAR(64) NOT NULL PRIMARY KEY,
    conversation_id VARCHAR(64) NOT NULL,
    role VARCHAR(16) NOT NULL,
    content TEXT NOT NULL,
    card_json JSON,
    session_key VARCHAR(256),
    created_at DATETIME(6) NOT NULL,
    KEY idx_visit_message_conversation_time (conversation_id, created_at),
    CONSTRAINT fk_visit_message_conversation FOREIGN KEY (conversation_id)
        REFERENCES visit_conversation(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
