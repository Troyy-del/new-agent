package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.VisitPlanRepository;
import com.locallife.visit.service.ReviewAccessService;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

@Component
public class ApproveReviewHandler implements VisitActionHandler {
    private final VisitPlanRepository plans; private final VisitHandlerSupport support; private final ReviewAccessService access;
    public ApproveReviewHandler(VisitPlanRepository plans, VisitHandlerSupport support, ReviewAccessService access) { this.plans=plans; this.support=support; this.access=access; }
    public Set<String> actions() { return Collections.singleton("approve_review"); }
    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.REVIEW); access.requireReviewer(session.userId);
        VisitPlan plan=support.detail(support.requiredPlan(session));
        plans.approveReview(plan.id, plan.version, session.userId, VisitHandlerSupport.text(params,"comment","reviewComment"));
        return support.detail(plan.id);
    }
}
