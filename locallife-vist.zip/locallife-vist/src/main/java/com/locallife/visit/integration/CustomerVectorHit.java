package com.locallife.visit.integration;

public class CustomerVectorHit {
    public String customerId;
    public String objectType;
    public String standardName;
    public String address;
    public String city;
    public float score;
}
