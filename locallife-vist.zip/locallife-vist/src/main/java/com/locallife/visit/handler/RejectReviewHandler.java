package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.VisitPlanRepository;
import com.locallife.visit.service.ReviewAccessService;
import com.locallife.visit.support.BizException;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

@Component
public class RejectReviewHandler implements VisitActionHandler {
    private final VisitPlanRepository plans; private final VisitHandlerSupport support; private final ReviewAccessService access;
    public RejectReviewHandler(VisitPlanRepository plans, VisitHandlerSupport support, ReviewAccessService access) { this.plans=plans; this.support=support; this.access=access; }
    public Set<String> actions() { return Collections.singleton("reject_review"); }
    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.REVIEW); access.requireReviewer(session.userId);
        String comment=VisitHandlerSupport.text(params,"comment","reviewComment");
        if(comment==null) throw new BizException("REVIEW_COMMENT_REQUIRED","驳回时必须填写审核意见");
        VisitPlan plan=support.detail(support.requiredPlan(session)); plans.rejectReview(plan.id,plan.version,session.userId,comment);
        return support.detail(plan.id);
    }
}
