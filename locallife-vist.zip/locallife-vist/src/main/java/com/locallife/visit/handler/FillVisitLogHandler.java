package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.service.VisitContractService;
import com.locallife.visit.support.BizException;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

@Component
public class FillVisitLogHandler implements VisitActionHandler {
    private final VisitHandlerSupport support;
    private final VisitContractService contracts;

    public FillVisitLogHandler(VisitHandlerSupport support, VisitContractService contracts) { this.support = support; this.contracts = contracts; }
    public Set<String> actions() { return new LinkedHashSet<>(Arrays.asList("fill_log", "submit_log", "edit_log")); }
    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.FILL_LOG);
        VisitPlan plan = support.detail(support.requiredPlan(session));
        support.owner(plan, session.userId);
        Map<String, Object> request = new java.util.LinkedHashMap<>(params);
        request.put("visitId", plan.id);
        contracts.fillLog(request);
        return support.detail(plan.id);
    }
}
