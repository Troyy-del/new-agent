package com.locallife.visit.integration;

import org.springframework.stereotype.Component;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

@Component
@ConditionalOnProperty(prefix = "visit.asr", name = "enabled", havingValue = "false", matchIfMissing = true)
public class DisabledAsrGateway implements AsrGateway {
    @Override public String transcribe(String audioUrl) { return null; }
}
