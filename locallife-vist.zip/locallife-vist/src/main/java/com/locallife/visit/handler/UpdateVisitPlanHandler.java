package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.PlanStatus;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.VisitPlanRepository;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

@Component
public class UpdateVisitPlanHandler implements VisitActionHandler {
    private final VisitPlanRepository plans;
    private final VisitHandlerSupport support;

    public UpdateVisitPlanHandler(VisitPlanRepository plans, VisitHandlerSupport support) { this.plans = plans; this.support = support; }
    public Set<String> actions() { return new LinkedHashSet<>(Arrays.asList("update", "update_plan")); }
    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.UPDATE);
        VisitPlan current = support.detail(support.requiredPlan(session));
        support.owner(current, session.userId);
        if (current.status != PlanStatus.PLANNED && current.status != PlanStatus.PENDING_SUPPLEMENT)
            throw VisitHandlerSupport.transition("只有待拜访或待补充计划可修改");
        VisitPlan updated = support.fromSlots(session, current);
        plans.updatePlan(updated);
        return updated;
    }
}
