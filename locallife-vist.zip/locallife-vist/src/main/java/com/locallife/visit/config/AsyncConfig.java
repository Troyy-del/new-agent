package com.locallife.visit.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
public class AsyncConfig {
    @Bean(name="applicationTaskExecutor")
    public Executor applicationTaskExecutor(){
        ThreadPoolTaskExecutor executor=new ThreadPoolTaskExecutor(); executor.setCorePoolSize(2); executor.setMaxPoolSize(8);
        executor.setQueueCapacity(200); executor.setThreadNamePrefix("visit-async-"); executor.initialize(); return executor;
    }
}
