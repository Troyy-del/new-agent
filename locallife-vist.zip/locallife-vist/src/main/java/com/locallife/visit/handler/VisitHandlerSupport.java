package com.locallife.visit.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.PlanStatus;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.SupportingRepository;
import com.locallife.visit.repository.VisitPlanRepository;
import com.locallife.visit.support.BizException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Map;

@Component
public class VisitHandlerSupport {
    private static final ZoneId BUSINESS_ZONE = ZoneId.of("Asia/Shanghai");
    private final VisitPlanRepository plans;
    private final ObjectMapper json;
    private final double checkinRadius;

    public VisitHandlerSupport(VisitPlanRepository plans, ObjectMapper json,
                               @Value("${visit.checkin-radius-meters:1000}") double checkinRadius) {
        this.plans = plans;
        this.json = json;
        this.checkinRadius = checkinRadius;
    }

    public VisitPlan detail(long id) {
        return plans.find(id).orElseThrow(() -> new BizException("PLAN_NOT_FOUND", "拜访计划不存在", HttpStatus.NOT_FOUND));
    }

    public long requiredPlan(BizSession session) {
        if (session.planId == null) throw new BizException("PLAN_ID_REQUIRED", "visitPlanId 不能为空");
        return session.planId;
    }

    public void requireSkill(BizSession session, ActiveSkill expected) {
        if (session.activeSkill != expected) throw transition("当前会话不是 " + expected + " 流程");
    }

    public void owner(VisitPlan plan, String user) {
        if (user != null && !user.equals(plan.creatorId)) {
            throw new BizException("FORBIDDEN", "无权操作该拜访计划", HttpStatus.FORBIDDEN);
        }
    }

    public VisitPlan fromSlots(BizSession session, VisitPlan base) {
        Map<String, Object> slots = session.slots;
        VisitPlan plan = base == null ? new VisitPlan() : base;
        plan.id = base == null ? SupportingRepository.newId() : base.id;
        plan.creatorId = base == null ? session.userId : base.creatorId;
        plan.visitForm = required(slots, "visitForm");
        plan.objectType = required(slots, "objectType");
        Map<String, Object> customer = map(slots.get("customer"), "customer");
        plan.customerId = required(customer, "id");
        plan.customerName = required(customer, "name");
        plan.customerType = string(slots.get("customerType"));
        plan.adIsTarget = slots.get("adIsTarget") instanceof Boolean ? (Boolean) slots.get("adIsTarget") : null;
        Map<String, Object> purpose = map(slots.get("purpose"), "purpose");
        plan.purposeCode = required(purpose, "code");
        plan.purposeLabel = required(purpose, "label");
        plan.planTime = instant(slots.get("planTime"));
        Map<String, Object> address = map(slots.get("planAddress"), "planAddress");
        Object addressText = address.containsKey("text") ? address.get("text") : address.get("address");
        if (addressText == null || String.valueOf(addressText).trim().isEmpty()) {
            throw new BizException("MISSING_SLOT", "缺少槽位: planAddress.text");
        }
        plan.planAddress = String.valueOf(addressText);
        plan.longitude = number(address, "longitude", "lng");
        plan.latitude = number(address, "latitude", "lat");
        plan.companionsJson = write(slots.getOrDefault("companions", Collections.emptyList()));
        plan.travelApplyId = string(slots.get("travelApplyId"));
        plan.status = base == null ? PlanStatus.PLANNED : base.status;
        plan.createdAt = base == null ? Instant.now() : base.createdAt;
        plan.updatedAt = Instant.now();
        return plan;
    }

    public double checkinRadius() { return checkinRadius; }

    public static void requireTodayCheckin(VisitPlan plan) {
        LocalDate today = LocalDate.now(BUSINESS_ZONE);
        LocalDate planDate = plan.planTime == null ? null : plan.planTime.atZone(BUSINESS_ZONE).toLocalDate();
        if (!today.equals(planDate)) {
            throw new BizException("CHECKIN_DATE_NOT_TODAY", "只能签到当日的拜访计划", HttpStatus.CONFLICT);
        }
    }

    public String write(Object value) {
        try { return json.writeValueAsString(value); }
        catch (Exception e) { throw new BizException("INVALID_JSON", "JSON 序列化失败"); }
    }

    public static String text(Map<String, Object> values, String... keys) {
        if (values == null) return null;
        for (String key : keys) if (values.get(key) != null) return String.valueOf(values.get(key));
        return null;
    }

    public static Double number(Map<String, Object> values, String... keys) {
        if (values == null) return null;
        for (String key : keys) {
            Object value = values.get(key);
            if (value instanceof Number) return ((Number) value).doubleValue();
            if (value != null) try { return Double.valueOf(String.valueOf(value)); } catch (NumberFormatException ignored) { }
        }
        return null;
    }

    public static long longValue(Object value, String label) {
        if (value == null) throw new BizException("MISSING_ARGUMENT", label + "不能为空");
        try { return Long.parseLong(String.valueOf(value)); }
        catch (NumberFormatException e) { throw new BizException("INVALID_ARGUMENT", label + "格式错误"); }
    }

    public static double distance(double lat1, double lon1, double lat2, double lon2) {
        double radius = 6371000;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2 - lat1), dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * radius * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    public static BizException transition(String message) {
        return new BizException("INVALID_FSM_TRANSITION", message, HttpStatus.CONFLICT);
    }

    private static String required(Map<String, Object> values, String key) {
        Object value = values.get(key);
        if (value == null || String.valueOf(value).trim().isEmpty()) throw new BizException("MISSING_SLOT", "缺少槽位: " + key);
        return String.valueOf(value);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Object value, String label) {
        if (!(value instanceof Map)) throw new BizException("INVALID_SLOT", label + " 槽位必须是对象");
        return (Map<String, Object>) value;
    }

    private static String string(Object value) { return value == null ? null : String.valueOf(value); }

    private static Instant instant(Object value) {
        if (value == null) throw new BizException("MISSING_SLOT", "缺少槽位: planTime");
        if (value instanceof Instant) return (Instant) value;
        if (value instanceof Number) return Instant.ofEpochMilli(((Number) value).longValue());
        try { return Instant.parse(String.valueOf(value)); }
        catch (Exception e) { throw new BizException("INVALID_PLAN_TIME", "计划时间必须是 ISO-8601 时间"); }
    }
}
