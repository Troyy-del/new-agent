package com.locallife.visit.service;

import com.locallife.visit.support.BizException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Service
public class ReviewAccessService {
    private final boolean allReviewers;
    private final Set<String> reviewers;

    public ReviewAccessService(@Value("${visit.security.all-reviewers:false}") boolean allReviewers,
                               @Value("${visit.security.reviewers:demo-manager}") String reviewers) {
        this.allReviewers = allReviewers;
        if (reviewers == null || reviewers.trim().isEmpty()) this.reviewers = Collections.emptySet();
        else this.reviewers = new HashSet<>(Arrays.asList(reviewers.split("\\s*,\\s*")));
    }

    public void requireReviewer(String user) {
        if (!allReviewers && !reviewers.contains(user))
            throw new BizException("REVIEW_FORBIDDEN", "当前用户没有审核权限", HttpStatus.FORBIDDEN);
    }
}
