package com.locallife.visit.domain;

public enum ActiveSkill {
    CREATE, UPDATE, CANCEL, CHECKIN, CHECKOUT, RECORD, FILL_LOG, REVIEW, PENDING;

    public static ActiveSkill parse(Object value) {
        if (value == null || String.valueOf(value).trim().isEmpty()) return null;
        String raw = String.valueOf(value).trim().replace('-', '_').toUpperCase();
        if ("FILLLOG".equals(raw)) raw = "FILL_LOG";
        return valueOf(raw);
    }
}
