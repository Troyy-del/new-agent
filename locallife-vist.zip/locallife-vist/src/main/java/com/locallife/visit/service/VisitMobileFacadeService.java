package com.locallife.visit.service;

import com.locallife.visit.domain.*;
import com.locallife.visit.handler.VisitHandlerSupport;
import com.locallife.visit.repository.*;
import com.locallife.visit.support.BizException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Adapts the feature_amu_visit mobile page contract to the visit domain.
 */
@Service
public class VisitMobileFacadeService {
    private static final ZoneId ZONE = ZoneId.of("Asia/Shanghai");
    private final SessionService sessions;
    private final SessionRepository sessionRepository;
    private final VisitService visits;
    private final VisitPlanRepository plans;
    private final VisitConversationRepository conversations;
    private final SupportingRepository supporting;
    private final CustomerSearchService customerSearch;
    private final VisitContractService contracts;
    private final SlotResolver resolver;

    public VisitMobileFacadeService(SessionService sessions, SessionRepository sessionRepository,
                                    VisitService visits, VisitPlanRepository plans,
                                    VisitConversationRepository conversations, SupportingRepository supporting,
                                    VisitContractService contracts, SlotResolver resolver,
                                    CustomerSearchService customerSearch) {
        this.sessions = sessions;
        this.sessionRepository = sessionRepository;
        this.visits = visits;
        this.plans = plans;
        this.conversations = conversations;
        this.supporting = supporting;
        this.customerSearch = customerSearch;
        this.contracts = contracts;
        this.resolver = resolver;
    }

    public Map<String, Object> bootstrap(String user) {
        List<Map<String, Object>> customers = customerSearch.search("", null, 100);
        List<Map<String, Object>> licenses = new ArrayList<>();
        List<Map<String, Object>> addresses = new ArrayList<>();
        for (Map<String, Object> customer : customers) {
            String id = text(customer.get("id"));
            String name = text(customer.get("name"));
            String type = text(customer.get("objectType"));
            Map<String, Object> license = new LinkedHashMap<>();
            license.put("corporationName", name);
            license.put("licenseNo", id);
            license.put("regCity", customer.get("city"));
            license.put("objectTypes", Collections.singletonList(type));
            if ("agent".equals(type)) {
                license.put("agentId", id);
                license.put("agentName", name);
            }
            if ("provider".equals(type)) {
                license.put("providerId", id);
                license.put("providerName", name);
            }
            license.put("targetCustomers", Collections.emptyList());
            license.put("ksUsers", Collections.emptyList());
            licenses.add(license);

            Map<String, Object> address = new LinkedHashMap<>();
            address.put("poiName", name);
            address.put("address", customer.get("address"));
            address.put("city", customer.get("city"));
            address.put("district", "");
            addresses.add(address);
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("licenses", licenses);
        result.put("purposes", purposeGroups());
        result.put("addresses", addresses);
        result.put("travelApplications", contracts.travelApplications(user));
        return result;
    }

    /**
     * 面向移动端表单的实时客户检索。
     * query 非空时 CustomerSearchService 会生成 embedding 并执行 Milvus COSINE Search；
     * query 为空时返回 active 客户列表，便于用户点开下拉框后直接选择。
     */
    public Map<String, Object> searchCustomers(String query, String objectType, int limit) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("list", customerSearch.search(query, blankToNull(objectType), Math.max(1, Math.min(limit, 20))));
        return result;
    }

    public List<Map<String, Object>> conversations(String user) {
        return conversations.list(user);
    }

    public Map<String, Object> createConversation(String user) {
        return conversations.create(user);
    }

    public Map<String, Object> conversation(String user, String id) {
        Map<String, Object> conversation = conversations.detail(user, id);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("conversation", conversation);
        String key = conversations.activeSessionKey(conversation);
        if (key != null)
            sessionRepository.find(key).ifPresent(session -> result.put("activeSession", sessionView(session)));
        return result;
    }

    public Map<String, Object> startCreate(String user, Map<String, Object> body) {
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        String conversationId = text(conversation.get("id"));
        appendUser(user, conversationId, text(body.get("message")), null);
        BizSession session = sessions.load(conversationId, user, ActiveSkill.CREATE, null, System.currentTimeMillis());
        String message = text(body.get("message"));
        session.guidedCreate = !pureCreateIntent(message);
        if (session.guidedCreate) {
            List<Map<String, Object>> initial = initialCreateSlots(message);
            String customerQuery = customerQueryFrom(message);
            if (customerQuery != null) initial.add(slot("visitObjectInfo", customerQuery));
            if (!initial.isEmpty()) sessions.resolve(session, initial, true);
            else sessionRepository.save(session);
        }
        conversations.activate(user, conversationId, session.sessionKey);
        if (!session.guidedCreate)
            return respond(user, conversationId, session, "请补充完整的拜访计划信息。", createForm(session, "create", null));
        return createProgressResponse(user, conversationId, session);
    }

    public Map<String, Object> resolveCreate(String user, Map<String, Object> body) {
        BizSession session = ownedSession(user, required(body, "sessionId"));
        if (session.activeSkill != ActiveSkill.CREATE && session.activeSkill != ActiveSkill.UPDATE)
            throw new BizException("INVALID_FLOW", "当前不是创建或修改计划流程", HttpStatus.CONFLICT);
        String conversationId = conversationId(body, session);
        String display = firstText(body, "displayText", "text");
        appendUser(user, conversationId, display, session.sessionKey);
        List<Map<String, Object>> items = new ArrayList<>();
        Object slotValues = body.get("slots");
        if (slotValues instanceof Map) {
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) slotValues).entrySet())
                items.add(slot(String.valueOf(entry.getKey()), normalizeSlot(String.valueOf(entry.getKey()), entry.getValue())));
        } else if (body.get("slotName") != null) {
            String name = String.valueOf(body.get("slotName"));
            items.add(slot(name, normalizeSlot(name, body.get("value"))));
        } else if (body.get("text") != null && session.waitingFor.size() == 1) {
            String name = session.waitingFor.get(0);
            items.add(slot(name, normalizeSlot(name, body.get("text"))));
        }
        if (!items.isEmpty()) sessions.resolve(session, items, true);
        resolvePendingCustomer(session);
        boolean ready = session.waitingFor.isEmpty() && session.ambiguous.isEmpty();
        Map<String, Object> card = ready ? summaryCard(session, "confirm")
                : session.guidedCreate ? nextSlotCard(session)
                : createForm(session, session.activeSkill == ActiveSkill.UPDATE ? "edit" : "create", session.planId);
        return respond(user, conversationId, session,
                ready ? "信息已完整，请确认后提交。"
                        : session.guidedCreate ? nextSlotPrompt(session) : "请继续补充拜访信息。", card);
    }

    public Map<String, Object> confirmCreate(String user, Map<String, Object> body) {
        BizSession session = ownedSession(user, required(body, "sessionId"));
        String conversationId = conversationId(body, session);
        appendUser(user, conversationId, "确认提交", session.sessionKey);
        sessions.confirm(session);
        String action = session.activeSkill == ActiveSkill.UPDATE ? "update" : "create";
        VisitPlan plan = (VisitPlan) visits.execute(session, "mobile-" + UUID.randomUUID(), action, session.slots);
        Map<String, Object> card = summaryCard(session, "success");
        ((Map<String, Object>) card.get("data")).put("visitPlanId", String.valueOf(plan.id));
        return respond(user, conversationId, session,
                session.activeSkill == ActiveSkill.UPDATE ? "拜访计划修改成功。" : "拜访计划创建成功。", card);
    }

    public Map<String, Object> resetCreate(String user, Map<String, Object> body) {
        String old = text(body.get("sessionId"));
        if (old != null) {
            BizSession session = ownedSession(user, old);
            sessionRepository.delete(session.sessionKey);
        }
        Map<String, Object> next = new LinkedHashMap<>(body);
        next.put("message", "重新填写拜访计划");
        return startCreate(user, next);
    }

    public Map<String, Object> editPlan(String user, Map<String, Object> body) {
        long planId = longValue(required(body, "planId"));
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        String conversationId = text(conversation.get("id"));
        appendUser(user, conversationId, "修改计划", null);
        BizSession session = sessions.load(conversationId, user, ActiveSkill.UPDATE, planId, System.currentTimeMillis());
        sessions.initializeSlots(session, visits.slotsFromPlan(planId, user));
        conversations.activate(user, conversationId, session.sessionKey);
        return respond(user, conversationId, session, "请修改需要调整的拜访信息。", createForm(session, "edit", planId));
    }

    public Map<String, Object> startCheckin(String user, Map<String, Object> body) {
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        String conversationId = text(conversation.get("id"));
        appendUser(user, conversationId, firstText(body, "message", "displayText"), null);
        BizSession session = sessions.load(conversationId, user, ActiveSkill.CHECKIN, null, System.currentTimeMillis());
        conversations.activate(user, conversationId, session.sessionKey);
        return respond(user, conversationId, session, "签到前需要获取当前位置。", card("enable-location", "开启位置", Collections.emptyMap()));
    }

    public Map<String, Object> resolveCheckin(String user, Map<String, Object> body) {
        BizSession session = ownedSession(user, required(body, "sessionId"));
        if (session.activeSkill != ActiveSkill.CHECKIN)
            throw new BizException("INVALID_FLOW", "当前不是签到流程", HttpStatus.CONFLICT);
        String conversationId = conversationId(body, session);
        appendUser(user, conversationId, firstText(body, "displayText", "message"), session.sessionKey);
        Map<String, Object> location = map(body.get("location"));
        session.slots.put("location", location);
        Object planId = body.get("planId");
        if (planId == null) {
            session.planId = null;
            sessionRepository.save(session);
            List<Map<String, Object>> items = checkinCandidates(user, location);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("items", items);
            return respond(user, conversationId, session,
                    items.isEmpty() ? "当前没有可签到的拜访计划。" : "请选择要签到的拜访计划。",
                    card("checkin-plans", "待签到计划", data));
        }
        VisitPlan plan = visits.detail(longValue(String.valueOf(planId)));
        owner(plan, user);
        VisitHandlerSupport.requireTodayCheckin(plan);
        session.planId = plan.id;
        sessionRepository.save(session);
        return respond(user, conversationId, session, "请核对位置并完成拍照签到。", checkinCard(plan, location));
    }

    public Map<String, Object> submitCheckin(String user, Map<String, Object> body) {
        BizSession session = ownedSession(user, required(body, "sessionId"));
        String conversationId = conversationId(body, session);
        long planId = longValue(required(body, "planId"));
        session.planId = planId;
        Map<String, Object> location = map(body.get("location"));
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("longitude", location.get("longitude"));
        params.put("latitude", location.get("latitude"));
        params.put("address", location.get("address"));
        params.put("photoUrl", body.get("photoUrl"));
        if (session.fsmState == FsmState.CONFIRMING) sessions.confirm(session);
        VisitPlan plan = (VisitPlan) visits.execute(session, "mobile-" + UUID.randomUUID(), "checkin", params);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("visitPlanId", String.valueOf(plan.id));
        data.put("visitId", String.valueOf(plan.id));
        data.put("clientName", plan.customerName);
        data.put("checkinTime", format(plan.checkinTime));
        data.put("checkinAddress", plan.checkinAddress);
        data.put("planVisitTime", format(plan.planTime));
        data.put("planVisitAddress", plan.planAddress);
        data.put("checkinAbnormalReason", plan.checkinAbnormalReason);
        Map<String, Object> resultCard = card("checkin-success", "签到成功", data);
        resultCard.put("actions", Arrays.asList(action("record-log", "录制拜访纪要", true), action("edit-plan", "修改拜访计划", false)));
        return respond(user, conversationId, session, "签到成功。", resultCard);
    }

    public List<Map<String, Object>> plans(String user, String type) {
        List<PlanStatus> statuses;
        if ("checkout".equals(type)) statuses = Collections.singletonList(PlanStatus.CHECKED_IN);
        else if ("log".equals(type)) statuses = Arrays.asList(PlanStatus.CHECKED_OUT, PlanStatus.LOGGED);
        else if ("checkin".equals(type)) statuses = Collections.singletonList(PlanStatus.PLANNED);
        else
            statuses = Arrays.asList(PlanStatus.PLANNED, PlanStatus.CHECKED_IN, PlanStatus.CHECKED_OUT, PlanStatus.LOGGED);
        List<Map<String, Object>> result = new ArrayList<>();
        for (VisitPlan plan : visits.list(user, null, statuses, 100)) result.add(planItem(plan));
        return result;
    }

    public Map<String, Object> cancelPlan(String user, Map<String, Object> body) {
        long planId = longValue(required(body, "planId"));
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        BizSession session = actionSession(user, text(conversation.get("id")), ActiveSkill.CANCEL, planId, Collections.emptyMap());
        VisitPlan plan = (VisitPlan) visits.execute(session, turn(body), "cancel", Collections.emptyMap());
        return respond(user, session.chatId, session, "拜访计划已取消。", planResultCard(plan, "canceled", "已取消"));
    }

    public Map<String, Object> startCancel(String user, Map<String, Object> body) {
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        String conversationId = text(conversation.get("id"));
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("items", plans(user, "checkin"));
        return simpleRespond(user, conversationId, "请选择要取消的未开始拜访计划。", card("cancel-plans", "取消拜访计划", data));
    }

    public Map<String, Object> startCheckout(String user, Map<String, Object> body) {
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        String conversationId = text(conversation.get("id"));
        String id = text(body.get("planId"));
        if (id == null) {
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("items", plans(user, "checkout"));
            return simpleRespond(user, conversationId, "请选择要签退的拜访计划。", card("checkout-plans", "待签退计划", data));
        }
        VisitPlan plan = visits.detailOwned(longValue(id), user);
        BizSession session = actionSession(user, conversationId, ActiveSkill.CHECKOUT, plan.id, Collections.emptyMap());
        Map<String, Object> data = planItem(plan);
        data.put("location", map(body.get("location")));
        return respond(user, conversationId, session, "请先完成签退预校验。", card("checkout-precheck", "签退确认", data));
    }

    public Map<String, Object> precheckCheckout(String user, Map<String, Object> body) {
        BizSession session = ownedSession(user, required(body, "sessionId"));
        long planId = body.get("planId") == null ? session.planId : longValue(String.valueOf(body.get("planId")));
        session.planId = planId;
        sessionRepository.save(session);
        Map<String, Object> request = locationRequest(body, planId);
        Map<String, Object> check = contracts.preCheckCheckout(request);
        Map<String, Object> data = new LinkedHashMap<>(planItem(visits.detailOwned(planId, user)));
        data.putAll(check);
        data.put("location", map(body.get("location")));
        return respond(user, conversationId(body, session), session, Boolean.TRUE.equals(check.get("canCheckout")) ? "预校验通过，请确认签退。" : "当前无法签退。", card("checkout-confirm", "签退确认", data));
    }

    public Map<String, Object> submitCheckout(String user, Map<String, Object> body) {
        BizSession session = ownedSession(user, required(body, "sessionId"));
        long planId = body.get("planId") == null ? session.planId : longValue(String.valueOf(body.get("planId")));
        session.planId = planId;
        Map<String, Object> params = locationRequest(body, planId);
        if (session.fsmState == FsmState.CONFIRMING) sessions.confirm(session);
        VisitPlan plan = (VisitPlan) visits.execute(session, turn(body), "checkout", params);
        return respond(user, conversationId(body, session), session, "签退成功，请填写拜访日志。", planResultCard(plan, "checkout-success", "签退成功"));
    }

    public Map<String, Object> startLog(String user, Map<String, Object> body) {
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        String conversationId = text(conversation.get("id"));
        String id = text(body.get("planId"));
        if (id == null) {
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("items", plans(user, "log"));
            return simpleRespond(user, conversationId, "请选择要填写或修改日志的计划。", card("log-plans", "拜访日志", data));
        }
        VisitPlan plan = visits.detailOwned(longValue(id), user);
        BizSession session = actionSession(user, conversationId, ActiveSkill.FILL_LOG, plan.id, Collections.emptyMap());
        Map<String, Object> data = planItem(plan);
        data.put("visitSummary", plan.visitSummary);
        data.put("contacts", readContacts(plan.contactsJson));
        data.put("mode", plan.status == PlanStatus.LOGGED ? "edit" : "create");
        return respond(user, conversationId, session, "请填写联系人和拜访纪要。", card("visit-log", "拜访日志", data));
    }

    public Map<String, Object> submitLog(String user, Map<String, Object> body) {
        BizSession session = ownedSession(user, required(body, "sessionId"));
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("contacts", body.get("contacts"));
        params.put("visitSummary", body.get("visitSummary"));
        session.slots.putAll(params);
        session.waitingFor = resolver.required(session);
        session.fsmState = session.waitingFor.isEmpty() ? FsmState.CONFIRMING : FsmState.FILLING;
        sessionRepository.save(session);
        if (session.fsmState == FsmState.CONFIRMING) sessions.confirm(session);
        VisitPlan plan = (VisitPlan) visits.execute(session, turn(body), "fill_log", params);
        return respond(user, conversationId(body, session), session, "拜访日志已保存。", planResultCard(plan, "log-success", "日志已保存"));
    }

    public Map<String, Object> supplementCheckout(String user, Map<String, Object> body) {
        long id = longValue(required(body, "planId"));
        visits.detailOwned(id, user);
        contracts.supplementCheckout(id);
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        return simpleRespond(user, text(conversation.get("id")), "签退已补录，请继续填写拜访日志。", planResultCard(visits.detailOwned(id, user), "checkout-success", "补录签退成功"));
    }

    public Map<String, Object> startRecording(String user, Map<String, Object> body) {
        long planId = longValue(required(body, "planId"));
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        String conversationId = text(conversation.get("id"));
        BizSession session = actionSession(user, conversationId, ActiveSkill.RECORD, planId, Collections.emptyMap());
        if (session.fsmState == FsmState.CONFIRMING) sessions.confirm(session);
        @SuppressWarnings("unchecked") Map<String, Object> result = (Map<String, Object>) visits.execute(session, turn(body), "start_recording", Collections.emptyMap());
        return respond(user, conversationId, session, "录音已开始。", card("recording", "录音中", result));
    }

    public Map<String, Object> stopRecording(String user, Map<String, Object> body) {
        BizSession session = ownedSession(user, required(body, "sessionId"));
        session.fsmState = FsmState.CONFIRMING;
        sessionRepository.save(session);
        sessions.confirm(session);
        Map<String, Object> params = new LinkedHashMap<>(body);
        @SuppressWarnings("unchecked") Map<String, Object> result = (Map<String, Object>) visits.execute(session, turn(body), "stop_recording", params);
        return respond(user, conversationId(body, session), session, "录音已结束，纪要正在生成。", card("recording-processing", "纪要生成中", result));
    }

    public Map<String, Object> recording(String user, long id) {
        Map<String, Object> result = visits.recording(id);
        visits.detailOwned(((Number) result.get("visitPlanId")).longValue(), user);
        return result;
    }

    public Map<String, Object> submitReview(String user, Map<String, Object> body) {
        long planId = longValue(required(body, "planId"));
        Map<String, Object> conversation = ensureConversation(user, text(body.get("conversationId")));
        BizSession session = actionSession(user, text(conversation.get("id")), ActiveSkill.REVIEW, planId, Collections.emptyMap());
        VisitPlan plan = (VisitPlan) visits.execute(session, turn(body), "submit_review", Collections.emptyMap());
        return respond(user, session.chatId, session, "拜访日志已提交审核。", planResultCard(plan, "review-pending", "待审核"));
    }

    private List<Map<String, Object>> checkinCandidates(String user, Map<String, Object> location) {
        LocalDate today = LocalDate.now(ZONE);
        List<VisitPlan> found = plans.findByFilters(user, Collections.singletonList(PlanStatus.PLANNED),
                today.atStartOfDay(ZONE).toInstant(), today.plusDays(1).atStartOfDay(ZONE).toInstant(), null, null, 100);
        List<Map<String, Object>> result = new ArrayList<>();
        for (VisitPlan plan : found) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("visitPlanId", String.valueOf(plan.id));
            item.put("customerName", plan.customerName);
            item.put("customerTypeLabel", customerType(plan));
            item.put("planVisitTime", format(plan.planTime));
            item.put("planVisitTimeLabel", format(plan.planTime));
            item.put("planVisitAddress", plan.planAddress);
            item.put("distance", distance(plan, location));
            result.add(item);
        }
        result.sort(Comparator.comparingDouble(item -> item.get("distance") instanceof Number ? ((Number) item.get("distance")).doubleValue() : Double.MAX_VALUE));
        return result;
    }

    private Map<String, Object> simpleRespond(String user, String conversationId, String message, Map<String, Object> card) {
        conversations.append(user, conversationId, "assistant", message, card, null);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", message);
        result.put("card", card);
        result.put("conversation", conversations.detail(user, conversationId));
        return result;
    }

    private Map<String, Object> createProgressResponse(String user, String conversationId, BizSession session) {
        boolean ready = session.waitingFor.isEmpty() && session.ambiguous.isEmpty();
        return respond(user, conversationId, session, ready ? "信息已完整，请确认后提交。" : nextSlotPrompt(session),
                ready ? summaryCard(session, "confirm") : nextSlotCard(session));
    }

    private Map<String, Object> nextSlotCard(BizSession session) {
        String internal = nextSlot(session);
        String external = externalSlotName(internal);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("slotName", external);
        Map<String, Object> result = card(session.ambiguous.containsKey(internal) ? "candidates" : "ask", FIELD_LABELS.getOrDefault(internal, "补充拜访信息"), data);
        List<Map<String, Object>> candidates = slotCandidates(session, internal);
        if (!candidates.isEmpty()) result.put("candidates", candidates);
        return result;
    }

    private String nextSlotPrompt(BizSession session) {
        String internal = nextSlot(session);
        if (session.ambiguous.containsKey(internal))
            return "找到多个匹配项，请选择正确的" + FIELD_LABELS.getOrDefault(internal, "信息") + "。";
        switch (internal) {
            case "visitForm":
                return "这是本地拜访还是出差拜访？";
            case "objectType":
                return session.pendingCustomerQuery == null
                        ? "拜访对象是广告客户、广告代理商、门店还是团购服务商？"
                        : "你说的“" + session.pendingCustomerQuery + "”属于广告客户、广告代理商、门店还是团购服务商？";
            case "customerType":
                return "请问该客户是新客还是老客？";
            case "adIsTarget":
                return "请确认是否为靶向新客？";
            case "customer":
                return "请告诉我要拜访的客户或门店名称。";
            case "purpose":
                return "请选择本次拜访目的。";
            case "planTime":
                return "请告诉我计划拜访时间。";
            case "planAddress":
                return "请告诉我计划拜访地址。";
            case "travelApplyId":
                return "请选择本次拜访关联的差旅申请。";
            default:
                return "请继续补充拜访计划信息。";
        }
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> slotCandidates(BizSession session, String internal) {
        Object ambiguous = session.ambiguous.get(internal);
        if (ambiguous instanceof List) {
            List<Map<String, Object>> result = new ArrayList<>();
            for (Object value : (List<?>) ambiguous) {
                Map<String, Object> payload = map(value);
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("title", first(payload, "name", "displayName", "label", "address"));
                item.put("subtitle", first(payload, "address", "city"));
                item.put("payload", payload);
                result.add(item);
            }
            return result;
        }
        List<Map<String, Object>> values = new ArrayList<>();
        if ("visitForm".equals(internal)) {
            values.add(candidate("本地拜访", "local"));
            values.add(candidate("出差拜访", "travel"));
        } else if ("objectType".equals(internal)) {
            values.add(candidate("广告客户", "ad_customer"));
            values.add(candidate("广告代理商", "agent"));
            values.add(candidate("门店", "store"));
            values.add(candidate("团购服务商", "provider"));
        } else if ("customerType".equals(internal)) {
            values.add(candidate("新客", "new"));
            values.add(candidate("老客", "old"));
        } else if ("adIsTarget".equals(internal)) {
            values.add(candidate("是", true));
            values.add(candidate("否", false));
        } else if ("purpose".equals(internal)) for (Map.Entry<String, String> entry : resolver.purposes().entrySet())
            values.add(candidate(entry.getValue(), entry.getKey()));
        return values;
    }

    private static Map<String, Object> candidate(String title, Object value) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("title", title);
        item.put("payload", value);
        return item;
    }

    private List<Map<String, Object>> initialCreateSlots(String message) {
        List<Map<String, Object>> items = new ArrayList<>();
        if (message == null) return items;
        String text = message.trim();
        if (containsAny(text, "本地")) items.add(slot("visitType", "本地"));
        else if (containsAny(text, "出差", "差旅")) items.add(slot("visitType", "出差"));
        String objectType = null;
        if (containsAny(text, "门店", "店铺")) objectType = "门店";
        else if (containsAny(text, "代理商", "广告代理")) objectType = "代理商";
        else if (containsAny(text, "服务商")) objectType = "服务商";
        else if (containsAny(text, "广告客户")) objectType = "广告客户";
        if (objectType != null) items.add(slot("visitObjectType", objectType));
        if (containsAny(text, "新客", "新客户")) items.add(slot("customerType", "新客"));
        else if (containsAny(text, "老客", "老客户", "旧客")) items.add(slot("customerType", "老客"));
        if (containsAny(text, "非靶向", "不是靶向")) items.add(slot("adIsTarget", false));
        else if (containsAny(text, "靶向新客", "靶向客户")) items.add(slot("adIsTarget", true));
        String purpose = purposeFrom(text);
        if (purpose != null) items.add(slot("visitPurpose", purpose));
        String time = planTimeFrom(text);
        if (time != null) items.add(slot("planVisitTime", time));
        String address = extract(text, "(?:拜访地点|拜访地址|地点|地址)(?:是|为|在|：|:)?\\s*([^，,。；;]+)");
        if (address != null) items.add(slot("planVisitAddress", address));
        return items;
    }

    private void resolvePendingCustomer(BizSession session) {
        if (session.pendingCustomerQuery == null || session.slots.get("objectType") == null) return;
        String query = session.pendingCustomerQuery;
        sessions.resolve(session, Collections.singletonList(slot("visitObjectInfo", query)), true);
        session.pendingCustomerQuery = null;
        sessionRepository.save(session);
    }

    private static String nextSlot(BizSession session) {
        if (!session.ambiguous.isEmpty()) return session.ambiguous.keySet().iterator().next();
        if (session.pendingCustomerQuery != null && !session.slots.containsKey("objectType")) return "objectType";
        return session.waitingFor.isEmpty() ? "" : session.waitingFor.get(0);
    }

    private static String customerQueryFrom(String text) {
        if (text == null) return null;
        String explicit = extract(text, "(?:拜访对象|客户名称|门店名称|公司名称)(?:是|为|叫|：|:)?\\s*([^，,。；;]+)");
        if (explicit != null) return explicit;
        return extract(text, "(?:客户|门店|公司)\\s*(?:是|为|叫|：|:)\\s*([^，,。；;]+)");
    }

    private String purposeFrom(String text) {
        for (Map.Entry<String, String> entry : resolver.purposes().entrySet()) {
            String label = entry.getValue();
            String leaf = label.contains("/") ? label.substring(label.indexOf('/') + 1) : label;
            if (text.contains(label) || text.contains(leaf)) return entry.getKey();
        }
        if (text.contains("客情维护")) return "customer_maintenance";
        if (text.contains("产品培训")) return "meeting_product_training";
        if (text.contains("复盘")) return "meeting_review";
        if (text.contains("项目提案")) return "meeting_project";
        return null;
    }

    private static String planTimeFrom(String text) {
        Matcher relative = Pattern.compile("(今天|明天|后天)(?:上午|下午|晚上|中午)?\\s*(\\d{1,2})?(?:点|时)?(?:(\\d{1,2})分)?").matcher(text);
        if (relative.find()) {
            int plus = "明天".equals(relative.group(1)) ? 1 : "后天".equals(relative.group(1)) ? 2 : 0;
            int hour = relative.group(2) == null ? 9 : Integer.parseInt(relative.group(2));
            String token = relative.group();
            if ((token.contains("下午") || token.contains("晚上")) && hour < 12) hour += 12;
            int minute = relative.group(3) == null ? 0 : Integer.parseInt(relative.group(3));
            return LocalDate.now(ZONE).plusDays(plus).atTime(hour, minute).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        }
        Matcher absolute = Pattern.compile("(20\\d{2})[-/年](\\d{1,2})[-/月](\\d{1,2})日?(?:\\s*(?:上午|下午)?\\s*(\\d{1,2})(?:点|时|:)(\\d{1,2})?)?").matcher(text);
        if (absolute.find()) {
            int hour = absolute.group(4) == null ? 9 : Integer.parseInt(absolute.group(4));
            if (absolute.group().contains("下午") && hour < 12) hour += 12;
            int minute = absolute.group(5) == null ? 0 : Integer.parseInt(absolute.group(5));
            return LocalDate.of(Integer.parseInt(absolute.group(1)), Integer.parseInt(absolute.group(2)), Integer.parseInt(absolute.group(3))).atTime(hour, minute).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        }
        return null;
    }

    private static boolean pureCreateIntent(String message) {
        if (message == null || message.trim().isEmpty()) return true;
        String value = message.replaceAll("[。！!？?，,\\s]", "").replaceAll("^(我要|我想|帮我|请帮我|麻烦帮我)", "").replaceAll("(创建|新建|建立|新增|建)(一个)?拜访计划", "").replaceAll("(创建|新建)拜访", "");
        return value.isEmpty();
    }

    private static String extract(String text, String regex) {
        Matcher matcher = Pattern.compile(regex).matcher(text);
        if (!matcher.find()) return null;
        String value = matcher.group(1).trim();
        return value.isEmpty() ? null : value;
    }

    private static boolean containsAny(String text, String... values) {
        for (String value : values) if (text.contains(value)) return true;
        return false;
    }

    private static String externalSlotName(String internal) {
        switch (internal) {
            case "visitForm":
                return "visitType";
            case "objectType":
                return "visitObjectType";
            case "customer":
                return "visitObjectInfo";
            case "purpose":
                return "visitPurpose";
            case "planTime":
                return "planVisitTime";
            case "planAddress":
                return "planVisitAddress";
            case "travelApplyId":
                return "travelApplyNo";
            default:
                return internal;
        }
    }

    private static final Map<String, String> FIELD_LABELS = new LinkedHashMap<>();

    static {
        FIELD_LABELS.put("visitForm", "拜访形式");
        FIELD_LABELS.put("objectType", "对象类型");
        FIELD_LABELS.put("customerType", "客户类型");
        FIELD_LABELS.put("adIsTarget", "靶向新客");
        FIELD_LABELS.put("customer", "拜访对象");
        FIELD_LABELS.put("purpose", "拜访目的");
        FIELD_LABELS.put("planTime", "拜访时间");
        FIELD_LABELS.put("planAddress", "拜访地址");
        FIELD_LABELS.put("travelApplyId", "差旅申请");
    }

    private BizSession actionSession(String user, String conversationId, ActiveSkill skill, long planId, Map<String, Object> slots) {
        BizSession session = sessions.load(conversationId, user, skill, planId, System.currentTimeMillis());
        session.planId = planId;
        if (slots != null) session.slots.putAll(slots);
        session.waitingFor = resolver.required(session);
        session.fsmState = session.waitingFor.isEmpty() ? FsmState.CONFIRMING : FsmState.FILLING;
        sessionRepository.save(session);
        conversations.activate(user, conversationId, session.sessionKey);
        return session;
    }

    private Map<String, Object> locationRequest(Map<String, Object> body, long planId) {
        Map<String, Object> location = map(body.get("location"));
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("visitPlanId", planId);
        result.put("longitude", first(location, "longitude", "lng"));
        result.put("latitude", first(location, "latitude", "lat"));
        result.put("address", first(location, "address", "name"));
        return result;
    }

    private Map<String, Object> planItem(VisitPlan plan) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("visitPlanId", String.valueOf(plan.id));
        item.put("visitId", String.valueOf(plan.id));
        item.put("customerName", plan.customerName);
        item.put("planVisitTime", format(plan.planTime));
        item.put("planVisitAddress", plan.planAddress);
        item.put("status", plan.status);
        item.put("reviewStatus", plan.reviewStatus);
        item.put("checkinTime", format(plan.checkinTime));
        item.put("checkoutTime", format(plan.checkoutTime));
        return item;
    }

    private Map<String, Object> planResultCard(VisitPlan plan, String type, String title) {
        Map<String, Object> data = planItem(plan);
        data.put("visitSummary", plan.visitSummary);
        data.put("reviewComment", plan.reviewComment);
        return card(type, title, data);
    }

    private Map<String, Object> readContacts(String value) {
        if (value == null) return Collections.emptyMap();
        try {
            return new com.fasterxml.jackson.databind.ObjectMapper().readValue(value, new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {
            });
        } catch (Exception ignored) {
            return Collections.emptyMap();
        }
    }

    private static String turn(Map<String, Object> body) {
        String value = text(body.get("clientActionId"));
        return value == null ? "mobile-" + UUID.randomUUID() : value;
    }

    private Map<String, Object> checkinCard(VisitPlan plan, Map<String, Object> location) {
        Double distance = distance(plan, location);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("visitPlanId", String.valueOf(plan.id));
        data.put("clientName", plan.customerName);
        data.put("visitTarget", Collections.singletonMap("label", customerType(plan)));
        data.put("planVisitTime", format(plan.planTime));
        data.put("planVisitAddress", plan.planAddress);
        data.put("visitPurpose", plan.purposeLabel);
        data.put("currentAddress", location.get("address"));
        data.put("currentDistance", distance);
        data.put("rangeLimit", 1000);
        data.put("isTargetOutOfRange", distance != null && distance > 1000);
        data.put("rightBtnText", "拍照签到");
        data.put("buttonDisabled", false);
        return card("checkin-card", "拜访签到", data);
    }

    private Map<String, Object> respond(String user, String conversationId, BizSession session,
                                        String message, Map<String, Object> card) {
        conversations.append(user, conversationId, "assistant", message, card, session.sessionKey);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", message);
        result.put("card", card);
        result.put("session", sessionView(session));
        result.put("conversation", conversations.detail(user, conversationId));
        return result;
    }

    private Map<String, Object> createForm(BizSession session, String mode, Long planId) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("mode", mode);
        data.put("visitPlanId", planId == null ? null : String.valueOf(planId));
        data.put("slots", externalSlots(session.slots));
        return card("create-form", "edit".equals(mode) ? "修改拜访计划" : "创建拜访计划", data);
    }

    private Map<String, Object> summaryCard(BizSession session, String type) {
        Map<String, Object> slots = externalSlots(session.slots);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("mode", session.activeSkill == ActiveSkill.UPDATE ? "edit" : "create");
        data.put("visitType", label(slots.get("visitType")));
        data.put("visitObjectType", label(slots.get("visitObjectType")));
        data.put("customerType", label(slots.get("customerType")));
        Map<String, Object> customer = map(slots.get("visitObjectInfo"));
        data.put("customerName", first(customer, "displayName", "licenseName"));
        data.put("licenseNo", first(customer, "licenseCode", "id"));
        data.put("visitPurpose", label(slots.get("visitPurpose")));
        data.put("planTime", slots.get("planVisitTime"));
        data.put("planAddress", label(slots.get("planVisitAddress")));
        data.put("travelApplyNo", slots.get("travelApplyNo"));
        data.put("adIsTarget", label(slots.get("adIsTarget")));
        data.put("visitPlanId", session.planId == null ? null : String.valueOf(session.planId));
        Map<String, Object> card = card(type, "success".equals(type) ? "操作成功" : "确认拜访计划", data);
        if ("confirm".equals(type))
            card.put("actions", Collections.singletonList(action("confirm", session.activeSkill == ActiveSkill.UPDATE ? "确认修改" : "确认创建", true)));
        else
            card.put("actions", Arrays.asList(action("edit-plan", "修改当前计划", false), action("start-create", "继续创建", true)));
        return card;
    }

    private Map<String, Object> externalSlots(Map<String, Object> slots) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("visitType", slots.get("visitForm"));
        result.put("visitObjectType", slots.get("objectType"));
        result.put("customerType", slots.get("customerType"));
        Map<String, Object> customer = map(slots.get("customer"));
        if (!customer.isEmpty()) {
            Map<String, Object> view = new LinkedHashMap<>();
            view.put("id", customer.get("id"));
            view.put("displayName", customer.get("name"));
            view.put("licenseCode", customer.get("id"));
            view.put("licenseName", customer.get("name"));
            result.put("visitObjectInfo", view);
        }
        Map<String, Object> purpose = map(slots.get("purpose"));
        if (!purpose.isEmpty()) {
            Map<String, Object> view = new LinkedHashMap<>();
            view.put("value", purpose.get("code"));
            view.put("label", purpose.get("label"));
            result.put("visitPurpose", view);
        }
        Object time = slots.get("planTime");
        if (time != null) {
            try {
                Instant instant = time instanceof Instant ? (Instant) time : Instant.parse(String.valueOf(time));
                result.put("planVisitTime", DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm").withZone(ZONE).format(instant));
            } catch (RuntimeException ignored) {
                result.put("planVisitTime", String.valueOf(time));
            }
        }
        if (slots.get("planAddress") != null) result.put("planVisitAddress", slots.get("planAddress"));
        result.put("travelApplyNo", slots.get("travelApplyId"));
        if (slots.get("adIsTarget") instanceof Boolean) {
            Map<String, Object> target = new LinkedHashMap<>();
            target.put("isTargetCustomer", slots.get("adIsTarget"));
            target.put("label", Boolean.TRUE.equals(slots.get("adIsTarget")) ? "是" : "否");
            result.put("adIsTarget", target);
        }
        return result;
    }

    private Object normalizeSlot(String name, Object value) {
        if (("visitObjectInfo".equals(name) || "customer".equals(name)) && value instanceof Map) {
            Map<String, Object> source = map(value);
            Map<String, Object> customer = new LinkedHashMap<>();
            customer.put("id", first(source, "id", "licenseCode", "licenseNo", "storePoiId", "poiId", "agentId", "providerId"));
            customer.put("name", first(source, "name", "displayName", "licenseName", "corporationName", "storePoiName", "poiName", "agentName", "providerName"));
            customer.put("objectType", first(source, "objectType", "visitObjectType"));
            return customer;
        }
        if (("visitPurpose".equals(name) || "purpose".equals(name)) && value instanceof Map)
            return first(map(value), "value", "code", "label");
        if ("adIsTarget".equals(name) && value instanceof Map)
            return first(map(value), "isTargetCustomer", "value", "label");
        return value;
    }

    private Map<String, Object> ensureConversation(String user, String id) {
        return id == null || id.isEmpty() ? conversations.create(user) : conversations.detail(user, id);
    }

    private BizSession ownedSession(String user, String key) {
        BizSession session = sessionRepository.find(key).orElseThrow(() -> new BizException("SESSION_NOT_FOUND", "拜访流程已失效，请重新开始", HttpStatus.NOT_FOUND));
        if (!user.equals(session.userId))
            throw new BizException("FORBIDDEN", "无权访问该拜访流程", HttpStatus.FORBIDDEN);
        return session;
    }

    private String conversationId(Map<String, Object> body, BizSession session) {
        String id = text(body.get("conversationId"));
        return id == null ? session.chatId : id;
    }

    private void appendUser(String user, String conversationId, String content, String sessionKey) {
        if (content != null && !content.trim().isEmpty())
            conversations.append(user, conversationId, "user", content, null, sessionKey);
    }

    private void owner(VisitPlan plan, String user) {
        if (!user.equals(plan.creatorId))
            throw new BizException("FORBIDDEN", "无权操作该拜访计划", HttpStatus.FORBIDDEN);
    }

    private Double distance(VisitPlan plan, Map<String, Object> location) {
        Double lng = number(location.get("longitude")), lat = number(location.get("latitude"));
        return lng == null || lat == null || plan.longitude == null || plan.latitude == null ? null : VisitHandlerSupport.distance(lat, lng, plan.latitude, plan.longitude);
    }

    private static String customerType(VisitPlan plan) {
        if ("new".equals(plan.customerType)) return "新客";
        if ("old".equals(plan.customerType)) return "老客";
        return plan.objectType;
    }

    private static String format(Instant value) {
        return value == null ? "" : DateTimeFormatter.ofPattern("MM-dd HH:mm").withZone(ZONE).format(value);
    }

    private Map<String, Object> sessionView(BizSession session) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("id", session.sessionKey);
        result.put("conversationId", session.chatId);
        result.put("fsmState", session.fsmState);
        result.put("waitingFor", session.waitingFor);
        result.put("slots", externalSlots(session.slots));
        return result;
    }

    private static Map<String, Object> card(String type, String title, Map<String, Object> data) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("type", type);
        result.put("title", title);
        result.put("data", data);
        return result;
    }

    private static Map<String, Object> action(String id, String label, boolean primary) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("id", id);
        result.put("label", label);
        result.put("primary", primary);
        return result;
    }

    private static Map<String, Object> slot(String name, Object raw) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("slotName", name);
        result.put("raw", raw);
        return result;
    }

    private List<Map<String, Object>> purposeGroups() {
        Map<String, List<Map<String, Object>>> groups = new LinkedHashMap<>();
        for (Map.Entry<String, String> entry : resolver.purposes().entrySet()) {
            String group = entry.getKey().startsWith("meeting_") ? "会议场景" : entry.getKey().startsWith("onsite_") ? "驻场支持" : "通用";
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("value", entry.getKey());
            item.put("label", entry.getValue());
            groups.computeIfAbsent(group, ignored -> new ArrayList<>()).add(item);
        }
        List<Map<String, Object>> result = new ArrayList<>();
        int index = 0;
        for (Map.Entry<String, List<Map<String, Object>>> group : groups.entrySet()) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("value", "group_" + index++);
            item.put("label", group.getKey());
            item.put("children", group.getValue());
            result.add(item);
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Object value) {
        return value instanceof Map ? (Map<String, Object>) value : new LinkedHashMap<>();
    }

    private static Object first(Map<String, Object> map, String... keys) {
        for (String key : keys) if (map.get(key) != null) return map.get(key);
        return null;
    }

    private static String label(Object value) {
        if (value instanceof Map) {
            Object label = first(map(value), "label", "displayName", "address", "text", "value");
            return label == null ? null : String.valueOf(label);
        }
        return text(value);
    }

    private static String text(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    private static String blankToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }

    private static String firstText(Map<String, Object> map, String... keys) {
        Object value = first(map, keys);
        return text(value);
    }

    private static String required(Map<String, Object> map, String key) {
        String value = text(map.get(key));
        if (value == null || value.trim().isEmpty()) throw new BizException("MISSING_ARGUMENT", key + " 不能为空");
        return value;
    }

    private static long longValue(String value) {
        try {
            return Long.parseLong(value);
        } catch (Exception e) {
            throw new BizException("INVALID_ID", "计划ID格式错误");
        }
    }

    private static Double number(Object value) {
        if (value instanceof Number) return ((Number) value).doubleValue();
        try {
            return value == null ? null : Double.valueOf(String.valueOf(value));
        } catch (Exception e) {
            return null;
        }
    }
}
