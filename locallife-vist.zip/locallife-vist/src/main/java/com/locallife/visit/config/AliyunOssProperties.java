package com.locallife.visit.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "visit.oss")
public class AliyunOssProperties {
    private boolean enabled;
    private String endpoint;
    private String bucket;
    private String objectPrefix = "locallife-visit/recordings/";
    private long signedUrlSeconds = 86400;
    private long maxAudioBytes = 52428800;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getEndpoint() { return endpoint; }
    public void setEndpoint(String endpoint) { this.endpoint = endpoint; }
    public String getBucket() { return bucket; }
    public void setBucket(String bucket) { this.bucket = bucket; }
    public String getObjectPrefix() { return objectPrefix; }
    public void setObjectPrefix(String objectPrefix) { this.objectPrefix = objectPrefix; }
    public long getSignedUrlSeconds() { return signedUrlSeconds; }
    public void setSignedUrlSeconds(long signedUrlSeconds) { this.signedUrlSeconds = signedUrlSeconds; }
    public long getMaxAudioBytes() { return maxAudioBytes; }
    public void setMaxAudioBytes(long maxAudioBytes) { this.maxAudioBytes = maxAudioBytes; }
}
