package com.locallife.visit.integration;

public interface SummaryGateway {
    String summarize(String transcript);
}
