package com.locallife.visit.domain;

import java.time.Instant;

public class CustomerChangeEvent {
    public String eventId;
    public String eventType;
    public String customerId;
    public long version;
    public Instant occurredAt;
    public CustomerFileRecord data;
}
