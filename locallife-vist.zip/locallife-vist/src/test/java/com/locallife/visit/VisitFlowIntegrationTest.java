package com.locallife.visit;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.handler.VisitActionDispatcher;
import com.locallife.visit.service.CustomerSearchService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDate;
import java.time.ZoneId;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(properties = "visit.customer-sync.enabled=false")
@AutoConfigureMockMvc
@ActiveProfiles("test")
class VisitFlowIntegrationTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @Autowired VisitActionDispatcher dispatcher;
    @MockBean CustomerSearchService customerSearch;

    @Test
    void registersAllBusinessHandlers() {
        assertThat(dispatcher.registeredActions()).contains(
                "create", "create_plan", "update", "update_plan",
                "cancel", "cancel_plan", "checkin", "checkout",
                "fill_log", "submit_log", "edit_log", "start_recording", "stop_recording",
                "submit_review", "approve_review", "reject_review", "archive", "fallback");
    }

    @Test
    void completeVisitLifecycle() throws Exception {
        String create = "{\"visitForm\":\"local\",\"objectType\":\"ad_customer\",\"customerType\":\"old\",\"customer\":{\"id\":\"cust-001\",\"name\":\"北京果圈科技有限公司\"},\"purpose\":{\"code\":\"customer_maintenance\",\"label\":\"客情维护\"},\"planTime\":\"" + todayPlanTime() + "\",\"planAddress\":{\"text\":\"北京市海淀区西二旗大街1号\",\"longitude\":116.30,\"latitude\":40.05}}";
        String response = mvc.perform(post("/api/v1/visits").header("X-User-Id","tester").contentType(MediaType.APPLICATION_JSON).content(create)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        long id = json.readTree(response).path("data").path("id").asLong();
        assertThat(id).isPositive();

        String checkedIn=invoke(id,"checkin","{\"longitude\":116.30,\"latitude\":40.05,\"address\":\"现场\"}","turn-1");
        String retried=invoke(id,"checkin","{\"longitude\":116.30,\"latitude\":40.05,\"address\":\"现场\"}","turn-1");
        assertThat(json.readTree(retried).path("data").path("id").asLong()).isEqualTo(json.readTree(checkedIn).path("data").path("id").asLong());
        invoke(id,"checkout","{\"address\":\"现场\"}","turn-2");
        String logged = invoke(id,"log","{\"visitSummary\":\"客户认可方案，约定下周继续沟通\",\"contacts\":[{\"id\":\"contact-001\",\"name\":\"张经理\",\"isKp\":1}]}","turn-3");
        JsonNode node=json.readTree(logged);
        assertThat(node.path("data").path("status").asText()).isEqualTo("LOGGED");
    }

    @Test
    void rejectsCheckoutBeforeCheckin() throws Exception {
        String create = "{\"visitForm\":\"local\",\"objectType\":\"store\",\"customerType\":\"new\",\"customer\":{\"id\":\"store-001\",\"name\":\"肯德基龙泽家园店\"},\"purpose\":{\"code\":\"meeting_new_customer\",\"label\":\"新客开拓\"},\"planTime\":\"2030-01-02T02:00:00Z\",\"planAddress\":{\"text\":\"北京市昌平区龙泽园街道\"}}";
        String response=mvc.perform(post("/api/v1/visits").header("X-User-Id","tester2").contentType(MediaType.APPLICATION_JSON).content(create)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        long id=json.readTree(response).path("data").path("id").asLong();
        mvc.perform(post("/api/v1/visits/"+id+"/checkout").header("X-User-Id","tester2").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isConflict());
    }

    @Test
    void agentContractCreatesPlanAfterSlotConfirmation() throws Exception {
        long sessionCreatedAt=System.currentTimeMillis();
        String common="\"chatId\":\"agent-chat-"+sessionCreatedAt+"\",\"userId\":\"agent-user\",\"activeSkill\":\"create\",\"sessionCreatedAt\":"+sessionCreatedAt;
        mvc.perform(post("/rest/apicenter/visit/web/visitCenter/getAiVisitState").contentType(MediaType.APPLICATION_JSON).content("{"+common+"}"))
                .andExpect(status().isOk());
        String slots="{"+common+",\"items\":["
                +"{\"slotName\":\"visitType\",\"raw\":\"本地\"},"
                +"{\"slotName\":\"visitObjectType\",\"raw\":\"广告客户\"},"
                +"{\"slotName\":\"customerType\",\"raw\":\"老客\"},"
                +"{\"slotName\":\"visitObjectInfo\",\"raw\":{\"id\":\"cust-001\",\"name\":\"北京果圈科技有限公司\"}},"
                +"{\"slotName\":\"visitPurpose\",\"raw\":\"customer_maintenance\"},"
                +"{\"slotName\":\"planVisitTime\",\"raw\":\"2031-01-01 10:00\"},"
                +"{\"slotName\":\"planVisitAddress\",\"raw\":{\"text\":\"北京市海淀区西二旗大街1号\",\"longitude\":116.30,\"latitude\":40.05}}]}";
        String resolved=mvc.perform(post("/rest/apicenter/visit/web/visitCenter/batchResolveAiVisitSlot").contentType(MediaType.APPLICATION_JSON).content(slots)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(resolved).path("data").path("fsmState").asText()).isEqualTo("CONFIRMING");
        String execute="{"+common+",\"turnId\":\"agent-turn-1\"}";
        String created=mvc.perform(post("/rest/apicenter/visit/web/visitCenter/executeAiVisitAction").contentType(MediaType.APPLICATION_JSON).content(execute)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(created).path("data").path("planId").asLong()).isPositive();
    }

    @Test
    void localTravelDraftCanBeQueriedAndSupplemented() throws Exception {
        String user = "travel-tester-" + System.nanoTime();
        String applyNo = "TA-" + System.nanoTime();
        mvc.perform(post("/api/v1/travel-applications").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"travelApplyNo\":\"" + applyNo + "\",\"cities\":[\"北京\",\"上海\"],\"startTime\":\"2032-03-01\",\"endTime\":\"2032-03-03\"}"))
                .andExpect(status().isOk());
        String draft = mvc.perform(post("/api/v1/travel-plan-drafts").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"travelApplyNo\":\"" + applyNo + "\",\"planTime\":\"2032-03-01T02:00:00Z\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        String id = json.readTree(draft).path("data").path("visitPlanId").asText();

        String pending = mvc.perform(post("/rest/apicenter/visit/web/visitCenter/queryAiVisit")
                        .header("X-User-Id", user).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"queryType\":\"pending_travel\",\"param\":\"上海\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(pending).path("data").path("dataJson").asText()).contains(id, applyNo);

        String supplement = "{\"visitPlanIdStr\":\"" + id + "\",\"visitType\":\"travel\",\"visitObjectType\":\"ad_customer\","
                + "\"customerType\":\"old\",\"visitObjectInfo\":{\"licenseCode\":\"cust-travel-1\",\"licenseName\":\"上海示例客户\"},"
                + "\"visitPurpose\":\"customer_maintenance\",\"planVisitTime\":\"2032-03-01 10:00:00\","
                + "\"planVisitAddress\":\"上海市徐汇区\",\"travelApplyNo\":\"" + applyNo + "\"}";
        String updated = mvc.perform(post("/rest/apicenter/visit/web/visitCenter/updateVisitPlan")
                        .header("X-User-Id", user).contentType(MediaType.APPLICATION_JSON).content(supplement))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(updated).path("data").path("status").asText()).isEqualTo("PLANNED");

        String list = mvc.perform(post("/rest/apicenter/visit/app/visitAi/visitNew/queryVisitPlanListApp")
                        .header("X-User-Id", user).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"filterCondition\":[{\"key\":\"clockStatus\",\"value\":[\"0\"]}],\"pageInfo\":{\"pageSize\":20}}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(list).path("data").path("dataRow").toString()).contains(id, "ad_customer");
    }

    @Test
    void skillContactEndpointsCreateAndQueryMasterContact() throws Exception {
        String objectId = "contact-object-" + System.nanoTime();
        String add = "{\"objectType\":\"ad_customer\",\"objectId\":\"" + objectId + "\",\"objectName\":\"联系人测试客户\","
                + "\"contact\":{\"name\":\"王经理\",\"phone\":\"13800000000\",\"isKp\":1}}";
        mvc.perform(post("/rest/apicenter/visit/web/visitNew/addOrUpdateContact")
                        .contentType(MediaType.APPLICATION_JSON).content(add))
                .andExpect(status().isOk());
        String found = mvc.perform(post("/rest/apicenter/visit/web/visitNew/queryContacts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"objectType\":\"ad_customer\",\"objectId\":\"" + objectId + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(found).path("data").path("contact").toString()).contains("13800000000");
    }

    @Test
    void featureAmuVisitCreateContractPersistsTargetCustomerAndConversation() throws Exception {
        String user = "mobile-create-" + System.nanoTime();
        mvc.perform(get("/api/visit/health"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"));
        String bootstrap = mvc.perform(get("/api/visit/bootstrap").header("X-User-Id", user))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(bootstrap).path("purposes").isArray()).isTrue();

        String conversation = mvc.perform(post("/api/visit/conversations").header("X-User-Id", user))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String conversationId = json.readTree(conversation).path("id").asText();
        String started = mvc.perform(post("/api/visit/create/start").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(mapOf("conversationId", conversationId, "message", "创建拜访计划"))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String sessionId = json.readTree(started).path("session").path("id").asText();
        assertThat(json.readTree(started).path("card").path("type").asText()).isEqualTo("create-form");

        Map<String, Object> slots = new LinkedHashMap<>();
        slots.put("visitType", "local"); slots.put("visitObjectType", "ad_customer"); slots.put("customerType", "new");
        slots.put("adIsTarget", mapOf("isTargetCustomer", true, "label", "是"));
        slots.put("visitObjectInfo", mapOf("licenseCode", "mobile-customer-1", "licenseName", "移动端新客户"));
        slots.put("visitPurpose", mapOf("value", "customer_maintenance", "label", "客情维护"));
        slots.put("planVisitTime", "2033-01-01T10:00");
        slots.put("planVisitAddress", mapOf("address", "移动端测试地址", "longitude", 116.3, "latitude", 40.05));
        String resolved = mvc.perform(post("/api/visit/create/resolve").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(mapOf("sessionId", sessionId, "conversationId", conversationId,
                                "slots", slots, "displayText", "提交拜访计划信息"))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(resolved).path("card").path("type").asText()).isEqualTo("confirm");

        String confirmed = mvc.perform(post("/api/visit/create/confirm").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(mapOf("sessionId", sessionId, "conversationId", conversationId))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(confirmed).path("card").path("data").path("planTime").asText())
                .isEqualTo("2033-01-01T10:00");
        long planId = json.readTree(confirmed).path("card").path("data").path("visitPlanId").asLong();
        String detail = mvc.perform(get("/api/v1/visits/" + planId).header("X-User-Id", user)).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(detail).path("data").path("adIsTarget").asBoolean()).isTrue();

        String history = mvc.perform(get("/api/visit/conversations/" + conversationId).header("X-User-Id", user))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(history).path("conversation").path("messages").size()).isGreaterThanOrEqualTo(6);
    }

    @Test
    void pureCreateIntentShowsBlankFormButMessageWithSlotsStartsGuidedCollection() throws Exception {
        String user = "guided-create-" + System.nanoTime();
        String conversation = mvc.perform(post("/api/visit/conversations").header("X-User-Id", user))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String conversationId = json.readTree(conversation).path("id").asText();

        String pure = mvc.perform(post("/api/visit/create/start").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(mapOf("conversationId", conversationId, "message", "创建拜访计划"))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(pure).path("card").path("type").asText()).isEqualTo("create-form");

        String guidedConversation = mvc.perform(post("/api/visit/conversations").header("X-User-Id", user))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String guidedId = json.readTree(guidedConversation).path("id").asText();
        String guided = mvc.perform(post("/api/visit/create/start").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(mapOf("conversationId", guidedId,
                                "message", "创建一个明天上午10点的本地广告客户老客拜访计划，拜访目的客情维护"))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        JsonNode result = json.readTree(guided);
        assertThat(result.path("card").path("type").asText()).isIn("ask", "candidates");
        assertThat(result.path("card").path("type").asText()).isNotEqualTo("create-form");
        assertThat(result.path("session").path("slots").path("visitType").asText()).isEqualTo("local");
        assertThat(result.path("session").path("slots").path("visitObjectType").asText()).isEqualTo("ad_customer");
        assertThat(result.path("session").path("slots").path("customerType").asText()).isEqualTo("old");
        assertThat(result.path("session").path("slots").path("visitPurpose").path("value").asText()).isEqualTo("customer_maintenance");
    }

    @Test
    void customerHintSearchesAcrossObjectTypesBeforeOtherMissingFields() throws Exception {
        String user = "customer-hint-" + System.nanoTime();
        when(customerSearch.search("华北区", null, 5)).thenReturn(Arrays.asList(
                mapOf("id", "north-1", "name", "华北区域客户一", "objectType", "ad_customer", "address", "北京"),
                mapOf("id", "north-2", "name", "华北区域门店二", "objectType", "store", "address", "天津")));
        String conversation = mvc.perform(post("/api/visit/conversations").header("X-User-Id", user))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String conversationId = json.readTree(conversation).path("id").asText();

        String started = mvc.perform(post("/api/visit/create/start").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(mapOf("conversationId", conversationId,
                                "message", "要创建拜访计划。客户是华北区。"))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        JsonNode result = json.readTree(started);
        assertThat(result.path("message").asText()).contains("多个匹配项");
        assertThat(result.path("card").path("type").asText()).isEqualTo("candidates");
        assertThat(result.path("card").path("data").path("slotName").asText()).isEqualTo("visitObjectInfo");
        assertThat(result.path("card").path("candidates").size()).isEqualTo(2);
        assertThat(result.path("card").path("candidates").get(0).path("title").asText()).isEqualTo("华北区域客户一");
    }

    @Test
    void mobileCustomerPickerUsesRealtimeCrossTypeVectorSearch() throws Exception {
        when(customerSearch.search("华北区域", null, 8)).thenReturn(Arrays.asList(
                mapOf("id", "agent-001", "name", "华北区域代理商", "objectType", "agent",
                        "address", "北京市朝阳区", "city", "北京", "similarity", 0.672D)));

        mvc.perform(get("/api/visit/customers/search")
                        .param("q", "华北区域")
                        .param("limit", "8"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.list[0].id").value("agent-001"))
                .andExpect(jsonPath("$.list[0].objectType").value("agent"))
                .andExpect(jsonPath("$.list[0].name").value("华北区域代理商"));

        // 未传 objectType 时必须跨类型检索，避免先选错类型后把真实客户过滤掉。
        verify(customerSearch).search("华北区域", null, 8);
    }

    @Test
    void featureAmuVisitAllowsOutOfRangeAbnormalCheckin() throws Exception {
        String user = "mobile-checkin-" + System.nanoTime();
        Map<String, Object> create = new LinkedHashMap<>();
        create.put("visitForm", "local"); create.put("objectType", "store"); create.put("customerType", "old");
        create.put("customer", mapOf("id", "mobile-store-1", "name", "移动端签到门店"));
        create.put("purpose", mapOf("code", "customer_maintenance", "label", "客情维护"));
        create.put("planTime", todayPlanTime());
        create.put("planAddress", mapOf("text", "北京市海淀区", "longitude", 116.30, "latitude", 40.05));
        String created = mvc.perform(post("/api/v1/visits").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(create)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String planId = json.readTree(created).path("data").path("id").asText();

        String started = mvc.perform(post("/api/visit/checkin/start").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"message\":\"签到\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String sessionId = json.readTree(started).path("session").path("id").asText();
        String conversationId = json.readTree(started).path("conversation").path("id").asText();
        Map<String, Object> location = mapOf("longitude", 121.47, "latitude", 31.23, "address", "上海市测试位置");
        mvc.perform(post("/api/visit/checkin/resolve").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(mapOf("sessionId", sessionId, "conversationId", conversationId,
                                "planId", planId, "location", location, "displayText", "选择签到计划"))))
                .andExpect(status().isOk());
        String checked = mvc.perform(post("/api/visit/checkin/submit").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(mapOf("sessionId", sessionId, "conversationId", conversationId,
                                "planId", planId, "location", location, "photoUrl", "local://checkin-photo"))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(json.readTree(checked).path("card").path("type").asText()).isEqualTo("checkin-success");
        assertThat(json.readTree(checked).path("card").path("data").path("checkinAbnormalReason").asText()).isNotBlank();
    }

    @Test
    void recordingSummaryAndReviewLifecycleAreUsableWithoutExternalModels() throws Exception {
        String user = "local-pipeline-" + System.nanoTime();
        Map<String, Object> create = new LinkedHashMap<>();
        create.put("visitForm", "local"); create.put("objectType", "store"); create.put("customerType", "old");
        create.put("customer", mapOf("id", "pipeline-store", "name", "本地流程测试门店"));
        create.put("purpose", mapOf("code", "meeting_review", "label", "复盘及分享"));
        create.put("planTime", todayPlanTime());
        create.put("planAddress", mapOf("text", "北京市海淀区测试地址", "longitude", 116.30, "latitude", 40.05));
        String created = mvc.perform(post("/api/v1/visits").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(create)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        long planId = json.readTree(created).path("data").path("id").asLong();

        invokeAs(user, planId, "checkin", "{\"longitude\":116.30,\"latitude\":40.05,\"address\":\"测试地址\"}", "pipeline-checkin");
        String started = invokeAs(user, planId, "recording-start", "{}", "pipeline-recording-start");
        long recordingId = json.readTree(started).path("data").path("recordingId").asLong();
        invokeAs(user, planId, "recording-stop", "{\"recordingId\":" + recordingId + ",\"transcript\":\"客户认可当前合作方案。下周补充报价并安排产品培训。\"}", "pipeline-recording-stop");

        JsonNode recording = null;
        for (int i = 0; i < 20; i++) {
            String value = mvc.perform(get("/api/v1/recordings/" + recordingId).header("X-User-Id", user))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            recording = json.readTree(value).path("data");
            if ("COMPLETED".equals(recording.path("status").asText())) break;
            Thread.sleep(25);
        }
        assertThat(recording.path("status").asText()).isEqualTo("COMPLETED");
        assertThat(recording.path("summary").asText()).isNotBlank();
        mvc.perform(get("/api/v1/recordings/" + recordingId).header("X-User-Id", "another-user"))
                .andExpect(status().isForbidden());

        invokeAs(user, planId, "checkout", "{\"longitude\":116.30,\"latitude\":40.05,\"address\":\"测试地址\"}", "pipeline-checkout");
        invokeAs(user, planId, "log", "{\"visitSummary\":\"客户认可方案，待补充报价\",\"contacts\":[{\"name\":\"张经理\",\"phone\":\"13800000000\",\"isKp\":1}]}", "pipeline-log");
        String pending = invokeAs(user, planId, "submit-review", "{}", "pipeline-submit-review");
        assertThat(json.readTree(pending).path("data").path("reviewStatus").asText()).isEqualTo("PENDING");
        String approved = invokeAs("demo-manager", planId, "approve-review", "{\"comment\":\"审核通过\"}", "pipeline-approve");
        assertThat(json.readTree(approved).path("data").path("reviewStatus").asText()).isEqualTo("APPROVED");
        String archived = invokeAs("demo-manager", planId, "archive", "{}", "pipeline-archive");
        assertThat(json.readTree(archived).path("data").path("reviewStatus").asText()).isEqualTo("ARCHIVED");
    }

    @Test
    void rejectsCheckinForNonTodayPlanEvenWhenPlanIdIsSubmittedDirectly() throws Exception {
        String user = "future-checkin-" + System.nanoTime();
        Map<String, Object> create = new LinkedHashMap<>();
        create.put("visitForm", "local"); create.put("objectType", "store"); create.put("customerType", "old");
        create.put("customer", mapOf("id", "future-store", "name", "非当日签到测试门店"));
        create.put("purpose", mapOf("code", "customer_maintenance", "label", "客情维护"));
        create.put("planTime", LocalDate.now(ZoneId.of("Asia/Shanghai")).plusDays(1).atTime(12, 0)
                .atZone(ZoneId.of("Asia/Shanghai")).toInstant().toString());
        create.put("planAddress", mapOf("text", "北京市海淀区", "longitude", 116.30, "latitude", 40.05));
        String created = mvc.perform(post("/api/v1/visits").header("X-User-Id", user)
                        .contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(create)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        long planId = json.readTree(created).path("data").path("id").asLong();

        mvc.perform(post("/api/v1/visits/" + planId + "/checkin")
                        .header("X-User-Id", user).header("Idempotency-Key", "future-checkin")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"longitude\":116.30,\"latitude\":40.05,\"address\":\"测试地址\"}"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("CHECKIN_DATE_NOT_TODAY"))
                .andExpect(jsonPath("$.message").value("只能签到当日的拜访计划"));
    }

    private static String todayPlanTime() {
        ZoneId zone = ZoneId.of("Asia/Shanghai");
        return LocalDate.now(zone).atTime(12, 0).atZone(zone).toInstant().toString();
    }

    private static Map<String, Object> mapOf(Object... values) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (int i = 0; i < values.length; i += 2) result.put(String.valueOf(values[i]), values[i + 1]);
        return result;
    }

    private String invoke(long id,String action,String body,String key)throws Exception{return mvc.perform(post("/api/v1/visits/"+id+"/"+action).header("X-User-Id","tester").header("Idempotency-Key",key).contentType(MediaType.APPLICATION_JSON).content(body)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();}
    private String invokeAs(String user,long id,String action,String body,String key)throws Exception{return mvc.perform(post("/api/v1/visits/"+id+"/"+action).header("X-User-Id",user).header("Idempotency-Key",key).contentType(MediaType.APPLICATION_JSON).content(body)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();}
}
