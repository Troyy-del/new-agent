package com.locallife.visit.integration;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.locallife.visit.config.MilvusProperties;
import com.locallife.visit.support.BizException;
import io.milvus.v2.client.MilvusClientV2;
import io.milvus.v2.common.IndexParam;
import io.milvus.v2.service.vector.request.SearchReq;
import io.milvus.v2.service.vector.request.UpsertReq;
import io.milvus.v2.service.vector.request.DeleteReq;
import io.milvus.v2.service.vector.request.QueryReq;
import io.milvus.v2.service.vector.request.data.FloatVec;
import io.milvus.v2.service.vector.response.QueryResp;
import io.milvus.v2.service.vector.response.SearchResp;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.*;

@Component
@ConditionalOnProperty(prefix = "visit.milvus", name = "enabled", havingValue = "true")
public class MilvusCustomerVectorStore {
    private static final Set<String> TYPES = new HashSet<>(Arrays.asList("ad_customer", "store", "agent", "provider"));
    private static final List<String> OUTPUT_FIELDS = Arrays.asList("customer_id", "object_type", "standard_name", "address", "city");
    private final MilvusClientV2 client;
    private final MilvusProperties properties;
    private final Gson gson = new Gson();

    public MilvusCustomerVectorStore(@Lazy MilvusClientV2 client, MilvusProperties properties) {
        this.client = client;
        this.properties = properties;
    }

    public void upsert(String id, String objectType, String name, String aliases, String address,
                       String city, boolean active, List<Float> embedding) {
        validateVector(embedding);
        if (!TYPES.contains(objectType))
            throw new BizException("INVALID_OBJECT_TYPE", "不支持的客户类型: " + objectType);
        JsonObject row = new JsonObject();
        row.addProperty("customer_id", required(id, "customerId"));
        row.addProperty("object_type", objectType);
        row.addProperty("standard_name", required(name, "standardName"));
        row.addProperty("aliases", value(aliases));
        row.addProperty("address", value(address));
        row.addProperty("city", value(city));
        row.addProperty("active", active);
        row.addProperty("updated_at", Instant.now().toEpochMilli());
        row.add("embedding", gson.toJsonTree(embedding));
        client.upsert(UpsertReq.builder().databaseName(properties.getDatabase()).collectionName(properties.getCollection())
                .data(Collections.singletonList(row)).build());
    }

    public List<CustomerVectorHit> search(List<Float> vector, String objectType, int limit) {
        validateVector(vector);
        if (objectType != null && !TYPES.contains(objectType))
            throw new BizException("INVALID_OBJECT_TYPE", "不支持的客户类型: " + objectType);
        String filter = objectType == null ? "active == true" : "active == true && object_type == \"" + objectType + "\"";
        SearchResp response = client.search(SearchReq.builder().databaseName(properties.getDatabase())
                .collectionName(properties.getCollection()).annsField("embedding")
                .metricType(IndexParam.MetricType.COSINE).filter(filter).limit(Math.max(1, Math.min(limit, 100)))
                .outputFields(OUTPUT_FIELDS).data(Collections.singletonList(new FloatVec(vector))).build());
        List<CustomerVectorHit> hits = new ArrayList<>();
        if (response.getSearchResults().isEmpty()) return hits;
        for (SearchResp.SearchResult result : response.getSearchResults().get(0)) {
            Map<String, Object> entity = result.getEntity();
            CustomerVectorHit hit = new CustomerVectorHit();
            hit.customerId = text(entity.get("customer_id"));
            hit.objectType = text(entity.get("object_type"));
            hit.standardName = text(entity.get("standard_name"));
            hit.address = text(entity.get("address"));
            hit.city = text(entity.get("city"));
            hit.score = result.getScore();
            hits.add(hit);
        }
        return hits;
    }

    public List<CustomerVectorHit> list(String objectType, int limit) {
        if (objectType != null && !TYPES.contains(objectType))
            throw new BizException("INVALID_OBJECT_TYPE", "不支持的客户类型: " + objectType);
        String filter = objectType == null ? "active == true" : "active == true && object_type == \"" + objectType + "\"";
        QueryResp response = client.query(QueryReq.builder().databaseName(properties.getDatabase())
                .collectionName(properties.getCollection()).filter(filter)
                .limit(Math.max(1, Math.min(limit, 100))).outputFields(OUTPUT_FIELDS).build());
        List<CustomerVectorHit> hits = new ArrayList<>();
        for (QueryResp.QueryResult result : response.getQueryResults()) {
            hits.add(toHit(result.getEntity(), 0f));
        }
        return hits;
    }

    public void delete(String customerId) {
        client.delete(DeleteReq.builder().databaseName(properties.getDatabase())
                .collectionName(properties.getCollection())
                .ids(Collections.singletonList(required(customerId, "customerId"))).build());
    }

    private void validateVector(List<Float> vector) {
        if (properties.getDimension() <= 0) {
            throw new BizException("MILVUS_DIMENSION_REQUIRED", "向量读写前必须配置与 embedding 模型一致的 MILVUS_DIMENSION");
        }
        if (vector == null || vector.size() != properties.getDimension())
            throw new BizException("INVALID_EMBEDDING_DIMENSION", "向量维度必须为 " + properties.getDimension());
    }

    private static CustomerVectorHit toHit(Map<String, Object> entity, float score) {
        CustomerVectorHit hit = new CustomerVectorHit();
        hit.customerId = text(entity.get("customer_id"));
        hit.objectType = text(entity.get("object_type"));
        hit.standardName = text(entity.get("standard_name"));
        hit.address = text(entity.get("address"));
        hit.city = text(entity.get("city"));
        hit.score = score;
        return hit;
    }

    private static String required(String value, String name) {
        if (value == null || value.trim().isEmpty()) throw new BizException("MISSING_ARGUMENT", name + "不能为空");
        return value;
    }

    private static String value(String value) {
        return value == null ? "" : value;
    }

    private static String text(Object value) {
        return value == null ? null : String.valueOf(value);
    }
}
