package com.locallife.visit.api;

import com.locallife.visit.service.VisitContractService;
import com.locallife.visit.support.ApiResponse;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** HTTP endpoints kept compatible with the original visit-assistant skill scripts. */
@RestController
@RequestMapping({"/rest/apicenter/crm", "/rest/apicenter/visit"})
public class VisitSkillContractController {
    private final VisitContractService contracts;

    public VisitSkillContractController(VisitContractService contracts) {
        this.contracts = contracts;
    }

    @PostMapping("/app/visitAi/visitNew/queryVisitPlanListApp")
    public Map<String, Object> listApp(@RequestBody Map<String, Object> body,
                                       @RequestHeader(value = "X-User-Id", required = false) String headerUser) {
        return ApiResponse.ok(contracts.list(user(body, headerUser), body));
    }

    @PostMapping("/app/visitAi/visitCenter/preCheckCheckout")
    public Map<String, Object> preCheckCheckout(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(contracts.preCheckCheckout(body));
    }

    @PostMapping("/app/visitAi/visitCenter/submitCheckout")
    public Map<String, Object> submitCheckout(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(contracts.submitCheckout(body));
    }

    @PostMapping("/web/visitNew/queryContacts")
    public Map<String, Object> queryContacts(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("contact", contracts.contacts(text(first(body, "objectType", "visitObject")),
                text(first(body, "objectId", "targetCustomerId", "businessLicenseCode"))));
        result.put("wechatContact", Collections.emptyList());
        return ApiResponse.ok(result);
    }

    @SuppressWarnings("unchecked")
    @PostMapping("/web/visitNew/addOrUpdateContact")
    public Map<String, Object> addOrUpdateContact(@RequestBody Map<String, Object> body) {
        Object value = body.get("contact");
        Map<String, Object> contact = value instanceof Map ? new LinkedHashMap<>((Map<String, Object>) value) : new LinkedHashMap<>(body);
        return ApiResponse.ok(contracts.saveContact(
                text(first(body, "objectType", "visitObject")),
                text(first(body, "objectId", "targetCustomerId", "businessLicenseCode")),
                text(first(body, "objectName", "targetCustomerName", "businessLicense")), contact));
    }

    @PostMapping("/web/visitNew/checkVisitSupplementAllowed")
    public Map<String, Object> supplementAllowed(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(contracts.supplementAllowed(id(body)));
    }

    @PostMapping("/web/visitNew/submitLaterCheckin")
    public Map<String, Object> submitSupplement(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(contracts.supplementCheckout(id(body)));
    }

    @PostMapping("/web/visit/new/work/fillVisitLog")
    public Map<String, Object> fillVisitLog(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(contracts.fillLog(body));
    }

    @PostMapping("/app/visitAi/visitCenter/getLlmStatus")
    public Map<String, Object> llmStatus(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(contracts.llmStatus(id(body)));
    }

    @PostMapping("/app/visitAi/visitCenter/getAudioRecordDetail")
    public Map<String, Object> audioDetail(@RequestBody Map<String, Object> body) {
        return ApiResponse.ok(contracts.audioDetail(id(body)));
    }

    private static long id(Map<String, Object> body) {
        Object value = first(body, "visitPlanIdStr", "visitPlanId", "visitId", "id");
        if (value == null) throw new IllegalArgumentException("拜访计划ID不能为空");
        return Long.parseLong(String.valueOf(value));
    }

    private static String user(Map<String, Object> body, String header) {
        if (header != null && !header.trim().isEmpty()) return header;
        Object value = first(body, "userId", "creatorEmail", "creatorId");
        if (value == null && body.get("baseRequest") instanceof Map)
            value = first((Map<?, ?>) body.get("baseRequest"), "user_name", "userName", "userId");
        return value == null ? "demo-user" : String.valueOf(value);
    }

    private static Object first(Map<?, ?> body, String... keys) {
        for (String key : keys) if (body.get(key) != null) return body.get(key);
        return null;
    }

    private static String text(Object value) { return value == null ? null : String.valueOf(value); }
}
