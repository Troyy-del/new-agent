package com.locallife.visit.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.integration.AsrGateway;
import com.locallife.visit.integration.SummaryGateway;
import com.locallife.visit.repository.SupportingRepository;
import com.locallife.visit.support.BizException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

@Service
public class RecordingPipelineService {
    private final StringRedisTemplate redis;
    private final SupportingRepository supporting;
    private final AsrGateway asr;
    private final SummaryGateway summaries;
    private final ObjectMapper json;
    private final Executor taskExecutor;

    public RecordingPipelineService(StringRedisTemplate redis, SupportingRepository supporting,
                                    AsrGateway asr, SummaryGateway summaries, ObjectMapper json,
                                    @Qualifier("applicationTaskExecutor") Executor taskExecutor) {
        this.redis=redis; this.supporting=supporting; this.asr=asr; this.summaries=summaries; this.json=json; this.taskExecutor=taskExecutor;
    }

    public void appendFragment(long recordingId, String text) {
        if (text == null || text.trim().isEmpty()) throw new BizException("EMPTY_ASR_FRAGMENT", "转写片段不能为空");
        String key=key(recordingId); redis.opsForList().rightPush(key,text.trim()); redis.expire(key, Duration.ofHours(24));
    }

    public void finish(long recordingId, String user, String audioUrl, String suppliedTranscript) {
        supporting.markRecordingProcessing(recordingId,audioUrl);
        taskExecutor.execute(() -> process(recordingId,user,audioUrl,suppliedTranscript));
    }

    void process(long recordingId, String user, String audioUrl, String suppliedTranscript) {
        try {
            String transcript=normalize(suppliedTranscript);
            if(transcript==null) transcript=fragments(recordingId);
            if(transcript==null) transcript=normalize(asr.transcribe(audioUrl));
            if(transcript==null) { supporting.markRecordingWaitingExternal(recordingId); return; }
            String summary=summaries.summarize(transcript);
            supporting.completeRecording(recordingId,audioUrl,transcript,summary);
            Map<String,Object> payload=new LinkedHashMap<>(); payload.put("recordingId",recordingId); payload.put("summaryReady",summary!=null);
            supporting.enqueueNotification(user,"VISIT_SUMMARY_READY",String.valueOf(recordingId),json.writeValueAsString(payload));
            redis.delete(key(recordingId));
        } catch(Exception e) { supporting.failRecording(recordingId, safeMessage(e)); }
    }

    private String fragments(long id) { List<String> values=redis.opsForList().range(key(id),0,-1); return values==null||values.isEmpty()?null:normalize(String.join("\n",values)); }
    private static String key(long id){return "visit:recording:fragments:"+id;}
    private static String normalize(String value){return value==null||value.trim().isEmpty()?null:value.trim();}
    private static String safeMessage(Exception e){String value=e.getMessage(); if(value==null)value=e.getClass().getSimpleName(); return value.substring(0,Math.min(900,value.length()));}
}
