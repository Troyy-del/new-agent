package com.locallife.visit.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.domain.CustomerChangeEvent;
import com.locallife.visit.domain.CustomerFileRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(prefix = "visit.customer-sync", name = "enabled", havingValue = "true")
public class CustomerKafkaConsumer {
    private static final Logger log = LoggerFactory.getLogger(CustomerKafkaConsumer.class);
    private final ObjectMapper json;
    private final MilvusEmbeddingClient embeddings;
    private final MilvusCustomerVectorStore vectors;

    public CustomerKafkaConsumer(ObjectMapper json, MilvusEmbeddingClient embeddings,
                                 MilvusCustomerVectorStore vectors) {
        this.json=json; this.embeddings=embeddings; this.vectors=vectors;
    }

    @KafkaListener(topics = "${visit.customer-sync.topic}", groupId = "${visit.customer-sync.consumer-group}",
            containerFactory = "customerKafkaListenerContainerFactory")
    public void consume(String payload) throws Exception {
        // 反序列化
        CustomerChangeEvent event = json.readValue(payload, CustomerChangeEvent.class);
        // 参数校验
        validate(event);
        // 删除数据
        if ("DISABLE".equals(event.eventType)) disable(event);
        // 1、根据客户信息 emb   2、 连同 emb 一同写入 milvus
        else upsert(event);
        log.info("Consumed customer event {} {}", event.eventType, event.customerId);
    }

    private void upsert(CustomerChangeEvent event) {
        // embeddings.embed(text))  性能瓶颈
        // 存量 2000w：上游的 hive 表，维护的一批 客户信息  存量 2000w，每天增量(insert/update) 5w   5qps,3h写完
        // 一开始 写 qps: 5   存量 2000w 数据  写入时间: 46天     遇到的问题：1. 时间太长业务不接受  2. 丢数据
        // 加资源：申请了更高性能大算力 x40 卡 or 升级了服务(加钱了) qps: 40   存量 2000w  写入时间: 6天    向 kafka 侧申请 broker 保留时长 6h -> 8d

        CustomerFileRecord record = event.data;
        String text = record.name + "；别名：" + record.aliasesText() + "；地址：" + value(record.address) + "；城市：" + value(record.city);
        vectors.upsert(record.id, record.objectType, record.name, record.aliasesText(), record.address, record.city,
                record.active, embeddings.embed(text));
    }

    private void disable(CustomerChangeEvent event) {
        vectors.delete(event.customerId);
    }

    // 参数校验
    private static void validate(CustomerChangeEvent event) {
        if (event == null || event.eventId == null || event.customerId == null || event.data == null)
            throw new IllegalArgumentException("Invalid customer change event");
        if (!"UPSERT".equals(event.eventType) && !"DISABLE".equals(event.eventType))
            throw new IllegalArgumentException("Unsupported customer event type: " + event.eventType);
    }
    private static String value(String value) { return value == null ? "" : value; }
}
