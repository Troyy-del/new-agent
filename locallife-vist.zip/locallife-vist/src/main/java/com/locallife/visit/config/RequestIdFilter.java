package com.locallife.visit.config;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

@Component
public class RequestIdFilter extends OncePerRequestFilter {
    @Override protected void doFilterInternal(HttpServletRequest request,HttpServletResponse response,FilterChain chain)throws ServletException,IOException{
        String id=request.getHeader("X-Request-Id"); if(id==null||id.trim().isEmpty())id=UUID.randomUUID().toString();
        MDC.put("requestId",id); response.setHeader("X-Request-Id",id);
        try{chain.doFilter(request,response);}finally{MDC.remove("requestId");}
    }
}
