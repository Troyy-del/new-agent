package com.locallife.visit.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.Ordered;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Loads local development credentials from macOS Keychain before Spring binds
 * configuration properties. Explicit environment variables always win.
 */
public class LocalKeychainEnvironmentPostProcessor implements EnvironmentPostProcessor, Ordered {
    static final String ASR_ACCOUNT = "locallife-visit-asr";
    static final String MILVUS_ACCOUNT = "locallife-visit-milvus";

    @Override
    public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
        if (!isMac()) return;

        Map<String, Object> credentials = new LinkedHashMap<>();
        addIfMissing(environment, credentials, "ALIYUN_AK_ID", ASR_ACCOUNT,
                "locallife-visit-asr-access-key-id");
        addIfMissing(environment, credentials, "ALIYUN_AK_SECRET", ASR_ACCOUNT,
                "locallife-visit-asr-access-key-secret");
        addIfMissing(environment, credentials, "MILVUS_PASSWORD", MILVUS_ACCOUNT,
                "locallife-visit-milvus-password");

        if (!credentials.isEmpty()) {
            environment.getPropertySources().addFirst(new MapPropertySource("localMacKeychainCredentials", credentials));
        }
    }

    private void addIfMissing(ConfigurableEnvironment environment, Map<String, Object> target,
                              String property, String account, String service) {
        if (hasText(environment.getProperty(property))) return;
        String value = readKeychain(account, service);
        if (hasText(value)) target.put(property, value);
    }

    private String readKeychain(String account, String service) {
        File security = new File("/usr/bin/security");
        if (!security.isFile()) return null;
        Process process = null;
        try {
            process = new ProcessBuilder(security.getAbsolutePath(), "find-generic-password",
                    "-a", account, "-s", service, "-w")
                    .redirectErrorStream(true)
                    .start();
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            copy(process.getInputStream(), output);
            if (!process.waitFor(5, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return null;
            }
            return process.exitValue() == 0 ? output.toString(StandardCharsets.UTF_8.name()).trim() : null;
        } catch (IOException e) {
            return null;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        } finally {
            if (process != null) process.destroy();
        }
    }

    private static void copy(InputStream input, ByteArrayOutputStream output) throws IOException {
        byte[] buffer = new byte[256];
        int read;
        while ((read = input.read(buffer)) >= 0) output.write(buffer, 0, read);
    }

    private static boolean isMac() {
        String osName = System.getProperty("os.name", "");
        return osName.toLowerCase().contains("mac");
    }

    private static boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }

    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }
}
