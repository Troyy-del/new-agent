package com.locallife.visit.domain;

public enum FsmState {
    PENDING, FILLING, CONFIRMING, CONFIRMED, EXECUTING, DONE, CANCELED, FALLBACK
}
