package com.locallife.visit.domain;

public enum PlanStatus {
    PENDING_SUPPLEMENT, PLANNED, CHECKED_IN, CHECKED_OUT, LOGGED, CANCELED;

    public boolean writable() {
        return this != LOGGED && this != CANCELED;
    }
}
