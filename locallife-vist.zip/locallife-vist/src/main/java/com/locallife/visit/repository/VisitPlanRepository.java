package com.locallife.visit.repository;

import com.locallife.visit.domain.PlanStatus;
import com.locallife.visit.domain.ReviewStatus;
import com.locallife.visit.domain.VisitPlan;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class VisitPlanRepository {
    private final JdbcTemplate jdbc;

    public VisitPlanRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Optional<VisitPlan> find(long id) {
        return jdbc.query("SELECT * FROM visit_plan WHERE id=?", this::map, id).stream().findFirst();
    }

    public List<VisitPlan> findByCreator(String creator, String keyword, List<PlanStatus> statuses, int limit) {
        StringBuilder sql = new StringBuilder("SELECT * FROM visit_plan WHERE creator_id=?");
        List<Object> args = new ArrayList<>();
        args.add(creator);
        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (LOWER(customer_name) LIKE ? OR LOWER(plan_address) LIKE ? OR LOWER(purpose_label) LIKE ?)");
            String q = "%" + keyword.toLowerCase() + "%";
            args.add(q);
            args.add(q);
            args.add(q);
        }
        if (statuses != null && !statuses.isEmpty()) {
            sql.append(" AND status IN (");
            for (int i = 0; i < statuses.size(); i++) {
                if (i > 0) sql.append(',');
                sql.append('?');
                args.add(statuses.get(i).name());
            }
            sql.append(')');
        }
        sql.append(" ORDER BY plan_time DESC LIMIT ?");
        args.add(Math.max(1, Math.min(limit, 100)));
        return jdbc.query(sql.toString(), this::map, args.toArray());
    }

    public void insert(VisitPlan p) {
        jdbc.update("INSERT INTO visit_plan(id,creator_id,visit_form,object_type,customer_id,customer_name,customer_type,ad_is_target,purpose_code,purpose_label,plan_time,plan_address,longitude,latitude,companions_json,travel_apply_id,status,version,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                p.id, p.creatorId, p.visitForm, p.objectType, p.customerId, p.customerName, p.customerType, p.adIsTarget, p.purposeCode, p.purposeLabel, ts(p.planTime), p.planAddress, p.longitude, p.latitude, p.companionsJson, p.travelApplyId, p.status.name(), 0, ts(p.createdAt), ts(p.updatedAt));
    }

    public void updatePlan(VisitPlan p) {
        PlanStatus nextStatus = p.status == PlanStatus.PENDING_SUPPLEMENT ? PlanStatus.PLANNED : p.status;
        int changed = jdbc.update("UPDATE visit_plan SET visit_form=?,object_type=?,customer_id=?,customer_name=?,customer_type=?,ad_is_target=?,purpose_code=?,purpose_label=?,plan_time=?,plan_address=?,longitude=?,latitude=?,companions_json=?,travel_apply_id=?,status=?,version=version+1,updated_at=? WHERE id=? AND version=? AND status IN ('PLANNED','PENDING_SUPPLEMENT')",
                p.visitForm, p.objectType, p.customerId, p.customerName, p.customerType, p.adIsTarget, p.purposeCode, p.purposeLabel, ts(p.planTime), p.planAddress, p.longitude, p.latitude, p.companionsJson, p.travelApplyId, nextStatus.name(), ts(Instant.now()), p.id, p.version);
        if (changed == 0) throw new org.springframework.dao.OptimisticLockingFailureException("计划状态或版本已变化");
        p.status = nextStatus;
        p.version++;
    }

    public void markStatus(long id, long version, PlanStatus from, PlanStatus to, String address, Double lng, Double lat) {
        String prefix;
        if (to == PlanStatus.CHECKED_IN)
            prefix = "checkin_time=CURRENT_TIMESTAMP,checkin_address=?,checkin_longitude=?,checkin_latitude=?,";
        else if (to == PlanStatus.CHECKED_OUT)
            prefix = "checkout_time=CURRENT_TIMESTAMP,checkout_address=?,checkout_longitude=?,checkout_latitude=?,";
        else prefix = "";
        Object[] args = prefix.isEmpty()
                ? new Object[]{to.name(), id, version, from.name()}
                : new Object[]{address, lng, lat, to.name(), id, version, from.name()};
        int changed = jdbc.update("UPDATE visit_plan SET " + prefix + "status=?,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND version=? AND status=?", args);
        if (changed == 0)
            throw new org.springframework.dao.OptimisticLockingFailureException("非法状态迁移或计划已被修改");
    }

    public void markCheckin(long id, long version, String address, Double lng, Double lat,
                            String abnormalReason, String photoUrl) {
        int changed = jdbc.update("UPDATE visit_plan SET checkin_time=CURRENT_TIMESTAMP,checkin_address=?,checkin_longitude=?,checkin_latitude=?,checkin_abnormal_reason=?,checkin_photo_url=?,status='CHECKED_IN',version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND version=? AND status='PLANNED'",
                address, lng, lat, abnormalReason, photoUrl, id, version);
        if (changed == 0) throw new org.springframework.dao.OptimisticLockingFailureException("非法签到或计划已被修改");
    }

    public void saveLog(long id, long version, String summary, String contactsJson) {
        int changed = jdbc.update("UPDATE visit_plan SET visit_summary=?,contacts_json=?,status='LOGGED',review_status='DRAFT',reviewer_id=NULL,review_comment=NULL,reviewed_at=NULL,archived_at=NULL,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND version=? AND status IN ('CHECKED_OUT','LOGGED') AND review_status<>'ARCHIVED'", summary, contactsJson, id, version);
        if (changed == 0) throw new org.springframework.dao.OptimisticLockingFailureException("仅已签退计划可填写或修改日志");
    }

    public void submitReview(long id, long version) {
        changeReview(id, version, "review_status IN ('DRAFT','REJECTED') AND status='LOGGED'",
                "review_status='PENDING',reviewer_id=NULL,review_comment=NULL,reviewed_at=NULL", "当前日志不可提交审核");
    }

    public void approveReview(long id, long version, String reviewer, String comment) {
        int changed = jdbc.update("UPDATE visit_plan SET review_status='APPROVED',reviewer_id=?,review_comment=?,reviewed_at=CURRENT_TIMESTAMP,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND version=? AND review_status='PENDING' AND status='LOGGED'",
                reviewer, comment, id, version);
        if (changed == 0) throw new org.springframework.dao.OptimisticLockingFailureException("当前日志不可审核通过");
    }

    public void rejectReview(long id, long version, String reviewer, String comment) {
        int changed = jdbc.update("UPDATE visit_plan SET review_status='REJECTED',reviewer_id=?,review_comment=?,reviewed_at=CURRENT_TIMESTAMP,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND version=? AND review_status='PENDING' AND status='LOGGED'",
                reviewer, comment, id, version);
        if (changed == 0) throw new org.springframework.dao.OptimisticLockingFailureException("当前日志不可驳回");
    }

    public void archive(long id, long version) {
        changeReview(id, version, "review_status='APPROVED' AND status='LOGGED'",
                "review_status='ARCHIVED',archived_at=CURRENT_TIMESTAMP", "只有审核通过的日志可以归档");
    }

    private void changeReview(long id, long version, String condition, String update, String message) {
        int changed = jdbc.update("UPDATE visit_plan SET " + update + ",version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND version=? AND " + condition, id, version);
        if (changed == 0) throw new org.springframework.dao.OptimisticLockingFailureException(message);
    }

    public void supplementCheckout(long id, long version, String address) {
        int changed = jdbc.update("UPDATE visit_plan SET checkout_time=CURRENT_TIMESTAMP,checkout_address=?,checkout_longitude=checkin_longitude,checkout_latitude=checkin_latitude,status='CHECKED_OUT',supplemented=TRUE,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND version=? AND status='CHECKED_IN'", address, id, version);
        if (changed == 0) throw new org.springframework.dao.OptimisticLockingFailureException("当前计划不可补录签退");
    }

    public List<VisitPlan> findByFilters(String creator, List<PlanStatus> statuses, Instant planStart, Instant planEnd,
                                         Instant checkinStart, Instant checkinEnd, int limit) {
        StringBuilder sql = new StringBuilder("SELECT * FROM visit_plan WHERE creator_id=?");
        List<Object> args = new ArrayList<>();
        args.add(creator);
        if (statuses != null && !statuses.isEmpty()) {
            sql.append(" AND status IN (");
            for (int i = 0; i < statuses.size(); i++) {
                if (i > 0) sql.append(',');
                sql.append('?');
                args.add(statuses.get(i).name());
            }
            sql.append(')');
        }
        if (planStart != null) { sql.append(" AND plan_time>=?"); args.add(ts(planStart)); }
        if (planEnd != null) { sql.append(" AND plan_time<=?"); args.add(ts(planEnd)); }
        if (checkinStart != null) { sql.append(" AND checkin_time>=?"); args.add(ts(checkinStart)); }
        if (checkinEnd != null) { sql.append(" AND checkin_time<=?"); args.add(ts(checkinEnd)); }
        sql.append(" ORDER BY COALESCE(checkin_time,plan_time) DESC LIMIT ?");
        args.add(Math.max(1, Math.min(limit, 100)));
        return jdbc.query(sql.toString(), this::map, args.toArray());
    }

    public void insertPendingTravel(VisitPlan p) {
        jdbc.update("INSERT INTO visit_plan(id,creator_id,visit_form,plan_time,companions_json,travel_apply_id,status,version,created_at,updated_at) VALUES(?,?,'travel',?,'[]',?,'PENDING_SUPPLEMENT',0,?,?)",
                p.id, p.creatorId, ts(p.planTime), p.travelApplyId, ts(p.createdAt), ts(p.updatedAt));
    }

    private VisitPlan map(ResultSet rs, int row) throws SQLException {
        VisitPlan p = new VisitPlan();
        p.id = rs.getLong("id");
        p.creatorId = rs.getString("creator_id");
        p.visitForm = rs.getString("visit_form");
        p.objectType = rs.getString("object_type");
        p.customerId = rs.getString("customer_id");
        p.customerName = rs.getString("customer_name");
        p.customerType = rs.getString("customer_type");
        Object target = rs.getObject("ad_is_target");
        p.adIsTarget = target == null ? null : rs.getBoolean("ad_is_target");
        p.purposeCode = rs.getString("purpose_code");
        p.purposeLabel = rs.getString("purpose_label");
        p.planTime = instant(rs, "plan_time");
        p.planAddress = rs.getString("plan_address");
        p.longitude = number(rs, "longitude");
        p.latitude = number(rs, "latitude");
        p.companionsJson = rs.getString("companions_json");
        p.travelApplyId = rs.getString("travel_apply_id");
        p.status = PlanStatus.valueOf(rs.getString("status"));
        p.checkinTime = instant(rs, "checkin_time");
        p.checkinAddress = rs.getString("checkin_address");
        p.checkinLongitude = number(rs, "checkin_longitude");
        p.checkinLatitude = number(rs, "checkin_latitude");
        p.checkoutTime = instant(rs, "checkout_time");
        p.checkoutAddress = rs.getString("checkout_address");
        p.checkoutLongitude = number(rs, "checkout_longitude");
        p.checkoutLatitude = number(rs, "checkout_latitude");
        p.visitSummary = rs.getString("visit_summary");
        p.contactsJson = rs.getString("contacts_json");
        p.supplemented = rs.getBoolean("supplemented");
        p.checkinAbnormalReason = rs.getString("checkin_abnormal_reason");
        p.checkoutAbnormalReason = rs.getString("checkout_abnormal_reason");
        p.checkinPhotoUrl = rs.getString("checkin_photo_url");
        p.checkoutPhotoUrl = rs.getString("checkout_photo_url");
        p.reviewStatus = ReviewStatus.valueOf(rs.getString("review_status"));
        p.reviewerId = rs.getString("reviewer_id");
        p.reviewComment = rs.getString("review_comment");
        p.reviewedAt = instant(rs, "reviewed_at");
        p.archivedAt = instant(rs, "archived_at");
        p.version = rs.getLong("version");
        p.createdAt = instant(rs, "created_at");
        p.updatedAt = instant(rs, "updated_at");
        return p;
    }

    private static Timestamp ts(Instant value) {
        return value == null ? null : Timestamp.from(value);
    }

    private static Instant instant(ResultSet rs, String c) throws SQLException {
        Timestamp t = rs.getTimestamp(c);
        return t == null ? null : t.toInstant();
    }

    private static Double number(ResultSet rs, String c) throws SQLException {
        double v = rs.getDouble(c);
        return rs.wasNull() ? null : v;
    }
}
