package com.locallife.visit.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.support.BizException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

@Repository
public class VisitConversationRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper json;

    public VisitConversationRepository(JdbcTemplate jdbc, ObjectMapper json) {
        this.jdbc = jdbc;
        this.json = json;
    }

    public Map<String, Object> create(String owner) {
        String id = "visit_" + UUID.randomUUID().toString().replace("-", "");
        Instant now = Instant.now();
        jdbc.update("INSERT INTO visit_conversation(id,owner_id,title,created_at,updated_at) VALUES(?,?,?,?,?)",
                id, owner, "新建拜访会话", Timestamp.from(now), Timestamp.from(now));
        return detail(owner, id);
    }

    public List<Map<String, Object>> list(String owner) {
        return jdbc.query("SELECT * FROM visit_conversation WHERE owner_id=? ORDER BY updated_at DESC LIMIT 100",
                (rs, row) -> conversation(rs.getString("id"), rs.getString("title"), rs.getString("active_session_key"),
                        rs.getTimestamp("created_at").toInstant(), rs.getTimestamp("updated_at").toInstant(),
                        messages(rs.getString("id"))), owner);
    }

    public Map<String, Object> detail(String owner, String id) {
        List<Map<String, Object>> rows = jdbc.query("SELECT * FROM visit_conversation WHERE id=? AND owner_id=?", (rs, row) ->
                conversation(rs.getString("id"), rs.getString("title"), rs.getString("active_session_key"),
                        rs.getTimestamp("created_at").toInstant(), rs.getTimestamp("updated_at").toInstant(),
                        messages(rs.getString("id"))), id, owner);
        if (rows.isEmpty()) throw new BizException("CONVERSATION_NOT_FOUND", "拜访会话不存在", HttpStatus.NOT_FOUND);
        return rows.get(0);
    }

    public void activate(String owner, String id, String sessionKey) {
        int changed = jdbc.update("UPDATE visit_conversation SET active_session_key=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND owner_id=?",
                sessionKey, id, owner);
        if (changed == 0) throw new BizException("CONVERSATION_NOT_FOUND", "拜访会话不存在", HttpStatus.NOT_FOUND);
    }

    public void append(String owner, String conversationId, String role, String content,
                       Map<String, Object> card, String sessionKey) {
        detail(owner, conversationId);
        Instant now = Instant.now();
        jdbc.update("INSERT INTO visit_conversation_message(id,conversation_id,role,content,card_json,session_key,created_at) VALUES(?,?,?,?,CAST(? AS JSON),?,?)",
                "msg_" + UUID.randomUUID().toString().replace("-", ""), conversationId, role,
                content == null ? "" : content, card == null ? null : write(card), sessionKey, Timestamp.from(now));
        String title = "user".equals(role) && content != null && !content.trim().isEmpty()
                ? content.trim().substring(0, Math.min(content.trim().length(), 40)) : null;
        if (title == null) jdbc.update("UPDATE visit_conversation SET updated_at=? WHERE id=? AND owner_id=?", Timestamp.from(now), conversationId, owner);
        else jdbc.update("UPDATE visit_conversation SET title=IF(title='新建拜访会话',?,title),updated_at=? WHERE id=? AND owner_id=?",
                title, Timestamp.from(now), conversationId, owner);
    }

    public String activeSessionKey(Map<String, Object> conversation) {
        Object value = conversation.get("activeSessionKey");
        return value == null ? null : String.valueOf(value);
    }

    private Map<String, Object> conversation(String id, String title, String sessionKey,
                                              Instant created, Instant updated, List<Map<String, Object>> messages) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("id", id);
        result.put("title", title);
        result.put("activeSessionId", sessionKey);
        result.put("activeSessionKey", sessionKey);
        result.put("messages", messages);
        result.put("createdAt", created);
        result.put("updatedAt", updated);
        return result;
    }

    private List<Map<String, Object>> messages(String conversationId) {
        return jdbc.query("SELECT * FROM visit_conversation_message WHERE conversation_id=? ORDER BY created_at,id", (rs, row) -> {
            Map<String, Object> message = new LinkedHashMap<>();
            message.put("id", rs.getString("id"));
            message.put("role", rs.getString("role"));
            message.put("content", rs.getString("content"));
            String card = rs.getString("card_json");
            if (card != null) message.put("cardSnapshot", read(card));
            message.put("sessionId", rs.getString("session_key"));
            message.put("createdAt", rs.getTimestamp("created_at").toInstant());
            return message;
        }, conversationId);
    }

    private String write(Object value) {
        try { return json.writeValueAsString(value); }
        catch (Exception e) { throw new BizException("INVALID_JSON", "会话卡片序列化失败"); }
    }

    private Map<String, Object> read(String value) {
        try { return json.readValue(value, new TypeReference<Map<String, Object>>() { }); }
        catch (Exception e) { return Collections.emptyMap(); }
    }
}
