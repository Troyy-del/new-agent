package com.locallife.visit.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    private final VisitIdentityInterceptor identity;
    public WebMvcConfig(VisitIdentityInterceptor identity){this.identity=identity;}
    @Override public void addInterceptors(InterceptorRegistry registry){registry.addInterceptor(identity).addPathPatterns("/api/**","/rest/**").excludePathPatterns("/api/visit/health");}
}
