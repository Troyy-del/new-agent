package com.locallife.visit.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.domain.BizSession;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Repository;

import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.Optional;

/** Redis-backed conversation state with TTL and optimistic version checks. */
@Repository
public class SessionRepository {
    private static final DefaultRedisScript<Long> SAVE_SCRIPT = new DefaultRedisScript<>(
            "if redis.call('exists', KEYS[1]) == 0 then " +
                    "redis.call('hset', KEYS[1], 'version', ARGV[1], 'payload', ARGV[3]); " +
                    "redis.call('expire', KEYS[1], ARGV[5]); return 1; end; " +
                    "if redis.call('hget', KEYS[1], 'version') ~= ARGV[1] then return 0; end; " +
                    "redis.call('hset', KEYS[1], 'version', ARGV[2], 'payload', ARGV[4]); " +
                    "redis.call('expire', KEYS[1], ARGV[5]); return 2;",
            Long.class);

    private final StringRedisTemplate redis;
    private final ObjectMapper json;

    public SessionRepository(StringRedisTemplate redis, ObjectMapper json) {
        this.redis = redis;
        this.json = json;
    }

    public Optional<BizSession> find(String key) {
        Object payload = redis.opsForHash().get(key, "payload");
        if (payload == null) return Optional.empty();
        try {
            return Optional.of(json.readValue(String.valueOf(payload), BizSession.class));
        } catch (Exception e) {
            throw new IllegalStateException("Redis 拜访会话反序列化失败: " + key, e);
        }
    }

    public void save(BizSession session) {
        long currentVersion = session.version;
        long nextVersion = currentVersion + 1;
        long ttlSeconds = Math.max(1, Duration.between(Instant.now(), session.expiresAt).getSeconds());
        String currentPayload = write(session);
        session.version = nextVersion;
        String nextPayload = write(session);
        session.version = currentVersion;

        Long result = redis.execute(SAVE_SCRIPT, Collections.singletonList(session.sessionKey),
                String.valueOf(currentVersion), String.valueOf(nextVersion), currentPayload, nextPayload,
                String.valueOf(ttlSeconds));
        if (result == null || result == 0) {
            throw new OptimisticLockingFailureException("拜访会话已被其他请求更新: " + session.sessionKey);
        }
        if (result == 2) session.version = nextVersion;
    }

    public void delete(String key) {
        redis.delete(key);
    }

    private String write(BizSession session) {
        try {
            return json.writeValueAsString(session);
        } catch (Exception e) {
            throw new IllegalArgumentException("拜访会话 JSON 序列化失败", e);
        }
    }
}
