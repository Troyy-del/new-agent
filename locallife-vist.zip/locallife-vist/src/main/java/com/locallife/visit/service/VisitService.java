package com.locallife.visit.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.FsmState;
import com.locallife.visit.domain.PlanStatus;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.handler.VisitActionDispatcher;
import com.locallife.visit.repository.SupportingRepository;
import com.locallife.visit.repository.VisitPlanRepository;
import com.locallife.visit.support.BizException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Application service for visit flows. Cross-cutting workflow concerns stay
 * here; concrete business actions are selected and run by independent handlers.
 */
@Service
public class VisitService {
    private static final Logger log = LoggerFactory.getLogger(VisitService.class);
    private final VisitPlanRepository plans;
    private final SupportingRepository supporting;
    private final CustomerSearchService customerSearch;
    private final SessionService sessions;
    private final IdempotencyService idempotency;
    private final VisitActionDispatcher dispatcher;
    private final ObjectMapper json;

    public VisitService(VisitPlanRepository plans, SupportingRepository supporting, CustomerSearchService customerSearch,
                        SessionService sessions, IdempotencyService idempotency,
                        VisitActionDispatcher dispatcher, ObjectMapper json) {
        this.plans = plans;
        this.supporting = supporting;
        this.customerSearch = customerSearch;
        this.sessions = sessions;
        this.idempotency = idempotency;
        this.dispatcher = dispatcher;
        this.json = json;
    }

    public VisitPlan detail(long id) {
        return plans.find(id).orElseThrow(() -> new BizException("PLAN_NOT_FOUND", "拜访计划不存在", HttpStatus.NOT_FOUND));
    }

    public VisitPlan detailOwned(long id, String user) {
        VisitPlan plan = detail(id);
        owner(plan, user);
        return plan;
    }

    public List<VisitPlan> list(String user, String keyword, List<PlanStatus> statuses, int limit) {
        return plans.findByCreator(user, keyword, statuses, limit);
    }

    public Object execute(BizSession session, String turnId, String action, Map<String, Object> params) {
        String requestId = turnId == null ? UUID.randomUUID().toString() : turnId;
        return idempotency.execute(session.chatId, requestId, action,
                () -> executeOnce(session, requestId, action, params));
    }

    private Object executeOnce(BizSession session, String turnId, String action, Map<String, Object> params) {
        sessions.executing(session);
        boolean success = false;
        Object result = null;
        try {
            result = dispatcher.dispatch(action, session, params);
            success = true;
            sessions.complete(session);
            return result;
        } catch (RuntimeException failure) {
            sessions.executionFailed(session);
            throw failure;
        } finally {
            try {
                supporting.audit(session.userId, session.chatId, turnId, action,
                        session.planId == null ? null : String.valueOf(session.planId),
                        params, success, String.valueOf(result));
            } catch (RuntimeException auditFailure) {
                log.error("Failed to persist visit audit, action={}, turnId={}", action, turnId, auditFailure);
            }
        }
    }

    @Transactional
    public VisitPlan directCreate(String user, Map<String, Object> data) {
        return (VisitPlan) dispatcher.dispatch("create", directSession(user, ActiveSkill.CREATE, null, data), data);
    }

    @Transactional
    public VisitPlan directUpdate(String user, long planId, Map<String, Object> data) {
        Map<String, Object> merged = new LinkedHashMap<>(slotsFromPlan(planId, user));
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            if (entry.getValue() != null) merged.put(entry.getKey(), entry.getValue());
        }
        return (VisitPlan) dispatcher.dispatch("update", directSession(user, ActiveSkill.UPDATE, planId, merged), merged);
    }

    private BizSession directSession(String user, ActiveSkill skill, Long planId, Map<String, Object> slots) {
        BizSession session = new BizSession();
        session.userId = user;
        session.chatId = "direct:" + user;
        session.activeSkill = skill;
        session.planId = planId;
        session.slots = new LinkedHashMap<>(slots);
        session.fsmState = FsmState.CONFIRMED;
        return session;
    }

    public Map<String, Object> query(String user, String type, Object param, int limit) {
        Map<String, Object> result = new LinkedHashMap<>();
        switch (type) {
            case "plan_detail":
                VisitPlan plan = detail(longValue(param, "planId"));
                owner(plan, user);
                result.put("plan", plan);
                break;
            case "nearby_match":
            case "plan_list":
                result.put("list", list(user, keyword(param), Arrays.asList(PlanStatus.PLANNED), limit));
                break;
            case "pending_checkout":
                result.put("list", list(user, null, Arrays.asList(PlanStatus.CHECKED_IN), limit));
                break;
            case "pending_log":
                result.put("list", list(user, null, Arrays.asList(PlanStatus.CHECKED_OUT), limit));
                break;
            case "pending":
                result.put("list", list(user, null,
                        Arrays.asList(PlanStatus.PLANNED, PlanStatus.CHECKED_IN, PlanStatus.CHECKED_OUT), limit));
                break;
            case "pending_travel_plan":
                result.put("list", Collections.emptyList());
                break;
            default:
                throw new BizException("UNKNOWN_QUERY_TYPE", "不支持的 queryType: " + type);
        }
        return result;
    }

    public List<Map<String, Object>> searchCustomers(String query, String type, int limit) {
        return customerSearch.search(query, type, limit);
    }

    public Map<String, Object> recording(long id) {
        Map<String, Object> result = supporting.recording(id);
        if (result == null) throw new BizException("RECORDING_NOT_FOUND", "录音任务不存在", HttpStatus.NOT_FOUND);
        return result;
    }

    public List<Map<String, Object>> audits(int limit) {
        return supporting.audits(limit);
    }

    public Map<String, Object> slotsFromPlan(long id, String user) {
        VisitPlan plan = detail(id);
        owner(plan, user);
        Map<String, Object> slots = new LinkedHashMap<>();
        slots.put("visitForm", plan.visitForm);
        slots.put("objectType", plan.objectType);
        slots.put("customerType", plan.customerType);
        if (plan.adIsTarget != null) slots.put("adIsTarget", plan.adIsTarget);
        Map<String, Object> customer = new LinkedHashMap<>();
        customer.put("id", plan.customerId);
        customer.put("name", plan.customerName);
        customer.put("objectType", plan.objectType);
        slots.put("customer", customer);
        Map<String, Object> purpose = new LinkedHashMap<>();
        purpose.put("code", plan.purposeCode);
        purpose.put("label", plan.purposeLabel);
        slots.put("purpose", purpose);
        slots.put("planTime", plan.planTime);
        Map<String, Object> address = new LinkedHashMap<>();
        address.put("text", plan.planAddress);
        address.put("longitude", plan.longitude);
        address.put("latitude", plan.latitude);
        slots.put("planAddress", address);
        try {
            slots.put("companions", json.readValue(plan.companionsJson, new TypeReference<List<Object>>() {
            }));
        } catch (Exception ignored) {
            slots.put("companions", Collections.emptyList());
        }
        if (plan.travelApplyId != null) slots.put("travelApplyId", plan.travelApplyId);
        return slots;
    }

    private static void owner(VisitPlan plan, String user) {
        if (user != null && !user.equals(plan.creatorId)) {
            throw new BizException("FORBIDDEN", "无权操作该拜访计划", HttpStatus.FORBIDDEN);
        }
    }

    private static long longValue(Object value, String label) {
        if (value == null) throw new BizException("MISSING_ARGUMENT", label + "不能为空");
        try {
            return Long.parseLong(String.valueOf(value));
        } catch (NumberFormatException e) {
            throw new BizException("INVALID_ARGUMENT", label + "格式错误");
        }
    }

    private static String keyword(Object param) {
        if (param instanceof Map) {
            Object value = ((Map<?, ?>) param).get("keyword");
            return value == null ? null : String.valueOf(value);
        }
        return param == null ? null : String.valueOf(param);
    }
}
