package com.locallife.visit.integration;

import org.springframework.stereotype.Component;

@Component
public class LocalSummaryGateway implements SummaryGateway {
    @Override public String summarize(String transcript) {
        if (transcript == null) return null;
        String text = transcript.trim().replaceAll("\\s+", " ");
        return text.length() <= 500 ? text : text.substring(0, 500) + "…";
    }
}
