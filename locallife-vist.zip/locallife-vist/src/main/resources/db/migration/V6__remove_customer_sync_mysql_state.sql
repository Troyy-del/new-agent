DROP TABLE IF EXISTS customer_event_consumption;
DROP TABLE IF EXISTS customer_file_snapshot;
