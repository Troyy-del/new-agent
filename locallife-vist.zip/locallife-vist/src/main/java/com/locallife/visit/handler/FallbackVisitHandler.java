package com.locallife.visit.handler;

import com.locallife.visit.domain.BizSession;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

@Component
public class FallbackVisitHandler implements VisitActionHandler {
    public Set<String> actions() { return Collections.singleton("fallback"); }
    public Object handle(BizSession session, Map<String, Object> params) {
        return Collections.singletonMap("nativeFormRequired", true);
    }
}
