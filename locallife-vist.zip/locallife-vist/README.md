# locallife-visit

从 `visit-assistant` skill 中抽取的独立拜访业务服务。项目把大模型侧的“理解与编排”与后端侧的“状态、校验、幂等和最终写操作”分开：Skill 只提交槽位和动作，所有写操作最终都由本服务的 FSM 决定能否执行。

## 已实现范围

- 拜访计划：创建、查询、修改、取消
- 履约：位置范围校验、签到、签退、非法状态迁移拦截
- 拜访日志：联系人与纪要校验、保存、提交审核、审核通过/驳回与归档
- 录音：开始/结束、Redis 流式转写片段、异步处理、本地摘要、失败状态与结果查询
- 待办：待签到、待签退、待日志、综合待办
- Agent 后端契约：`getAiVisitState`、`batchResolveAiVisitSlot`、`queryAiVisit`、`executeAiVisitAction`
- Handler 路由：统一 `VisitActionDispatcher` 自动发现并路由独立业务 Handler，避免在 Service 中堆叠动作分支
- 生产保护：确认态、Redis 60 秒幂等、Redis chat 级分布式锁、会话 CAS 乐观锁、权限校验、审计日志、24 小时无进展 FALLBACK
- 客户召回：客户主数据直接从 Milvus 列表查询或向量检索，不经过 MySQL
- Milvus：已接入阿里云 Milvus 2.6 Java SDK、连接健康检查、客户向量集合初始化、幂等 upsert/delete、列表查询和 COSINE 检索
- 本地 Hive2Kafka 模拟：监听 `data/customers.jsonl`，计算增删改差异并投递 Kafka；Consumer 直接更新 Milvus，失败消息进入 DLQ
- Skill 原始接口兼容：拜访列表/详情、签退预检/提交、补录、联系人维护、日志填写/修改和录音结果查询
- 本地业务替代：差旅申请、待补充差旅草稿、随访人员目录、联系人主数据和拜访联系人快照
- `feature_amu_visit` 移动端适配：首页启动数据、会话历史、创建/编辑、签到、签退、日志、录音和提交审核卡片
- 异常签到：超出定位半径时仍可提交，并持久化异常原因和现场照片地址
- 安全与可观测性：可配置身份/灰度名单拦截、审核人权限、请求 ID、Actuator 健康与指标端点

## 技术栈与运行

当前机器是 Java 11，因此使用兼容 Java 11 的 Spring Boot 2.7.18。默认连接本机 Docker 中的 MySQL 和 Redis；MySQL 表结构由 Flyway 管理，Redis 保存 Agent 会话、幂等结果和 chat 级分布式锁。

本机开发环境：

- MySQL 容器：`mysql8`，数据库 `locallife_visit`
- MySQL 应用账号：`locallife_visit_app`（仅允许 Docker 本机网关访问）
- Redis 容器：`locallife-visit-redis`，`127.0.0.1:6379`
- Redis 持久化卷：`locallife_visit_redis_data`，AOF `everysec`

```bash
mvn test
mvn spring-boot:run
```

健康检查：`GET http://localhost:8080/actuator/health`

### 阿里云 Milvus

当前实例公网地址已经加入本机 IP 白名单，应用默认仍关闭 Milvus，确保没有密钥时也可启动。请把密码只放在本机环境变量或 IntelliJ Run Configuration 中，不要提交到 Git：

```bash
MILVUS_ENABLED=true \
MILVUS_URI='http://c-e7314e9be34928db.milvus.aliyuncs.com:19530' \
MILVUS_USERNAME=root \
MILVUS_PASSWORD='你的实例密码' \
MILVUS_DATABASE=default \
mvn spring-boot:run
```

应用使用阿里云 Milvus 实例内置的 `AI_EMBEDDING` 服务调用 `text-embedding-v4`，不需要额外的百炼 API Key。当前客户文本检索统一使用 1024 维。首次创建集合：

```bash
MILVUS_DIMENSION=1024 \
MILVUS_EMBEDDING_MODEL=text-embedding-v4 \
MILVUS_COLLECTION=visit_customer_v1 \
MILVUS_INITIALIZE_SCHEMA=true \
mvn spring-boot:run
```

首次创建成功后应把 `MILVUS_INITIALIZE_SCHEMA` 恢复为 `false`。集合主键是 `customer_id`，向量字段是 `embedding`，索引采用 `AUTOINDEX + COSINE`。如果将来更换了输出维度不同的 embedding 模型，必须使用新集合名重建索引，不能直接修改既有向量字段维度。客户列表与关键词查询都只读取 Milvus，不再查询 MySQL 客户表。

如需重建 Redis 容器：

```bash
docker compose -f docker-compose.redis.yml up -d
```

### 本地文件 → Kafka → Milvus

启动官方 Apache Kafka 3.9.1 单节点 KRaft 容器：

```bash
docker compose -f docker-compose.kafka.yml up -d
docker exec locallife-visit-kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list
```

联调启动参数：

```bash
MILVUS_ENABLED=true \
MILVUS_PASSWORD='你的实例密码' \
CUSTOMER_FILE_SYNC_ENABLED=true \
mvn spring-boot:run
```

修改 `data/customers.jsonl` 后约 2 秒内会产生变更事件。每行是一个 JSON 客户；新增或修改产生 `UPSERT`，从文件删除产生 `DISABLE`。业务 Topic 为 `locallife.customer.changed.v1`，消费组为 `locallife-visit-customer-indexer`，连续失败三次后发送到 `locallife.customer.changed.v1.dlq`。Topic 按 `customerId` 做 Key 并开启日志压缩；Consumer 依靠 Kafka 已提交 offset 与 Milvus 主键 upsert/delete 保证可重复消费。文件侧差异状态保存在 `data/.customers.sync-state.json`，不使用 MySQL 快照表。

查看消息：

```bash
docker exec locallife-visit-kafka /opt/kafka/bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 --topic locallife.customer.changed.v1 \
  --from-beginning --property print.key=true --max-messages 20
```

连接参数都可通过环境变量覆盖：

```bash
MYSQL_URL='jdbc:mysql://127.0.0.1:3306/locallife_visit?...' \
MYSQL_USERNAME=locallife_visit_app MYSQL_PASSWORD=locallife_visit_dev \
REDIS_HOST=127.0.0.1 REDIS_PORT=6379 REDIS_DATABASE=0 \
mvn spring-boot:run
```

## Agent / Skill 接口

接口前缀为 `/rest/apicenter/crm/web/visitCenter`，字段兼容现有 Python client 的 camelCase 命名。

1. `POST /getAiVisitState`：加载或创建 `BizSessionState`
2. `POST /batchResolveAiVisitSlot`：解析、校验并回填槽位
3. 用户看到确认卡并确认后，调用 `POST /executeAiVisitAction`
4. 查询统一走 `POST /queryAiVisit`

创建流程示例：

```json
POST /rest/apicenter/crm/web/visitCenter/getAiVisitState
{
  "chatId": "chat-001",
  "userId": "bd-001",
  "activeSkill": "create",
  "sessionCreatedAt": 1893456000000
}
```

```json
POST /rest/apicenter/crm/web/visitCenter/batchResolveAiVisitSlot
{
  "chatId": "chat-001",
  "userId": "bd-001",
  "activeSkill": "create",
  "sessionCreatedAt": 1893456000000,
  "items": [
    {"slotName":"visitType","raw":"本地"},
    {"slotName":"visitObjectType","raw":"广告客户"},
    {"slotName":"customerType","raw":"老客"},
    {"slotName":"visitObjectInfo","raw":"北京果圈"},
    {"slotName":"visitPurpose","raw":"customer_maintenance"},
    {"slotName":"planVisitTime","raw":"2030-01-01 10:00"},
    {"slotName":"planVisitAddress","raw":{"text":"北京市海淀区西二旗大街1号","longitude":116.30,"latitude":40.05}}
  ]
}
```

当响应 `fsmState=CONFIRMING` 且 `waitingFor=[]`、`ambiguous={}` 时可以展示确认卡；用户确认后调用：

```json
POST /rest/apicenter/crm/web/visitCenter/executeAiVisitAction
{
  "chatId": "chat-001",
  "userId": "bd-001",
  "activeSkill": "create",
  "sessionCreatedAt": 1893456000000,
  "turnId": "turn-001"
}
```

## REST 接口

- `GET/POST /api/v1/visits`
- `GET/PUT /api/v1/visits/{id}`
- `POST /api/v1/visits/{id}/cancel`
- `POST /api/v1/visits/{id}/checkin`
- `POST /api/v1/visits/{id}/checkout`
- `POST /api/v1/visits/{id}/log`
- `POST /api/v1/visits/{id}/recording-start`
- `POST /api/v1/visits/{id}/recording-stop`
- `POST /api/v1/visits/{id}/submit-review|approve-review|reject-review|archive`
- `POST /api/v1/recordings/{id}/fragments`
- `GET /api/v1/recordings/{id}`
- `GET /api/v1/audit-logs`
- `GET/POST /api/v1/travel-applications`
- `POST /api/v1/travel-plan-drafts`
- `GET /api/v1/employees`

写请求建议携带 `Idempotency-Key`。调用方身份通过 `X-User-Id` 传入；生产环境应由网关认证后注入，禁止信任公网客户端自报身份。

## `feature_amu_visit` 移动端接口

以下接口对应 `New-Agent/public/visit-assistant.html` 使用的 `/api/visit` 契约：

- `GET /api/visit/bootstrap`：执照、目的、地址和差旅申请启动数据
- `GET /api/visit/health`：New-Agent 代理联通检查
- `GET/POST /api/visit/conversations`：会话列表/新建会话
- `GET /api/visit/conversations/{id}`：会话、消息卡片快照及活跃业务会话
- `POST /api/visit/create/start|resolve|confirm|reset`：创建计划卡片流程
- `POST /api/visit/plan/edit`：编辑已有计划
- `POST /api/visit/checkin/start|resolve|submit`：定位、选计划、拍照并签到
- `GET /api/visit/plans?type=checkout|log|all`：移动端待处理计划
- `POST /api/visit/checkout/start|precheck|submit`：签退完整流程
- `POST /api/visit/log/start|submit`：填写或修改拜访日志
- `POST /api/visit/recording/start|stop`、`GET /api/visit/recordings/{id}`：录音任务与结果
- `POST /api/visit/review/submit`：提交日志审核
- `POST /api/visit/plan/cancel`、`POST /api/visit/checkout/supplement`：取消与补录签退
- `POST /api/visit/cancel/start`：选择未开始计划并进入取消流程

本地调试时可直接传 `X-User-Id`，未传时使用 `demo-user`。正式联调时建议由 New-Agent 服务把 `/api/visit/*` 反向代理到本服务，并由网关注入真实用户身份。

## 核心状态

会话 FSM：`PENDING → FILLING → CONFIRMING → CONFIRMED → EXECUTING → DONE`，另有 `CANCELED/FALLBACK`。

拜访计划 FSM：`PLANNED → CHECKED_IN → CHECKED_OUT → LOGGED`，`PLANNED` 可转 `CANCELED`。任何逆向或跳级迁移都会返回 HTTP 409 `INVALID_FSM_TRANSITION`。

## Handler 架构

`VisitService` 只编排会话门禁、幂等、审计和执行生命周期，具体动作由 Spring 自动发现的 `VisitActionHandler` 执行：

- `CreateVisitPlanHandler` / `UpdateVisitPlanHandler` / `CancelVisitPlanHandler`
- `CheckinVisitHandler` / `CheckoutVisitHandler`
- `FillVisitLogHandler`
- `StartRecordingHandler` / `StopRecordingHandler`
- `SubmitReviewHandler` / `ApproveReviewHandler` / `RejectReviewHandler` / `ArchiveVisitHandler`
- `FallbackVisitHandler`

新增动作时实现 `VisitActionHandler` 并声明 `actions()` 即可；Dispatcher 会在启动时检测重复路由。

## 阿里云 ASR 与 OSS

已实现两条语音链路：

- 录音转写：浏览器采集 16 kHz 单声道 WAV，经后端上传到私有 OSS，生成临时签名 URL，异步调用录音文件识别并写回转写和摘要。
- 实时输入：后端使用 RAM AccessKey 换取短期 NLS Token，浏览器直连 NLS WebSocket，识别中间结果实时回填输入框。长期 AccessKey 不会下发到浏览器。

本机 AccessKey 保存在 macOS 钥匙串，使用脚本启动即可，不需要把密钥写入配置文件：

```bash
./scripts/run-local-asr.sh
```

也可以在 IntelliJ Run Configuration 中设置 `ALIYUN_ASR_ENABLED=true`、`NLS_APP_KEY`、`ALIYUN_AK_ID`、`ALIYUN_AK_SECRET`、`ALIYUN_OSS_ENDPOINT` 和 `ALIYUN_OSS_BUCKET`。RAM 用户仅被授予 NLS 调用权限，以及 `lzf-fzx/locallife-visit/recordings/*` 的 OSS 对象读写权限。

相关接口：

- `GET /api/visit/asr/realtime-session`：返回短期 Token、AppKey、WebSocket 地址和音频格式。
- `POST /api/visit/asr/audio`：上传 Base64 WAV 到私有 OSS，仅允许录音所属用户调用。

## 后续接入点

以下能力仍依赖公司系统或外部模型：

- 将本地文件源替换为真实 Hive/Kafka 客户主数据源
- 将 `SummaryGateway` 的本地摘要替换成真实 LLM；如需跨服务消费，再把本地异步执行器替换为消息队列
- 在网关层接入真实用户身份与组织权限

本地联调默认关闭身份强校验。需要验证灰度和身份门禁时可设置：

```bash
VISIT_SECURITY_ENABLED=true \
VISIT_SECURITY_ALL=false \
VISIT_WHITE_USERS=demo-user,demo-manager \
VISIT_REVIEWERS=demo-manager \
mvn spring-boot:run
```
