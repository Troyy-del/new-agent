package com.locallife.visit.service;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.support.BizException;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

@Service
public class SlotResolver {
    private static final Map<String, String> PURPOSES = new LinkedHashMap<>();

    static {
        PURPOSES.put("customer_maintenance", "客情维护");
        PURPOSES.put("meeting_new_customer", "会议场景/新客开拓方向的制定及跟进");
        PURPOSES.put("meeting_agent", "会议场景/新代理商/服务商建联");
        PURPOSES.put("meeting_product_training", "会议场景/产品培训");
        PURPOSES.put("meeting_review", "会议场景/复盘及分享");
        PURPOSES.put("meeting_framework", "会议场景/框架跟进");
        PURPOSES.put("meeting_policy", "会议场景/政策方案解读");
        PURPOSES.put("meeting_project", "会议场景/项目提案");
        PURPOSES.put("meeting_audit_training", "会议场景/审核培训");
        PURPOSES.put("meeting_key_customer", "会议场景/重点客户增量策略");
        PURPOSES.put("meeting_other", "会议场景/其他会议");
        PURPOSES.put("onsite_daily", "驻场支持/日常驻场");
        PURPOSES.put("onsite_big_event", "驻场支持/大场驻场");
        PURPOSES.put("onsite_other", "驻场支持/其他驻场");
        PURPOSES.put("other", "其他");
    }

    private final CustomerSearchService customerSearch;

    public SlotResolver(CustomerSearchService customerSearch) {
        this.customerSearch = customerSearch;
    }

    public void resolve(BizSession session, String name, Object raw) {
        if (name == null) throw new BizException("INVALID_SLOT", "slotName 不能为空");
        Object parsed;
        switch (name) {
            case "visitType":
            case "visitForm":
                parsed = visitForm(raw);
                name = "visitForm";
                break;
            case "visitObjectType":
            case "objectType":
                parsed = objectType(raw);
                name = "objectType";
                break;
            case "customerType":
                parsed = customerType(raw);
                break;
            case "adIsTarget":
                parsed = targetCustomer(raw);
                break;
            case "visitObjectInfo":
            case "customer":
                resolveCustomer(session, raw);
                return;
            case "visitPurpose":
            case "purpose":
                parsed = purpose(raw);
                name = "purpose";
                break;
            case "planVisitTime":
            case "planTime":
                parsed = parseTime(raw);
                name = "planTime";
                break;
            case "planVisitAddress":
            case "planAddress":
                parsed = address(raw);
                name = "planAddress";
                break;
            case "travelApplyNo":
            case "travelApplyId":
                parsed = requiredText(raw, "差旅单");
                name = "travelApplyId";
                break;
            case "companions":
                parsed = raw == null ? Collections.emptyList() : raw;
                break;
            case "contacts":
                parsed = raw;
                break;
            case "visitSummary":
                parsed = requiredText(raw, "拜访纪要");
                break;
            default:
                throw new BizException("UNKNOWN_SLOT", "不支持的槽位: " + name);
        }
        session.slots.put(name, parsed);
        session.ambiguous.remove(name);
    }

    public List<String> required(BizSession s) {
        ActiveSkill skill = s.activeSkill;
        if (skill == null) return Collections.emptyList();
        if (skill == ActiveSkill.CREATE || skill == ActiveSkill.UPDATE) {
            List<String> r = new ArrayList<>(Arrays.asList("visitForm", "objectType"));
            if ("travel".equals(s.slots.get("visitForm"))) r.add("travelApplyId");
            Object ot = s.slots.get("objectType");
            if ("ad_customer".equals(ot) || "store".equals(ot)) r.add("customerType");
            if ("ad_customer".equals(ot) && "new".equals(s.slots.get("customerType"))) r.add("adIsTarget");
            r.addAll(Arrays.asList("customer", "purpose", "planTime", "planAddress"));
            return missing(s, r);
        }
        if (skill == ActiveSkill.FILL_LOG) return missing(s, Arrays.asList("contacts", "visitSummary"));
        return Collections.emptyList();
    }

    public Map<String, String> purposes() {
        return Collections.unmodifiableMap(PURPOSES);
    }

    private void resolveCustomer(BizSession s, Object raw) {
        if (raw instanceof Map) {
            Map<?, ?> m = (Map<?, ?>) raw;
            if (m.get("id") != null && m.get("name") != null) {
                s.slots.put("customer", raw);
                adoptObjectType(s, m.get("objectType"));
                s.ambiguous.remove("customer");
                return;
            }
        }
        String q = requiredText(raw, "拜访对象");
        String type = (String) s.slots.get("objectType");
        List<Map<String, Object>> matches = customerSearch.search(q, type, 5);
        if (matches.isEmpty()) throw new BizException("CUSTOMER_NOT_FOUND", "未找到匹配的拜访对象");
        if (matches.size() > 1) {
            s.ambiguous.put("customer", matches);
            return;
        }
        Map<String, Object> customer = matches.get(0);
        s.slots.put("customer", customer);
        adoptObjectType(s, customer.get("objectType"));
        s.ambiguous.remove("customer");
    }

    private static void adoptObjectType(BizSession session, Object value) {
        if (session.slots.get("objectType") == null && value != null)
            session.slots.put("objectType", objectType(value));
    }

    private static List<String> missing(BizSession s, List<String> names) {
        List<String> r = new ArrayList<>();
        for (String n : names)
            if (!s.slots.containsKey(n) || s.slots.get(n) == null || s.ambiguous.containsKey(n)) r.add(n);
        return r;
    }

    private static String visitForm(Object r) {
        String v = norm(r);
        if (v.contains("出差") || v.contains("travel") || v.contains("business_trip")) return "travel";
        if (v.contains("本地") || v.contains("local")) return "local";
        throw new BizException("INVALID_VISIT_FORM", "拜访形式只能是本地或出差");
    }

    private static String objectType(Object r) {
        String v = norm(r);
        if (v.contains("门店") || v.equals("store")) return "store";
        if (v.contains("代理") || v.equals("agent")) return "agent";
        if (v.contains("服务商") || v.equals("provider")) return "provider";
        if (v.contains("客户") || v.contains("ad_customer")) return "ad_customer";
        throw new BizException("INVALID_OBJECT_TYPE", "对象类型只能是广告客户、门店、代理商或服务商");
    }

    private static String customerType(Object r) {
        String v = norm(r);
        if (v.equals("new") || v.contains("新")) return "new";
        if (v.equals("old") || v.contains("老") || v.contains("旧")) return "old";
        throw new BizException("INVALID_CUSTOMER_TYPE", "客户类型只能是新客或老客");
    }

    private static Boolean targetCustomer(Object raw) {
        if (raw instanceof Boolean) return (Boolean) raw;
        if (raw instanceof Map) {
            Object value = ((Map<?, ?>) raw).get("isTargetCustomer");
            if (value instanceof Boolean) return (Boolean) value;
            raw = value;
        }
        String value = norm(raw);
        if (value.equals("yes") || value.equals("true") || value.equals("1") || value.contains("是")) return true;
        if (value.equals("no") || value.equals("false") || value.equals("0") || value.contains("否")) return false;
        throw new BizException("INVALID_TARGET_CUSTOMER", "靶向新客只能选择是或否");
    }

    private static Map<String, Object> purpose(Object r) {
        String v = norm(r);
        String code = null;
        if (PURPOSES.containsKey(v)) code = v;
        else for (Map.Entry<String, String> e : PURPOSES.entrySet())
            if (e.getValue().contains(v) || v.contains(e.getValue())) {
                code = e.getKey();
                break;
            }
        if (code == null) throw new BizException("INVALID_PURPOSE", "无效的拜访目的 code");
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("code", code);
        m.put("label", PURPOSES.get(code));
        return m;
    }

    private static Map<String, Object> address(Object r) {
        if (r instanceof Map) {
            Map<?, ?> x = (Map<?, ?>) r;
            if (x.get("text") != null || x.get("address") != null) return new LinkedHashMap<>((Map<String, Object>) r);
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("text", requiredText(r, "拜访地址"));
        return m;
    }

    private static Instant parseTime(Object r) {
        if (r instanceof Number) return Instant.ofEpochMilli(((Number) r).longValue());
        String v = requiredText(r, "计划时间");
        try {
            return Instant.parse(v);
        } catch (DateTimeParseException ignore) {
        }
        try {
            return LocalDateTime.parse(v, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")).atZone(ZoneId.of("Asia/Shanghai")).toInstant();
        } catch (DateTimeParseException e) {
            try {
                return LocalDateTime.parse(v, DateTimeFormatter.ISO_LOCAL_DATE_TIME).atZone(ZoneId.of("Asia/Shanghai")).toInstant();
            } catch (DateTimeParseException ignored) {
                throw new BizException("INVALID_PLAN_TIME", "计划时间需为 ISO-8601 或 yyyy-MM-dd HH:mm");
            }
        }
    }

    private static String requiredText(Object r, String label) {
        String v = r == null ? "" : String.valueOf(r).trim();
        if (v.isEmpty()) throw new BizException("MISSING_SLOT", label + "不能为空");
        return v;
    }

    private static String norm(Object r) {
        return requiredText(r, "参数").toLowerCase(Locale.ROOT).trim();
    }
}
