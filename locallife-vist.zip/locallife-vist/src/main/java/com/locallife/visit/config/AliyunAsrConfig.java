package com.locallife.visit.config;

import com.locallife.visit.support.BizException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
@EnableConfigurationProperties({AliyunAsrProperties.class, AliyunOssProperties.class})
@ConditionalOnProperty(prefix = "visit.asr", name = "enabled", havingValue = "true")
public class AliyunAsrConfig {
    private final AliyunAsrProperties asr;
    private final AliyunOssProperties oss;

    public AliyunAsrConfig(AliyunAsrProperties asr, AliyunOssProperties oss) { this.asr = asr; this.oss = oss; }

    @PostConstruct
    public void validate() {
        required(asr.getAppKey(), "NLS_APP_KEY");
        required(asr.getAccessKeyId(), "ALIYUN_AK_ID");
        required(asr.getAccessKeySecret(), "ALIYUN_AK_SECRET");
        required(oss.getEndpoint(), "ALIYUN_OSS_ENDPOINT");
        required(oss.getBucket(), "ALIYUN_OSS_BUCKET");
    }

    private static void required(String value, String name) {
        if (value == null || value.trim().isEmpty()) throw new BizException("ASR_CONFIG_REQUIRED", "启用阿里云 ASR 时必须配置 " + name);
    }
}
