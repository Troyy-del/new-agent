package com.locallife.visit.integration;

import com.locallife.visit.config.MilvusProperties;
import com.locallife.visit.support.BizException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Component
@ConditionalOnProperty(prefix = "visit.milvus", name = "enabled", havingValue = "true")
public class MilvusEmbeddingClient {
    private final MilvusProperties properties;
    private final RestTemplate rest;

    public MilvusEmbeddingClient(MilvusProperties properties) {
        this.properties = properties;
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout((int) properties.getConnectTimeoutMs());
        factory.setReadTimeout((int) Math.max(properties.getRpcDeadlineMs(), 30_000));
        this.rest = new RestTemplate(factory);
    }

    public List<Float> embed(String text) {
        if (text == null || text.trim().isEmpty()) throw new BizException("EMPTY_EMBEDDING_TEXT", "向量化文本不能为空");
        if (properties.getDimension() <= 0) throw new BizException("MILVUS_DIMENSION_REQUIRED", "向量化前必须配置 MILVUS_DIMENSION");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(properties.getUsername() + ":" + properties.getPassword());
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("dim", properties.getDimension());
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model_name", properties.getEmbeddingModel());
        body.put("texts", Collections.singletonList(text));
        body.put("params", params);
        try {
            ResponseEntity<Map> response = rest.exchange(endpoint(), HttpMethod.POST, new HttpEntity<>(body, headers), Map.class);
            return vector(response.getBody());
        } catch (RuntimeException error) {
            throw new BizException("MILVUS_EMBEDDING_FAILED", "Milvus 文本向量化失败: " + error.getMessage());
        }
    }

    private String endpoint() {
        String uri = properties.getUri();
        return (uri.endsWith("/") ? uri.substring(0, uri.length() - 1) : uri) + "/v2/vectordb/ai/embedding";
    }

    private List<Float> vector(Map response) {
        Object code = response == null ? null : response.get("code");
        if (!(code instanceof Number) || ((Number) code).intValue() != 0) {
            throw new BizException("MILVUS_EMBEDDING_FAILED", "Milvus 文本向量化返回异常: " + (response == null ? "empty response" : response.get("message")));
        }
        try {
            Map data = (Map) response.get("data");
            Map output = (Map) data.get("output");
            List embeddings = (List) output.get("embeddings");
            Map first = (Map) embeddings.get(0);
            List values = (List) first.get("embedding");
            List<Float> result = new ArrayList<>(values.size());
            for (Object value : values) result.add(((Number) value).floatValue());
            if (result.size() != properties.getDimension()) throw new IllegalStateException("unexpected vector dimension " + result.size());
            return result;
        } catch (RuntimeException error) {
            throw new BizException("MILVUS_EMBEDDING_RESPONSE_INVALID", "Milvus 向量化响应格式不正确: " + error.getMessage());
        }
    }
}
