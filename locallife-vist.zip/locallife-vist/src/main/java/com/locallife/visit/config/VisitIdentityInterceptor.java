package com.locallife.visit.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.support.ApiResponse;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class VisitIdentityInterceptor implements HandlerInterceptor {
    private final VisitSecurityProperties properties; private final ObjectMapper json;
    public VisitIdentityInterceptor(VisitSecurityProperties properties,ObjectMapper json){this.properties=properties;this.json=json;}
    @Override public boolean preHandle(HttpServletRequest request,HttpServletResponse response,Object handler)throws Exception{
        if(!properties.isEnabled()) return true;
        String user=request.getHeader("X-User-Id");
        if(user!=null) user=user.trim();
        if(user==null||user.isEmpty()) return reject(response,401,"UNAUTHENTICATED","缺少可信用户身份");
        if(!properties.isAll()&&!properties.getWhiteUsernameList().contains(user)) return reject(response,403,"NOT_IN_GRAY_LIST","当前用户未进入拜访功能灰度名单");
        return true;
    }
    private boolean reject(HttpServletResponse response,int status,String code,String message)throws Exception{
        response.setStatus(status);response.setContentType(MediaType.APPLICATION_JSON_VALUE);response.setCharacterEncoding("UTF-8");
        json.writeValue(response.getWriter(), ApiResponse.fail(code,message)); return false;
    }
}
