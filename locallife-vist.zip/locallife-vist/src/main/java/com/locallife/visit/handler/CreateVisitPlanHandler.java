package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.VisitPlanRepository;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

@Component
public class CreateVisitPlanHandler implements VisitActionHandler {
    private final VisitPlanRepository plans;
    private final VisitHandlerSupport support;

    public CreateVisitPlanHandler(VisitPlanRepository plans, VisitHandlerSupport support) {
        this.plans = plans;
        this.support = support;
    }

    public Set<String> actions() {
        return new LinkedHashSet<>(Arrays.asList("create", "create_plan"));
    }

    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.CREATE);
        VisitPlan plan = support.fromSlots(session, null);
        plans.insert(plan);
        session.planId = plan.id;
        return plan;
    }
}
