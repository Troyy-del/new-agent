package com.locallife.visit.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "visit.security")
public class VisitSecurityProperties {
    private boolean enabled;
    private boolean all = true;
    private List<String> whiteUsernameList = new ArrayList<>();
    public boolean isEnabled(){return enabled;} public void setEnabled(boolean enabled){this.enabled=enabled;}
    public boolean isAll(){return all;} public void setAll(boolean all){this.all=all;}
    public List<String> getWhiteUsernameList(){return whiteUsernameList;} public void setWhiteUsernameList(List<String> value){this.whiteUsernameList=value==null?new ArrayList<>():value;}
}
