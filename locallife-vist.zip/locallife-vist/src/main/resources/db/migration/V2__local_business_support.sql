ALTER TABLE visit_plan
    MODIFY object_type VARCHAR(32) NULL,
    MODIFY customer_id VARCHAR(128) NULL,
    MODIFY customer_name VARCHAR(256) NULL,
    MODIFY purpose_code VARCHAR(64) NULL,
    MODIFY purpose_label VARCHAR(256) NULL,
    MODIFY plan_address VARCHAR(512) NULL,
    ADD COLUMN supplemented BOOLEAN NOT NULL DEFAULT FALSE AFTER contacts_json,
    ADD COLUMN checkin_abnormal_reason VARCHAR(512) NULL AFTER supplemented,
    ADD COLUMN checkout_abnormal_reason VARCHAR(512) NULL AFTER checkin_abnormal_reason,
    ADD COLUMN checkin_photo_url VARCHAR(1000) NULL AFTER checkout_abnormal_reason,
    ADD COLUMN checkout_photo_url VARCHAR(1000) NULL AFTER checkin_photo_url;

CREATE TABLE travel_application (
    apply_no VARCHAR(128) NOT NULL PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL,
    cities_json JSON NOT NULL,
    start_city VARCHAR(64),
    via_city VARCHAR(256),
    start_time DATE NOT NULL,
    end_time DATE NOT NULL,
    status VARCHAR(32) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    KEY idx_travel_user_status (user_id, status, start_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE employee_directory (
    user_id BIGINT NOT NULL PRIMARY KEY,
    user_code VARCHAR(128) NOT NULL UNIQUE,
    user_name VARCHAR(128) NOT NULL,
    department VARCHAR(256),
    position_name VARCHAR(128),
    avatar VARCHAR(1000),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    KEY idx_employee_name (user_name),
    KEY idx_employee_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE visit_contact (
    id BIGINT NOT NULL PRIMARY KEY,
    object_type VARCHAR(32) NOT NULL,
    object_id VARCHAR(128) NOT NULL,
    object_name VARCHAR(256),
    contact_name VARCHAR(128) NOT NULL,
    phone VARCHAR(64),
    is_kp BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    KEY idx_contact_object (object_type, object_id),
    KEY idx_contact_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE visit_contact_log (
    id BIGINT NOT NULL PRIMARY KEY,
    visit_plan_id BIGINT NOT NULL,
    contact_type VARCHAR(16) NOT NULL,
    contact_ref_id VARCHAR(128),
    snapshot_json JSON NOT NULL,
    created_at DATETIME(6) NOT NULL,
    KEY idx_contact_log_plan (visit_plan_id),
    CONSTRAINT fk_contact_log_plan FOREIGN KEY (visit_plan_id) REFERENCES visit_plan(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO travel_application(apply_no,user_id,cities_json,start_city,via_city,start_time,end_time,status,created_at,updated_at) VALUES
('TRAVEL-DEMO-001','demo-user','["北京","上海"]','北京','上海','2030-01-10','2030-01-12','APPROVED',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP),
('TRAVEL-DEMO-002','agent-user','["北京","杭州"]','北京','杭州','2030-02-15','2030-02-17','APPROVED',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);

INSERT INTO employee_directory(user_id,user_code,user_name,department,position_name,avatar,active) VALUES
(10001,'zhangsan01','张三','本地生活销售一部','BD','',TRUE),
(10002,'lisi02','李四','本地生活销售二部','高级BD','',TRUE),
(10003,'wangwu03','王五','商户运营部','运营经理','',TRUE);
