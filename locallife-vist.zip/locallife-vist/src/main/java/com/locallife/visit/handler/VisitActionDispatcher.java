package com.locallife.visit.handler;

import com.locallife.visit.domain.BizSession;
import com.locallife.visit.support.BizException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Component
public class VisitActionDispatcher {
    private final Map<String, VisitActionHandler> handlers;

    public VisitActionDispatcher(List<VisitActionHandler> discovered) {
        Map<String, VisitActionHandler> routes = new LinkedHashMap<>();
        for (VisitActionHandler handler : discovered) {
            for (String action : handler.actions()) {
                String key = normalize(action);
                VisitActionHandler previous = routes.putIfAbsent(key, handler);
                if (previous != null) {
                    throw new IllegalStateException("重复的拜访 Handler 路由: " + key);
                }
            }
        }
        this.handlers = Collections.unmodifiableMap(routes);
    }

    public Object dispatch(String action, BizSession session, Map<String, Object> params) {
        VisitActionHandler handler = handlers.get(normalize(action));
        if (handler == null) {
            throw new BizException("UNKNOWN_ACTION", "不支持的业务动作: " + action);
        }
        return handler.handle(session, params == null ? Collections.emptyMap() : params);
    }

    public List<String> registeredActions() {
        return new ArrayList<>(handlers.keySet());
    }

    private static String normalize(String action) {
        return action == null ? "" : action.trim().toLowerCase(Locale.ROOT);
    }
}
