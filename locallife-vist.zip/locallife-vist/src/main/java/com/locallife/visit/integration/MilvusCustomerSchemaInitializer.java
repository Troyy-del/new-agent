package com.locallife.visit.integration;

import com.locallife.visit.config.MilvusProperties;
import com.locallife.visit.support.BizException;
import io.milvus.v2.client.MilvusClientV2;
import io.milvus.v2.common.DataType;
import io.milvus.v2.common.IndexParam;
import io.milvus.v2.service.collection.request.AddFieldReq;
import io.milvus.v2.service.collection.request.CreateCollectionReq;
import io.milvus.v2.service.collection.request.ListCollectionsReq;
import io.milvus.v2.service.collection.request.LoadCollectionReq;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Lazy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.core.annotation.Order;
import io.milvus.shaded.io.grpc.StatusRuntimeException;

import java.util.Collections;

@Component
@Order(10)
@ConditionalOnProperty(prefix = "visit.milvus", name = "enabled", havingValue = "true")
public class MilvusCustomerSchemaInitializer implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(MilvusCustomerSchemaInitializer.class);
    private final MilvusClientV2 client;
    private final MilvusProperties properties;

    public MilvusCustomerSchemaInitializer(@Lazy MilvusClientV2 client, MilvusProperties properties) {
        this.client = client;
        this.properties = properties;
    }

    @Override public void run(ApplicationArguments args) {
        if (properties.getDimension() <= 0) {
            throw new BizException("MILVUS_DIMENSION_REQUIRED", "初始化 Milvus 集合前必须配置与 embedding 模型一致的 MILVUS_DIMENSION");
        }
        try {
            boolean exists = client.listCollectionsV2(ListCollectionsReq.builder().databaseName(properties.getDatabase()).build())
                    .getCollectionNames().contains(properties.getCollection());
            if (!exists) {
                if (!properties.isInitializeSchema()) {
                    throw new BizException("MILVUS_COLLECTION_MISSING", "Milvus 客户集合不存在；首次启动请设置 MILVUS_INITIALIZE_SCHEMA=true");
                }
                createCollection();
            }
            client.loadCollection(LoadCollectionReq.builder().databaseName(properties.getDatabase())
                    .collectionName(properties.getCollection()).numReplicas(1).sync(true).build());
        } catch (RuntimeException error) {
            StatusRuntimeException connectionError = connectionError(error);
            if (connectionError == null) throw error;
            // 云端 Milvus 的瞬时网络故障不应拖垮计划、签到、录音等全部拜访能力。
            // 客户检索、Kafka 消费和健康检查在真正调用时仍会返回明确的连接错误。
            log.warn("Milvus is temporarily unavailable during startup; application will continue and retry on demand: {}",
                    connectionError.getStatus());
        }
    }

    private static StatusRuntimeException connectionError(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof StatusRuntimeException) return (StatusRuntimeException) current;
            current = current.getCause();
        }
        return null;
    }

    private void createCollection() {
        CreateCollectionReq.CollectionSchema schema = MilvusClientV2.CreateSchema();
        schema.addField(varchar("customer_id", 128, true));
        schema.addField(varchar("object_type", 32, false));
        schema.addField(varchar("standard_name", 512, false));
        schema.addField(varchar("aliases", 2048, false));
        schema.addField(varchar("address", 1024, false));
        schema.addField(varchar("city", 128, false));
        schema.addField(AddFieldReq.builder().fieldName("active").dataType(DataType.Bool).build());
        schema.addField(AddFieldReq.builder().fieldName("updated_at").dataType(DataType.Int64).build());
        schema.addField(AddFieldReq.builder().fieldName("embedding").dataType(DataType.FloatVector)
                .dimension(properties.getDimension()).build());
        IndexParam index = IndexParam.builder().fieldName("embedding")
                .indexType(IndexParam.IndexType.AUTOINDEX).metricType(IndexParam.MetricType.COSINE).build();
        client.createCollection(CreateCollectionReq.builder().databaseName(properties.getDatabase())
                .collectionName(properties.getCollection()).description("拜访客户语义检索索引")
                .collectionSchema(schema).indexParams(Collections.singletonList(index)).enableDynamicField(false).build());
    }

    private static AddFieldReq varchar(String name, int length, boolean primary) {
        return AddFieldReq.builder().fieldName(name).dataType(DataType.VarChar).maxLength(length)
                .isPrimaryKey(primary).autoID(false).build();
    }
}
