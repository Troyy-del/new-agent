package com.locallife.visit.domain;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class BizSession {
    public String sessionKey;
    public String chatId;
    public String userId;
    public ActiveSkill activeSkill;
    public FsmState fsmState = FsmState.PENDING;
    public Long planId;
    public Map<String, Object> slots = new LinkedHashMap<>();
    public List<String> waitingFor = new ArrayList<>();
    public Map<String, Object> ambiguous = new LinkedHashMap<>();
    /** True when creation started from a message that already contained business fields. */
    public boolean guidedCreate;
    /** Customer text supplied before its object type was known; resolved immediately after type selection. */
    public String pendingCustomerQuery;
    public int askRound;
    public long version;
    public Instant lastProgress;
    public Instant expiresAt;
    public Instant createdAt;
    public Instant updatedAt;
}
