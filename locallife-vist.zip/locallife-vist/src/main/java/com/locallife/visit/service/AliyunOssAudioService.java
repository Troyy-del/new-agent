package com.locallife.visit.service;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.ObjectMetadata;
import com.locallife.visit.config.AliyunAsrProperties;
import com.locallife.visit.config.AliyunOssProperties;
import com.locallife.visit.support.BizException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.io.ByteArrayInputStream;
import java.net.URL;
import java.time.Instant;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@Service
@ConditionalOnProperty(prefix = "visit.asr", name = "enabled", havingValue = "true")
public class AliyunOssAudioService {
    private final AliyunOssProperties properties;
    private final OSS client;

    public AliyunOssAudioService(AliyunOssProperties properties, AliyunAsrProperties asr) {
        this.properties = properties;
        this.client = new OSSClientBuilder().build(properties.getEndpoint(), asr.getAccessKeyId(), asr.getAccessKeySecret());
    }

    public Map<String, Object> upload(long recordingId, String fileName, String contentType, String dataBase64) {
        if (dataBase64 == null || dataBase64.trim().isEmpty()) throw new BizException("AUDIO_REQUIRED", "录音数据不能为空");
        byte[] bytes;
        try { bytes = Base64.getDecoder().decode(dataBase64); }
        catch (IllegalArgumentException e) { throw new BizException("INVALID_AUDIO", "录音数据不是有效的 Base64"); }
        if (bytes.length == 0 || bytes.length > properties.getMaxAudioBytes())
            throw new BizException("AUDIO_TOO_LARGE", "录音文件为空或超过大小限制", HttpStatus.PAYLOAD_TOO_LARGE);

        String extension = extension(fileName);
        String prefix = properties.getObjectPrefix();
        if (!prefix.endsWith("/")) prefix += "/";
        String key = prefix + recordingId + "/" + Instant.now().toEpochMilli() + "-" + UUID.randomUUID() + extension;
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(bytes.length);
        metadata.setContentType(contentType == null || contentType.trim().isEmpty() ? "audio/wav" : contentType);
        client.putObject(properties.getBucket(), key, new ByteArrayInputStream(bytes), metadata);
        Date expires = new Date(System.currentTimeMillis() + properties.getSignedUrlSeconds() * 1000);
        URL url = client.generatePresignedUrl(properties.getBucket(), key, expires);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("recordingId", recordingId);
        result.put("objectKey", key);
        result.put("audioUrl", url.toString());
        result.put("expiresAt", expires.toInstant().getEpochSecond());
        result.put("size", bytes.length);
        return result;
    }

    private static String extension(String fileName) {
        if (fileName == null) return ".wav";
        String lower = fileName.toLowerCase();
        for (String extension : new String[]{".wav", ".mp3", ".aac", ".m4a", ".amr", ".ogg", ".pcm"})
            if (lower.endsWith(extension)) return extension;
        return ".wav";
    }

    @PreDestroy public void close() { client.shutdown(); }
}
