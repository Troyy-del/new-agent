package com.locallife.visit.integration;

public interface AsrGateway {
    /** Return null when no external ASR provider is configured. */
    String transcribe(String audioUrl);
}
