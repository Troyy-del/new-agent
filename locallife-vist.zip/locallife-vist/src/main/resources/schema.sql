CREATE TABLE IF NOT EXISTS visit_session (
    session_key VARCHAR(190) PRIMARY KEY,
    chat_id VARCHAR(128) NOT NULL,
    user_id VARCHAR(128) NOT NULL,
    active_skill VARCHAR(32),
    fsm_state VARCHAR(32) NOT NULL,
    plan_id BIGINT,
    slots_json TEXT NOT NULL,
    waiting_for_json TEXT NOT NULL,
    ambiguous_json TEXT NOT NULL,
    ask_round INT NOT NULL DEFAULT 0,
    version BIGINT NOT NULL DEFAULT 0,
    last_progress TIMESTAMP NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS visit_plan (
    id BIGINT PRIMARY KEY,
    creator_id VARCHAR(128) NOT NULL,
    visit_form VARCHAR(32) NOT NULL,
    object_type VARCHAR(32) NOT NULL,
    customer_id VARCHAR(128) NOT NULL,
    customer_name VARCHAR(256) NOT NULL,
    customer_type VARCHAR(16),
    purpose_code VARCHAR(64) NOT NULL,
    purpose_label VARCHAR(256) NOT NULL,
    plan_time TIMESTAMP NOT NULL,
    plan_address VARCHAR(512) NOT NULL,
    longitude DOUBLE,
    latitude DOUBLE,
    companions_json TEXT NOT NULL,
    travel_apply_id VARCHAR(128),
    status VARCHAR(32) NOT NULL,
    checkin_time TIMESTAMP,
    checkin_address VARCHAR(512),
    checkin_longitude DOUBLE,
    checkin_latitude DOUBLE,
    checkout_time TIMESTAMP,
    checkout_address VARCHAR(512),
    checkout_longitude DOUBLE,
    checkout_latitude DOUBLE,
    visit_summary TEXT,
    contacts_json TEXT,
    version BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_visit_plan_creator_status ON visit_plan(creator_id, status);
CREATE INDEX IF NOT EXISTS idx_visit_plan_time ON visit_plan(plan_time);

CREATE TABLE IF NOT EXISTS customer_master (
    id VARCHAR(128) PRIMARY KEY,
    object_type VARCHAR(32) NOT NULL,
    standard_name VARCHAR(256) NOT NULL,
    aliases VARCHAR(1000),
    address VARCHAR(512),
    city VARCHAR(64),
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS visit_recording (
    id BIGINT PRIMARY KEY,
    visit_plan_id BIGINT NOT NULL,
    status VARCHAR(32) NOT NULL,
    audio_url VARCHAR(1000),
    transcript TEXT,
    summary TEXT,
    started_at TIMESTAMP NOT NULL,
    stopped_at TIMESTAMP,
    updated_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS visit_audit_log (
    id BIGINT PRIMARY KEY,
    operator_id VARCHAR(128) NOT NULL,
    chat_id VARCHAR(128),
    turn_id VARCHAR(128),
    action VARCHAR(64) NOT NULL,
    biz_id VARCHAR(128),
    request_digest VARCHAR(128),
    success BOOLEAN NOT NULL,
    detail TEXT,
    created_at TIMESTAMP NOT NULL
);

MERGE INTO customer_master KEY(id) VALUES
('cust-001','ad_customer','北京果圈科技有限公司','北京果圈,果圈科技','北京市海淀区西二旗大街1号','北京',TRUE),
('cust-002','ad_customer','北京国圈文化有限公司','北京国圈,国圈文化','北京市朝阳区望京街8号','北京',TRUE),
('store-001','store','肯德基龙泽家园店','肯德基龙泽,龙泽家园KFC','北京市昌平区龙泽园街道','北京',TRUE),
('agent-001','agent','华北区域代理商','华北代理,北区代理','北京市朝阳区','北京',TRUE),
('provider-001','provider','本地生活服务商一号','服务商一号','上海市浦东新区','上海',TRUE);
