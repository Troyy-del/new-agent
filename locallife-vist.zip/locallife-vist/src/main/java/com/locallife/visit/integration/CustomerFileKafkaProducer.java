package com.locallife.visit.integration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.config.CustomerSyncProperties;
import com.locallife.visit.domain.CustomerChangeEvent;
import com.locallife.visit.domain.CustomerFileRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Component
@ConditionalOnProperty(prefix = "visit.customer-sync", name = "enabled", havingValue = "true")
public class CustomerFileKafkaProducer {
    private static final Logger log = LoggerFactory.getLogger(CustomerFileKafkaProducer.class);
    private final CustomerSyncProperties properties;
    private final ObjectMapper json;
    private final KafkaTemplate<String, String> kafka;

    public CustomerFileKafkaProducer(CustomerSyncProperties properties, ObjectMapper json,
                                     KafkaTemplate<String, String> kafka) {
        this.properties = properties; this.json = json; this.kafka = kafka;
    }

    @Scheduled(initialDelayString = "${visit.customer-sync.initial-delay-ms:3000}",
            fixedDelayString = "${visit.customer-sync.poll-delay-ms:2000}")
    public void publishChanges() {
        Path file = Paths.get(properties.getFile()).toAbsolutePath().normalize();
        if (!Files.isRegularFile(file)) { log.warn("Customer data file does not exist: {}", file); return; }
        try {
            Map<String, Snapshot> previous = snapshots();
            Map<String, RecordAndHash> current = read(file);
            int published = 0;
            for (RecordAndHash item : current.values()) {
                Snapshot old = previous.remove(item.record.id);
                if (old == null || !old.hash.equals(item.hash)) {
                    send("UPSERT", item.record);
                    published++;
                }
            }
            for (Snapshot removed : previous.values()) {
                CustomerFileRecord record = json.readValue(removed.payload, CustomerFileRecord.class);
                record.active = false;
                send("DISABLE", record);
                published++;
            }
            saveSnapshots(current);
            if (published > 0) log.info("Published {} customer file changes from {}", published, file);
        } catch (Exception error) {
            log.error("Failed to publish customer file changes", error);
        }
    }

    private Map<String, RecordAndHash> read(Path file) throws Exception {
        Map<String, RecordAndHash> result = new LinkedHashMap<>();
        int lineNumber = 0;
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            lineNumber++;
            if (line.trim().isEmpty() || line.trim().startsWith("#")) continue;
            CustomerFileRecord record = json.readValue(line, CustomerFileRecord.class);
            validate(record, lineNumber);
            String canonical = json.writeValueAsString(record);
            if (result.put(record.id, new RecordAndHash(record, sha256(canonical))) != null)
                throw new IllegalArgumentException("Duplicate customer id at line " + lineNumber + ": " + record.id);
        }
        return result;
    }

    private void send(String type, CustomerFileRecord record) throws Exception {
        CustomerChangeEvent event = new CustomerChangeEvent();
        event.eventType = type; event.customerId = record.id; event.version = System.currentTimeMillis();
        event.occurredAt = Instant.now(); event.data = record;
        // Kafka redelivery keeps the same payload/eventId. A later remove-and-readd lifecycle
        // must receive a fresh id even when the row content hash is identical.
        event.eventId = "file:" + type + ":" + record.id + ":" + UUID.randomUUID();
        kafka.send(properties.getTopic(), record.id, json.writeValueAsString(event)).get(10, TimeUnit.SECONDS);
    }

    private Map<String, Snapshot> snapshots() throws Exception {
        Path state = stateFile();
        if (!Files.isRegularFile(state)) return new LinkedHashMap<>();
        Map<String, Snapshot> result = json.readValue(state.toFile(), new TypeReference<Map<String, Snapshot>>() {});
        return result == null ? new LinkedHashMap<>() : new LinkedHashMap<>(result);
    }

    private void saveSnapshots(Map<String, RecordAndHash> current) throws Exception {
        Map<String, Snapshot> next = new LinkedHashMap<>();
        for (Map.Entry<String, RecordAndHash> entry : current.entrySet()) {
            RecordAndHash value = entry.getValue();
            next.put(entry.getKey(), new Snapshot(value.hash, json.writeValueAsString(value.record)));
        }
        Path state = stateFile();
        Path parent = state.getParent();
        if (parent != null) Files.createDirectories(parent);
        Path temp = state.resolveSibling(state.getFileName() + ".tmp");
        json.writerWithDefaultPrettyPrinter().writeValue(temp.toFile(), next);
        try {
            Files.move(temp, state, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(temp, state, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private Path stateFile() { return Paths.get(properties.getStateFile()).toAbsolutePath().normalize(); }

    private static void validate(CustomerFileRecord record, int line) {
        if (blank(record.id) || blank(record.objectType) || blank(record.name))
            throw new IllegalArgumentException("id/objectType/name are required at line " + line);
        if (!Arrays.asList("ad_customer", "store", "agent", "provider").contains(record.objectType))
            throw new IllegalArgumentException("Unsupported objectType at line " + line + ": " + record.objectType);
    }
    private static boolean blank(String value) { return value == null || value.trim().isEmpty(); }
    private static String sha256(String value) throws Exception {
        byte[] bytes = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
        StringBuilder result = new StringBuilder(); for (byte b : bytes) result.append(String.format("%02x", b)); return result.toString();
    }
    private static class RecordAndHash { final CustomerFileRecord record; final String hash; RecordAndHash(CustomerFileRecord r, String h) { record=r; hash=h; } }
    public static class Snapshot {
        public String hash;
        public String payload;
        public Snapshot() {}
        Snapshot(String hash, String payload) { this.hash = hash; this.payload = payload; }
    }
}
