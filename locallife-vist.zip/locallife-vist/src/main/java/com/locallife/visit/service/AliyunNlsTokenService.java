package com.locallife.visit.service;

import com.alibaba.nls.client.AccessToken;
import com.locallife.visit.config.AliyunAsrProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
@ConditionalOnProperty(prefix = "visit.asr", name = "enabled", havingValue = "true")
public class AliyunNlsTokenService {
    private final AliyunAsrProperties properties;
    private volatile String token;
    private volatile long expiresAt;

    public AliyunNlsTokenService(AliyunAsrProperties properties) { this.properties = properties; }

    public Map<String, Object> realtimeSession() {
        refreshIfNeeded();
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("appKey", properties.getAppKey());
        result.put("token", token);
        result.put("expiresAt", expiresAt);
        result.put("websocketUrl", properties.getWebsocketUrl());
        result.put("sampleRate", 16000);
        result.put("format", "pcm");
        return result;
    }

    private synchronized void refreshIfNeeded() {
        if (token != null && expiresAt > Instant.now().getEpochSecond() + 300) return;
        try {
            AccessToken request = new AccessToken(properties.getAccessKeyId(), properties.getAccessKeySecret(),
                    properties.getTokenDomain(), "cn-shanghai", "2019-02-28");
            request.apply();
            token = request.getToken();
            expiresAt = request.getExpireTime();
            if (token == null || token.isEmpty()) throw new IllegalStateException("阿里云未返回 NLS Token");
        } catch (Exception e) {
            throw new IllegalStateException("获取阿里云 NLS Token 失败：" + e.getMessage(), e);
        }
    }
}
