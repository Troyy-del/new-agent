package com.locallife.visit.service;

import com.locallife.visit.domain.*;
import com.locallife.visit.repository.SessionRepository;
import com.locallife.visit.support.BizException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

@Service
public class SessionService {
    private final SessionRepository repository;
    private final SlotResolver resolver;
    private final Duration ttl;

    public SessionService(SessionRepository repository, SlotResolver resolver, @Value("${visit.session-ttl:PT24H}") Duration ttl) {
        this.repository = repository;
        this.resolver = resolver;
        this.ttl = ttl;
    }

    public BizSession load(String chatId, String userId, ActiveSkill skill, Long planId, Long createdAt) {
        String key = key(chatId, skill, planId, createdAt);
        Instant now = Instant.now();
        BizSession s = repository.find(key).orElseGet(() -> newSession(key, chatId, userId, skill, planId, now));
        if (s.expiresAt.isBefore(now) || Duration.between(s.lastProgress, now).compareTo(ttl) > 0) {
            s.fsmState = FsmState.FALLBACK;
            s.activeSkill = null;
            s.waitingFor = Collections.emptyList();
            repository.save(s);
        }
        return s;
    }

    public BizSession resolve(BizSession s, List<Map<String, Object>> items, boolean autoPatch) {
        if (s.fsmState == FsmState.DONE || s.fsmState == FsmState.CANCELED)
            throw new BizException("INVALID_FSM_TRANSITION", "任务已结束，不能继续填充槽位", HttpStatus.CONFLICT);
        for (Map<String, Object> item : items) {
            String n = string(item, "slotName", "field", "name");
            Object raw = item.containsKey("raw") ? item.get("raw") : item.get("value");
            resolver.resolve(s, n, raw);
        }
        s.waitingFor = resolver.required(s);
        s.askRound = s.waitingFor.isEmpty() ? s.askRound : s.askRound + 1;
        s.fsmState = s.waitingFor.isEmpty() && s.ambiguous.isEmpty() ? FsmState.CONFIRMING : FsmState.FILLING;
        progress(s);
        repository.save(s);
        return s;
    }

    public void confirm(BizSession s) {
        if (s.fsmState != FsmState.CONFIRMING) throw invalid(s, "只有槽位完整后才能确认");
        s.fsmState = FsmState.CONFIRMED;
        progress(s);
        repository.save(s);
    }

    public void executing(BizSession s) {
        if (s.fsmState != FsmState.CONFIRMED) throw invalid(s, "写操作必须先二次确认");
        s.fsmState = FsmState.EXECUTING;
        progress(s);
        repository.save(s);
    }

    public void complete(BizSession s) {
        s.fsmState = FsmState.DONE;
        progress(s);
        repository.save(s);
    }

    public void executionFailed(BizSession s) {
        if (s.fsmState == FsmState.EXECUTING) {
            s.fsmState = FsmState.CONFIRMED;
            progress(s);
            repository.save(s);
        }
    }

    public void cancel(BizSession s) {
        s.fsmState = FsmState.CANCELED;
        progress(s);
        repository.save(s);
    }

    public void initializeSlots(BizSession s, Map<String, Object> slots) {
        if (!s.slots.isEmpty()) return;
        s.slots.putAll(slots);
        s.waitingFor = resolver.required(s);
        s.fsmState = s.waitingFor.isEmpty() ? FsmState.CONFIRMING : FsmState.FILLING;
        progress(s);
        repository.save(s);
    }

    private BizSession newSession(String key, String chat, String user, ActiveSkill skill, Long plan, Instant now) {
        BizSession s = new BizSession();
        s.sessionKey = key;
        s.chatId = chat;
        s.userId = user;
        s.activeSkill = skill;
        s.planId = plan;
        s.createdAt = now;
        s.updatedAt = now;
        s.lastProgress = now;
        s.expiresAt = now.plus(ttl);
        s.waitingFor = resolver.required(s);
        s.fsmState = skill == null ? FsmState.PENDING : (s.waitingFor.isEmpty() ? FsmState.CONFIRMING : FsmState.FILLING);
        repository.save(s);
        return s;
    }

    private void progress(BizSession s) {
        Instant now = Instant.now();
        s.lastProgress = now;
        s.updatedAt = now;
        s.expiresAt = now.plus(ttl);
    }

    private static BizException invalid(BizSession s, String m) {
        return new BizException("INVALID_FSM_TRANSITION", m + "，当前状态=" + s.fsmState, HttpStatus.CONFLICT);
    }

    private static String key(String chat, ActiveSkill skill, Long plan, Long created) {
        if (chat == null || chat.trim().isEmpty()) throw new BizException("MISSING_CHAT_ID", "chatId 不能为空");
        String suffix = plan != null ? String.valueOf(plan) : String.valueOf(created == null ? System.currentTimeMillis() : created);
        return "vai:state:" + chat + ":" + (skill == null ? "pending" : skill.name().toLowerCase(Locale.ROOT)) + ":" + suffix;
    }

    private static String string(Map<String, Object> m, String... keys) {
        for (String k : keys) if (m.get(k) != null) return String.valueOf(m.get(k));
        return null;
    }
}
