CREATE TABLE IF NOT EXISTS visit_plan (
    id BIGINT NOT NULL PRIMARY KEY,
    creator_id VARCHAR(128) NOT NULL,
    visit_form VARCHAR(32) NOT NULL,
    object_type VARCHAR(32) NOT NULL,
    customer_id VARCHAR(128) NOT NULL,
    customer_name VARCHAR(256) NOT NULL,
    customer_type VARCHAR(16),
    purpose_code VARCHAR(64) NOT NULL,
    purpose_label VARCHAR(256) NOT NULL,
    plan_time DATETIME(6) NOT NULL,
    plan_address VARCHAR(512) NOT NULL,
    longitude DOUBLE,
    latitude DOUBLE,
    companions_json JSON NOT NULL,
    travel_apply_id VARCHAR(128),
    status VARCHAR(32) NOT NULL,
    checkin_time DATETIME(6),
    checkin_address VARCHAR(512),
    checkin_longitude DOUBLE,
    checkin_latitude DOUBLE,
    checkout_time DATETIME(6),
    checkout_address VARCHAR(512),
    checkout_longitude DOUBLE,
    checkout_latitude DOUBLE,
    visit_summary TEXT,
    contacts_json JSON,
    version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    KEY idx_visit_plan_creator_status (creator_id, status),
    KEY idx_visit_plan_time (plan_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS customer_master (
    id VARCHAR(128) NOT NULL PRIMARY KEY,
    object_type VARCHAR(32) NOT NULL,
    standard_name VARCHAR(256) NOT NULL,
    aliases VARCHAR(1000),
    address VARCHAR(512),
    city VARCHAR(64),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    KEY idx_customer_type_active (object_type, active),
    KEY idx_customer_standard_name (standard_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS visit_recording (
    id BIGINT NOT NULL PRIMARY KEY,
    visit_plan_id BIGINT NOT NULL,
    status VARCHAR(32) NOT NULL,
    audio_url VARCHAR(1000),
    transcript LONGTEXT,
    summary TEXT,
    started_at DATETIME(6) NOT NULL,
    stopped_at DATETIME(6),
    updated_at DATETIME(6) NOT NULL,
    KEY idx_recording_plan (visit_plan_id),
    CONSTRAINT fk_recording_visit_plan FOREIGN KEY (visit_plan_id) REFERENCES visit_plan(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS visit_audit_log (
    id BIGINT NOT NULL PRIMARY KEY,
    operator_id VARCHAR(128) NOT NULL,
    chat_id VARCHAR(128),
    turn_id VARCHAR(128),
    action VARCHAR(64) NOT NULL,
    biz_id VARCHAR(128),
    request_digest VARCHAR(128),
    success BOOLEAN NOT NULL,
    detail TEXT,
    created_at DATETIME(6) NOT NULL,
    KEY idx_audit_operator_time (operator_id, created_at),
    KEY idx_audit_chat_turn (chat_id, turn_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO customer_master(id, object_type, standard_name, aliases, address, city, active) VALUES
('cust-001','ad_customer','北京果圈科技有限公司','北京果圈,果圈科技','北京市海淀区西二旗大街1号','北京',TRUE),
('cust-002','ad_customer','北京国圈文化有限公司','北京国圈,国圈文化','北京市朝阳区望京街8号','北京',TRUE),
('store-001','store','肯德基龙泽家园店','肯德基龙泽,龙泽家园KFC','北京市昌平区龙泽园街道','北京',TRUE),
('agent-001','agent','华北区域代理商','华北代理,北区代理','北京市朝阳区','北京',TRUE),
('provider-001','provider','本地生活服务商一号','服务商一号','上海市浦东新区','上海',TRUE)
ON DUPLICATE KEY UPDATE
    object_type=VALUES(object_type), standard_name=VALUES(standard_name), aliases=VALUES(aliases),
    address=VALUES(address), city=VALUES(city), active=VALUES(active);
