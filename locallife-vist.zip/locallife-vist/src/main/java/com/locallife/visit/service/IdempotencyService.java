package com.locallife.visit.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.support.BizException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.UUID;
import java.util.function.Supplier;

/** Cross-instance idempotency cache and per-chat distributed mutex. */
@Service
public class IdempotencyService {
    private static final DefaultRedisScript<Long> UNLOCK_SCRIPT = new DefaultRedisScript<>(
            "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]); end; return 0;",
            Long.class);

    private final StringRedisTemplate redis;
    private final ObjectMapper json;
    private final Duration ttl;
    private final Duration lockTimeout;

    public IdempotencyService(StringRedisTemplate redis, ObjectMapper json,
                              @Value("${visit.idempotency-ttl:PT60S}") Duration ttl,
                              @Value("${visit.chat-lock-timeout:PT30S}") Duration lockTimeout) {
        this.redis = redis;
        this.json = json;
        this.ttl = ttl;
        this.lockTimeout = lockTimeout;
    }

    public Object execute(String chatId, String turnId, String action, Supplier<Object> work) {
        String resultKey = "vai:idempotency:" + digest(chatId + "\n" + turnId + "\n" + action);
        Object cached = cached(resultKey);
        if (cached != null) return cached;

        String lockKey = "vai:lock:" + digest(chatId);
        String token = UUID.randomUUID().toString();
        Instant deadline = Instant.now().plus(lockTimeout);
        boolean acquired = false;
        try {
            while (!(acquired = Boolean.TRUE.equals(redis.opsForValue()
                    .setIfAbsent(lockKey, token, lockTimeout)))) {
                if (!Instant.now().isBefore(deadline)) {
                    throw new BizException("CHAT_LOCK_TIMEOUT", "同一会话正在执行其他写操作", HttpStatus.CONFLICT);
                }
                Thread.sleep(50);
            }
            cached = cached(resultKey);
            if (cached != null) return cached;
            Object value = work.get();
            redis.opsForValue().set(resultKey, write(value), ttl);
            return value;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new BizException("INTERRUPTED", "请求被中断");
        } finally {
            if (acquired) redis.execute(UNLOCK_SCRIPT, Collections.singletonList(lockKey), token);
        }
    }

    private Object cached(String key) {
        String value = redis.opsForValue().get(key);
        if (value == null) return null;
        try {
            return json.readValue(value, Object.class);
        } catch (Exception e) {
            redis.delete(key);
            return null;
        }
    }

    private String write(Object value) {
        try {
            return json.writeValueAsString(value);
        } catch (Exception e) {
            throw new IllegalArgumentException("幂等结果 JSON 序列化失败", e);
        }
    }

    private static String digest(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte item : bytes) result.append(String.format("%02x", item));
            return result.toString();
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 不可用", e);
        }
    }
}
