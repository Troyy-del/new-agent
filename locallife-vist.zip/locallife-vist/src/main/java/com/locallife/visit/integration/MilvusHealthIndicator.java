package com.locallife.visit.integration;

import com.locallife.visit.config.MilvusProperties;
import io.milvus.v2.client.MilvusClientV2;
import io.milvus.v2.service.collection.request.ListCollectionsReq;
import io.milvus.v2.service.collection.response.ListCollectionsResp;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component("milvus")
@ConditionalOnProperty(prefix = "visit.milvus", name = "enabled", havingValue = "true")
public class MilvusHealthIndicator implements HealthIndicator {
    private final MilvusClientV2 client;
    private final MilvusProperties properties;

    public MilvusHealthIndicator(@Lazy MilvusClientV2 client, MilvusProperties properties) {
        this.client = client;
        this.properties = properties;
    }

    @Override public Health health() {
        try {
            ListCollectionsResp response = client.listCollectionsV2(ListCollectionsReq.builder()
                    .databaseName(properties.getDatabase()).build());
            return Health.up().withDetail("database", properties.getDatabase())
                    .withDetail("collection", properties.getCollection())
                    .withDetail("collectionPresent", response.getCollectionNames().contains(properties.getCollection()))
                    .withDetail("collectionCount", response.getCollectionNames().size()).build();
        } catch (RuntimeException error) {
            return Health.down(error).withDetail("database", properties.getDatabase()).build();
        }
    }
}
