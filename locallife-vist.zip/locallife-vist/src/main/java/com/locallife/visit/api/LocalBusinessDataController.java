package com.locallife.visit.api;

import com.locallife.visit.service.VisitContractService;
import com.locallife.visit.support.ApiResponse;
import com.locallife.visit.support.BizException;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Local substitutes for data that would normally be synchronized from company systems. */
@RestController
@RequestMapping("/api/v1")
public class LocalBusinessDataController {
    private final VisitContractService contracts;

    public LocalBusinessDataController(VisitContractService contracts) {
        this.contracts = contracts;
    }

    @GetMapping("/travel-applications")
    public Map<String, Object> travelApplications(
            @RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user) {
        return ApiResponse.ok(contracts.travelApplications(user));
    }

    @SuppressWarnings("unchecked")
    @PostMapping("/travel-applications")
    public Map<String, Object> saveTravelApplication(
            @RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user,
            @RequestBody Map<String, Object> body) {
        String applyNo = required(body, "travelApplyNo");
        Object value = body.get("cities");
        List<?> cities = value instanceof List ? (List<?>) value : Collections.emptyList();
        if (cities.isEmpty()) throw new BizException("MISSING_TRAVEL_CITIES", "差旅城市不能为空");
        contracts.saveTravelApplication(applyNo, user, cities,
                LocalDate.parse(required(body, "startTime")), LocalDate.parse(required(body, "endTime")));
        return ApiResponse.ok(contracts.travelApplications(user));
    }

    @PostMapping("/travel-plan-drafts")
    public Map<String, Object> createTravelDraft(
            @RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user,
            @RequestBody Map<String, Object> body) {
        Instant planTime = body.get("planTime") == null ? null : Instant.parse(String.valueOf(body.get("planTime")));
        long id = contracts.createPendingTravel(user, required(body, "travelApplyNo"), planTime);
        return ApiResponse.ok(Collections.singletonMap("visitPlanId", String.valueOf(id)));
    }

    @GetMapping("/employees")
    public Map<String, Object> employees(@RequestParam(required = false) String keyword,
                                          @RequestParam(defaultValue = "30") int limit) {
        return ApiResponse.ok(contracts.employees(keyword, limit));
    }

    private static String required(Map<String, Object> body, String key) {
        Object value = body.get(key);
        if (value == null || String.valueOf(value).trim().isEmpty())
            throw new BizException("MISSING_" + key.toUpperCase(), key + " 不能为空");
        return String.valueOf(value);
    }
}
