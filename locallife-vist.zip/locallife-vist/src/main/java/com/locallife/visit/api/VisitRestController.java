package com.locallife.visit.api;

import com.locallife.visit.domain.*;
import com.locallife.visit.service.SessionService;
import com.locallife.visit.service.VisitService;
import com.locallife.visit.service.RecordingPipelineService;
import com.locallife.visit.support.ApiResponse;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/v1")
public class VisitRestController {
    private final VisitService visits;
    private final SessionService sessions;
    private final RecordingPipelineService recordings;

    public VisitRestController(VisitService visits, SessionService sessions, RecordingPipelineService recordings) {
        this.visits = visits;
        this.sessions = sessions;
        this.recordings=recordings;
    }

    @GetMapping("/visits")
    public Map<String, Object> list(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestParam(required = false) String keyword, @RequestParam(required = false) List<PlanStatus> status, @RequestParam(defaultValue = "20") int limit) {
        return ApiResponse.ok(visits.list(user, keyword, status, limit));
    }

    @GetMapping("/visits/{id}")
    public Map<String, Object> detail(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @PathVariable long id) {
        return ApiResponse.ok(visits.detailOwned(id,user));
    }

    @PostMapping("/visits")
    public Map<String, Object> create(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> slots) {
        return ApiResponse.ok(visits.directCreate(user, slots));
    }

    @PutMapping("/visits/{id}")
    public Map<String, Object> update(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @PathVariable long id, @RequestBody Map<String, Object> slots) {
        return ApiResponse.ok(visits.directUpdate(user, id, slots));
    }

    @PostMapping("/visits/{id}/{action:cancel|checkin|checkout|log|recording-start|recording-stop|submit-review|approve-review|reject-review|archive}")
    public Map<String, Object> action(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestHeader(value = "Idempotency-Key", required = false) String turnId, @PathVariable long id, @PathVariable String action, @RequestBody(required = false) Map<String, Object> body) {
        if (body == null) body = new LinkedHashMap<>();
        ActiveSkill skill = skill(action);
        long created = System.nanoTime();
        BizSession s = sessions.load("rest:" + user + ":" + id + ":" + action, user, skill, null, created);
        s.planId = id;
        sessions.initializeSlots(s, body);
        if (s.fsmState == FsmState.CONFIRMING) sessions.confirm(s);
        return ApiResponse.ok(visits.execute(s, turnId == null ? UUID.randomUUID().toString() : turnId, actionName(action), body));
    }

    @PostMapping("/recordings/{id}/fragments")
    public Map<String,Object> fragment(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user,
                                      @PathVariable long id,@RequestBody Map<String,Object> body){
        Map<String,Object> recording=visits.recording(id);
        visits.detailOwned(((Number)recording.get("visitPlanId")).longValue(),user);
        recordings.appendFragment(id,String.valueOf(body.getOrDefault("text","")));
        return ApiResponse.ok(Collections.singletonMap("accepted",true));
    }

    @GetMapping("/recordings/{id}")
    public Map<String, Object> recording(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user,
                                         @PathVariable long id) {
        Map<String,Object> recording=visits.recording(id);
        visits.detailOwned(((Number)recording.get("visitPlanId")).longValue(),user);
        return ApiResponse.ok(recording);
    }

    @GetMapping("/audit-logs")
    public Map<String, Object> audits(@RequestParam(defaultValue = "50") int limit) {
        return ApiResponse.ok(visits.audits(limit));
    }

    @GetMapping("/visit-purposes")
    public Map<String, Object> purposes() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("customer_maintenance", "客情维护");
        m.put("meeting_new_customer", "会议场景/新客开拓方向的制定及跟进");
        m.put("meeting_product_training", "会议场景/产品培训");
        m.put("meeting_review", "会议场景/复盘及分享");
        m.put("other", "其他");
        return ApiResponse.ok(m);
    }

    private static ActiveSkill skill(String a) {
        switch (a) {
            case "cancel":
                return ActiveSkill.CANCEL;
            case "checkin":
                return ActiveSkill.CHECKIN;
            case "checkout":
                return ActiveSkill.CHECKOUT;
            case "log":
                return ActiveSkill.FILL_LOG;
            case "submit-review": case "approve-review": case "reject-review": case "archive":
                return ActiveSkill.REVIEW;
            default:
                return ActiveSkill.RECORD;
        }
    }

    private static String actionName(String a) {
        switch (a) {
            case "log":
                return "fill_log";
            case "recording-start":
                return "start_recording";
            case "recording-stop":
                return "stop_recording";
            case "submit-review": return "submit_review";
            case "approve-review": return "approve_review";
            case "reject-review": return "reject_review";
            default:
                return a;
        }
    }
}
