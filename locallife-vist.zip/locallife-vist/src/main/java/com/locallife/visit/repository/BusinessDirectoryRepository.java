package com.locallife.visit.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Repository
public class BusinessDirectoryRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper json;

    public BusinessDirectoryRepository(JdbcTemplate jdbc, ObjectMapper json) {
        this.jdbc = jdbc;
        this.json = json;
    }

    public List<Map<String, Object>> travelApplications(String user) {
        return jdbc.query("SELECT * FROM travel_application WHERE status='APPROVED' AND (user_id=? OR user_id='*') ORDER BY start_time", (rs, row) -> {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("travelApplyNo", rs.getString("apply_no"));
            item.put("cities", readList(rs.getString("cities_json")));
            item.put("startTime", String.valueOf(rs.getDate("start_time")));
            item.put("endTime", String.valueOf(rs.getDate("end_time")));
            item.put("status", rs.getString("status"));
            item.put("travelStartCity", rs.getString("start_city"));
            item.put("travelViaCity", rs.getString("via_city"));
            return item;
        }, user);
    }

    public Map<String, Object> travelApplication(String applyNo) {
        return jdbc.query("SELECT * FROM travel_application WHERE apply_no=?", rs -> {
            if (!rs.next()) return null;
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("travelApplyNo", rs.getString("apply_no"));
            item.put("travelStartCity", rs.getString("start_city"));
            item.put("travelViaCity", rs.getString("via_city"));
            item.put("cities", readList(rs.getString("cities_json")));
            item.put("startTime", String.valueOf(rs.getDate("start_time")));
            item.put("endTime", String.valueOf(rs.getDate("end_time")));
            item.put("status", rs.getString("status"));
            return item;
        }, applyNo);
    }

    public void saveTravelApplication(String applyNo, String user, List<?> cities, LocalDate start, LocalDate end) {
        String first = cities.isEmpty() ? null : String.valueOf(cities.get(0));
        String via = cities.size() < 2 ? first : joinCities(cities.subList(1, cities.size()));
        jdbc.update("INSERT INTO travel_application(apply_no,user_id,cities_json,start_city,via_city,start_time,end_time,status,created_at,updated_at) VALUES(?,?,?,?,?,? ,?,'APPROVED',?,?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id),cities_json=VALUES(cities_json),start_city=VALUES(start_city),via_city=VALUES(via_city),start_time=VALUES(start_time),end_time=VALUES(end_time),status='APPROVED',updated_at=VALUES(updated_at)",
                applyNo, user, write(cities), first, via, Date.valueOf(start), Date.valueOf(end), Timestamp.from(Instant.now()), Timestamp.from(Instant.now()));
    }

    public List<Map<String, Object>> employees(String keyword, int limit) {
        String query = "%" + (keyword == null ? "" : keyword.trim().toLowerCase()) + "%";
        return jdbc.query("SELECT * FROM employee_directory WHERE active=TRUE AND (LOWER(user_name) LIKE ? OR LOWER(user_code) LIKE ? OR LOWER(COALESCE(department,'')) LIKE ?) ORDER BY user_name LIMIT ?", (rs, row) -> {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("userId", rs.getLong("user_id"));
            item.put("userName", rs.getString("user_name"));
            item.put("userCode", rs.getString("user_code"));
            item.put("department", rs.getString("department"));
            item.put("position", rs.getString("position_name"));
            item.put("avatar", rs.getString("avatar"));
            return item;
        }, query, query, query, Math.max(1, Math.min(limit, 100)));
    }

    public List<Map<String, Object>> contacts(String objectType, String objectId) {
        return jdbc.query("SELECT * FROM visit_contact WHERE object_type=? AND object_id=? ORDER BY is_kp DESC, created_at", (rs, row) -> {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", String.valueOf(rs.getLong("id")));
            item.put("name", rs.getString("contact_name"));
            item.put("phone", rs.getString("phone"));
            item.put("isKp", rs.getBoolean("is_kp") ? 1 : 0);
            return item;
        }, objectType, objectId);
    }

    public Map<String, Object> saveContact(String objectType, String objectId, String objectName, Map<String, Object> contact) {
        String idValue = text(contact.get("id"));
        String name = text(contact.get("name"));
        String phone = text(contact.get("phone"));
        boolean kp = booleanValue(contact.get("isKp"));
        Long existing = null;
        if (idValue != null) {
            try { existing = Long.valueOf(idValue); } catch (NumberFormatException ignored) { }
        }
        if (existing == null && phone != null && !phone.isEmpty()) {
            List<Long> ids = jdbc.query("SELECT id FROM visit_contact WHERE object_type=? AND object_id=? AND phone=? LIMIT 1", (rs, row) -> rs.getLong(1), objectType, objectId, phone);
            if (!ids.isEmpty()) existing = ids.get(0);
        }
        Instant now = Instant.now();
        if (existing == null) {
            existing = SupportingRepository.newId();
            jdbc.update("INSERT INTO visit_contact(id,object_type,object_id,object_name,contact_name,phone,is_kp,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                    existing, objectType, objectId, objectName, name, phone, kp, Timestamp.from(now), Timestamp.from(now));
        } else {
            jdbc.update("UPDATE visit_contact SET object_name=?,contact_name=?,phone=?,is_kp=?,updated_at=? WHERE id=? AND object_type=? AND object_id=?",
                    objectName, name, phone, kp, Timestamp.from(now), existing, objectType, objectId);
        }
        for (Map<String, Object> item : contacts(objectType, objectId)) {
            if (String.valueOf(existing).equals(item.get("id"))) return item;
        }
        return Collections.emptyMap();
    }

    public void replaceContactSnapshots(long planId, List<Map<String, Object>> phoneContacts, List<Map<String, Object>> wechatContacts) {
        jdbc.update("DELETE FROM visit_contact_log WHERE visit_plan_id=?", planId);
        Instant now = Instant.now();
        for (Map<String, Object> contact : phoneContacts) insertSnapshot(planId, "phone", text(contact.get("id")), contact, now);
        for (Map<String, Object> contact : wechatContacts) insertSnapshot(planId, "wechat", text(contact.get("wechatUserId")), contact, now);
    }

    private void insertSnapshot(long planId, String type, String reference, Map<String, Object> snapshot, Instant now) {
        jdbc.update("INSERT INTO visit_contact_log(id,visit_plan_id,contact_type,contact_ref_id,snapshot_json,created_at) VALUES(?,?,?,?,?,?)",
                SupportingRepository.newId(), planId, type, reference, write(snapshot), Timestamp.from(now));
    }

    private List<Object> readList(String value) {
        try { return json.readValue(value, json.getTypeFactory().constructCollectionType(List.class, Object.class)); }
        catch (Exception e) { return Collections.emptyList(); }
    }

    private String write(Object value) {
        try { return json.writeValueAsString(value); }
        catch (Exception e) { throw new IllegalArgumentException("JSON 序列化失败", e); }
    }

    private static String joinCities(List<?> values) {
        StringBuilder result = new StringBuilder();
        for (Object value : values) {
            if (result.length() > 0) result.append('-');
            result.append(value);
        }
        return result.toString();
    }

    private static String text(Object value) { return value == null ? null : String.valueOf(value); }
    private static boolean booleanValue(Object value) {
        if (value instanceof Boolean) return (Boolean) value;
        return "1".equals(String.valueOf(value)) || "true".equalsIgnoreCase(String.valueOf(value)) || "是".equals(String.valueOf(value));
    }
}
