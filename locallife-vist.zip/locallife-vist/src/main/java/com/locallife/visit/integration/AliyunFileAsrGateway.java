package com.locallife.visit.integration;

import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.http.ProtocolType;
import com.aliyuncs.profile.DefaultProfile;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.config.AliyunAsrProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
@ConditionalOnProperty(prefix = "visit.asr", name = "enabled", havingValue = "true")
public class AliyunFileAsrGateway implements AsrGateway {
    private static final String PRODUCT = "nls-filetrans";
    private static final String VERSION = "2018-08-17";
    private static final long SUCCESS = 21050000L;

    private final AliyunAsrProperties properties;
    private final ObjectMapper json;
    private final IAcsClient client;

    public AliyunFileAsrGateway(AliyunAsrProperties properties, ObjectMapper json) {
        this.properties = properties;
        this.json = json;
        DefaultProfile profile = DefaultProfile.getProfile(properties.getRegion(), properties.getAccessKeyId(), properties.getAccessKeySecret());
        this.client = new DefaultAcsClient(profile);
    }

    @Override
    public String transcribe(String audioUrl) {
        if (audioUrl == null || audioUrl.trim().isEmpty()) return null;
        try {
            String taskId = submit(audioUrl);
            long deadline = System.currentTimeMillis() + properties.getPollTimeoutMs();
            while (System.currentTimeMillis() < deadline) {
                JsonNode response = request("GetTaskResult", MethodType.GET, "TaskId", taskId);
                long status = response.path("StatusCode").asLong();
                String statusText = response.path("StatusText").asText("");
                if (status == SUCCESS || "SUCCESS".equalsIgnoreCase(statusText)) return transcript(response.path("Result"));
                if (!isPending(statusText)) throw new IllegalStateException("录音文件识别失败：" + statusText + " (" + status + ")");
                Thread.sleep(properties.getPollIntervalMs());
            }
            throw new IllegalStateException("录音文件识别超时");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("录音文件识别被中断", e);
        } catch (Exception e) {
            if (e instanceof IllegalStateException) throw (IllegalStateException) e;
            throw new IllegalStateException("调用阿里云录音文件识别失败：" + e.getMessage(), e);
        }
    }

    private String submit(String audioUrl) throws Exception {
        Map<String, Object> task = new LinkedHashMap<>();
        task.put("appkey", properties.getAppKey());
        task.put("file_link", audioUrl);
        task.put("version", "4.0");
        task.put("enable_words", false);
        task.put("enable_sample_rate_adaptive", true);
        JsonNode response = request("SubmitTask", MethodType.POST, "Task", json.writeValueAsString(task));
        String taskId = response.path("TaskId").asText();
        if (taskId.isEmpty()) throw new IllegalStateException("提交录音识别任务失败：" + response.path("StatusText").asText("未知错误"));
        return taskId;
    }

    private JsonNode request(String action, MethodType method, String parameter, String value) throws Exception {
        CommonRequest request = new CommonRequest();
        request.setSysProtocol(ProtocolType.HTTPS);
        request.setSysMethod(method);
        request.setSysDomain(properties.getFiletransDomain());
        request.setSysVersion(VERSION);
        request.setSysAction(action);
        request.putQueryParameter(parameter, value);
        CommonResponse response = client.getCommonResponse(request);
        return json.readTree(response.getData());
    }

    private String transcript(JsonNode result) {
        StringBuilder text = new StringBuilder();
        JsonNode sentences = result.path("Sentences");
        if (sentences.isArray()) for (JsonNode sentence : sentences) {
            String value = sentence.path("Text").asText("").trim();
            if (!value.isEmpty()) text.append(value);
        }
        String value = text.toString().trim();
        if (value.isEmpty()) throw new IllegalStateException("录音识别成功但未返回文本");
        return value;
    }

    private static boolean isPending(String value) {
        String status = value == null ? "" : value.toUpperCase();
        return status.isEmpty() || status.contains("RUNNING") || status.contains("QUEUE") || status.contains("PROCESSING");
    }
}
