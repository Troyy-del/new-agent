package com.locallife.visit.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SupportingRepository {
    private final JdbcTemplate jdbc;

    public SupportingRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public long insertRecording(long planId) {
        long id = newId();
        Instant now = Instant.now();
        jdbc.update("INSERT INTO visit_recording(id,visit_plan_id,status,started_at,updated_at) VALUES(?,?,'RECORDING',?,?)", id, planId, Timestamp.from(now), Timestamp.from(now));
        return id;
    }

    public void completeRecording(long id, String audioUrl, String transcript, String summary) {
        jdbc.update("UPDATE visit_recording SET status='COMPLETED',audio_url=COALESCE(?,audio_url),transcript=?,summary=?,error_message=NULL,stopped_at=COALESCE(stopped_at,CURRENT_TIMESTAMP),updated_at=CURRENT_TIMESTAMP WHERE id=?", audioUrl, transcript, summary, id);
    }

    public void markRecordingProcessing(long id, String audioUrl) {
        jdbc.update("UPDATE visit_recording SET status='PROCESSING',audio_url=COALESCE(?,audio_url),processing_started_at=CURRENT_TIMESTAMP,stopped_at=COALESCE(stopped_at,CURRENT_TIMESTAMP),updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='RECORDING'", audioUrl, id);
    }

    public void markRecordingWaitingExternal(long id) {
        jdbc.update("UPDATE visit_recording SET status='WAITING_EXTERNAL',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='PROCESSING'", id);
    }

    public void failRecording(long id, String message) {
        jdbc.update("UPDATE visit_recording SET status='FAILED',error_message=?,retry_count=retry_count+1,updated_at=CURRENT_TIMESTAMP WHERE id=?", message, id);
    }

    public Map<String, Object> recording(long id) {
        return jdbc.query("SELECT * FROM visit_recording WHERE id=?", rs -> {
            if (!rs.next()) return null;
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", rs.getLong("id"));
            m.put("visitPlanId", rs.getLong("visit_plan_id"));
            m.put("status", rs.getString("status"));
            m.put("audioUrl", rs.getString("audio_url"));
            m.put("transcript", rs.getString("transcript"));
            m.put("summary", rs.getString("summary"));
            m.put("errorMessage", rs.getString("error_message"));
            m.put("retryCount", rs.getInt("retry_count"));
            return m;
        }, id);
    }

    public Map<String, Object> latestRecordingByPlan(long planId) {
        return jdbc.query("SELECT * FROM visit_recording WHERE visit_plan_id=? ORDER BY started_at DESC LIMIT 1", rs -> {
            if (!rs.next()) return null;
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", rs.getLong("id"));
            m.put("visitPlanId", rs.getLong("visit_plan_id"));
            m.put("status", rs.getString("status"));
            m.put("audioUrl", rs.getString("audio_url"));
            m.put("transcript", rs.getString("transcript"));
            m.put("summary", rs.getString("summary"));
            m.put("errorMessage", rs.getString("error_message"));
            m.put("retryCount", rs.getInt("retry_count"));
            return m;
        }, planId);
    }

    public void enqueueNotification(String user, String eventType, String bizId, String payloadJson) {
        long id = newId(); Instant now = Instant.now();
        jdbc.update("INSERT INTO visit_notification_outbox(id,user_id,event_type,biz_id,payload_json,status,created_at,updated_at) VALUES(?,?,?,?,CAST(? AS JSON),'PENDING',?,?) ON DUPLICATE KEY UPDATE payload_json=VALUES(payload_json),status='PENDING',updated_at=VALUES(updated_at)",
                id, user, eventType, bizId, payloadJson, Timestamp.from(now), Timestamp.from(now));
    }

    public void audit(String operator, String chatId, String turnId, String action, String bizId, Object request, boolean success, String detail) {
        jdbc.update("INSERT INTO visit_audit_log(id,operator_id,chat_id,turn_id,action,biz_id,request_digest,success,detail,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                newId(), operator, chatId, turnId, action, bizId, digest(String.valueOf(request)), success, detail, Timestamp.from(Instant.now()));
    }

    public List<Map<String, Object>> audits(int limit) {
        return new ArrayList<>(jdbc.queryForList("SELECT * FROM visit_audit_log ORDER BY created_at DESC LIMIT ?", Math.max(1, Math.min(limit, 200))));
    }

    public static long newId() {
        return Math.abs(java.util.concurrent.ThreadLocalRandom.current().nextLong(1_000_000_000_000_000L, 9_000_000_000_000_000L));
    }

    private static String digest(String value) {
        try {
            byte[] b = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder s = new StringBuilder();
            for (byte x : b) s.append(String.format("%02x", x));
            return s.toString();
        } catch (Exception e) {
            return "unavailable";
        }
    }
}
