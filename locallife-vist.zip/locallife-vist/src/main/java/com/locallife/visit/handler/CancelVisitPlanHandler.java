package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.PlanStatus;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.VisitPlanRepository;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

@Component
public class CancelVisitPlanHandler implements VisitActionHandler {
    private final VisitPlanRepository plans;
    private final VisitHandlerSupport support;

    public CancelVisitPlanHandler(VisitPlanRepository plans, VisitHandlerSupport support) { this.plans = plans; this.support = support; }
    public Set<String> actions() { return new LinkedHashSet<>(Arrays.asList("cancel", "cancel_plan")); }
    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.CANCEL);
        VisitPlan plan = support.detail(support.requiredPlan(session));
        support.owner(plan, session.userId);
        if (plan.status != PlanStatus.PLANNED) throw VisitHandlerSupport.transition("只有待拜访计划可取消");
        plans.markStatus(plan.id, plan.version, PlanStatus.PLANNED, PlanStatus.CANCELED, null, null, null);
        return support.detail(plan.id);
    }
}
