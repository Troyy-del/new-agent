ALTER TABLE visit_plan
    ADD COLUMN review_status VARCHAR(32) NOT NULL DEFAULT 'DRAFT' AFTER status,
    ADD COLUMN reviewer_id VARCHAR(128) NULL AFTER review_status,
    ADD COLUMN review_comment VARCHAR(1000) NULL AFTER reviewer_id,
    ADD COLUMN reviewed_at DATETIME(6) NULL AFTER review_comment,
    ADD COLUMN archived_at DATETIME(6) NULL AFTER reviewed_at,
    ADD KEY idx_visit_review_status (review_status, updated_at);

ALTER TABLE visit_recording
    ADD COLUMN error_message VARCHAR(1000) NULL AFTER summary,
    ADD COLUMN retry_count INT NOT NULL DEFAULT 0 AFTER error_message,
    ADD COLUMN processing_started_at DATETIME(6) NULL AFTER retry_count;

CREATE TABLE visit_notification_outbox (
    id BIGINT NOT NULL PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    biz_id VARCHAR(128) NOT NULL,
    payload_json JSON NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
    retry_count INT NOT NULL DEFAULT 0,
    next_retry_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    UNIQUE KEY uk_visit_outbox_event (user_id, event_type, biz_id),
    KEY idx_visit_outbox_status_retry (status, next_retry_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
