package com.locallife.visit.domain;

import java.util.ArrayList;
import java.util.List;

public class CustomerFileRecord {
    public String id;
    public String objectType;
    public String name;
    public List<String> aliases = new ArrayList<>();
    public String address;
    public String city;
    public boolean active = true;

    public String aliasesText() { return aliases == null ? "" : String.join(",", aliases); }
}
