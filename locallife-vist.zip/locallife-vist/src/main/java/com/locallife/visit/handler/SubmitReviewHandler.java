package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.VisitPlanRepository;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

@Component
public class SubmitReviewHandler implements VisitActionHandler {
    private final VisitPlanRepository plans;
    private final VisitHandlerSupport support;
    public SubmitReviewHandler(VisitPlanRepository plans, VisitHandlerSupport support) { this.plans = plans; this.support = support; }
    public Set<String> actions() { return Collections.singleton("submit_review"); }
    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.REVIEW);
        VisitPlan plan = support.detail(support.requiredPlan(session));
        support.owner(plan, session.userId);
        plans.submitReview(plan.id, plan.version);
        return support.detail(plan.id);
    }
}
