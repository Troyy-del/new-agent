package com.locallife.visit.api;

import com.locallife.visit.service.VisitMobileFacadeService;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/visit")
public class VisitMobileFacadeController {
    private final VisitMobileFacadeService facade;

    public VisitMobileFacadeController(VisitMobileFacadeService facade) {
        this.facade = facade;
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Collections.singletonMap("status", "UP");
    }

    @GetMapping("/bootstrap")
    public Map<String, Object> bootstrap(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user) {
        return facade.bootstrap(user);
    }

    @GetMapping("/customers/search")
    public Map<String, Object> searchCustomers(
            @RequestParam(value = "q", defaultValue = "") String query,
            @RequestParam(value = "objectType", required = false) String objectType,
            @RequestParam(value = "limit", defaultValue = "8") int limit) {
        return facade.searchCustomers(query, objectType, limit);
    }

    @GetMapping("/conversations")
    public List<Map<String, Object>> conversations(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user) {
        return facade.conversations(user);
    }

    @PostMapping("/conversations")
    public Map<String, Object> createConversation(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user) {
        return facade.createConversation(user);
    }

    @GetMapping("/conversations/{id}")
    public Map<String, Object> conversation(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @PathVariable String id) {
        return facade.conversation(user, id);
    }

    @PostMapping("/create/start")
    public Map<String, Object> createStart(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody(required = false) Map<String, Object> body) {
        return facade.startCreate(user, safe(body));
    }

    @PostMapping("/create/resolve")
    public Map<String, Object> createResolve(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.resolveCreate(user, body);
    }

    @PostMapping("/create/confirm")
    public Map<String, Object> createConfirm(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.confirmCreate(user, body);
    }

    @PostMapping("/create/reset")
    public Map<String, Object> createReset(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.resetCreate(user, body);
    }

    @PostMapping("/plan/edit")
    public Map<String, Object> editPlan(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.editPlan(user, body);
    }

    @PostMapping("/checkin/start")
    public Map<String, Object> checkinStart(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody(required = false) Map<String, Object> body) {
        return facade.startCheckin(user, safe(body));
    }

    @PostMapping("/checkin/resolve")
    public Map<String, Object> checkinResolve(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.resolveCheckin(user, body);
    }

    @PostMapping("/checkin/submit")
    public Map<String, Object> checkinSubmit(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.submitCheckin(user, body);
    }

    @GetMapping("/plans")
    public List<Map<String, Object>> plans(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestParam(defaultValue = "all") String type) {
        return facade.plans(user, type);
    }

    @PostMapping("/plan/cancel")
    public Map<String, Object> cancel(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.cancelPlan(user, body);
    }

    @PostMapping("/cancel/start")
    public Map<String, Object> cancelStart(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody(required = false) Map<String, Object> body) {
        return facade.startCancel(user, safe(body));
    }

    @PostMapping("/checkout/start")
    public Map<String, Object> checkoutStart(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody(required = false) Map<String, Object> body) {
        return facade.startCheckout(user, safe(body));
    }

    @PostMapping("/checkout/precheck")
    public Map<String, Object> checkoutPrecheck(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.precheckCheckout(user, body);
    }

    @PostMapping("/checkout/submit")
    public Map<String, Object> checkoutSubmit(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.submitCheckout(user, body);
    }

    @PostMapping("/log/start")
    public Map<String, Object> logStart(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody(required = false) Map<String, Object> body) {
        return facade.startLog(user, safe(body));
    }

    @PostMapping("/log/submit")
    public Map<String, Object> logSubmit(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.submitLog(user, body);
    }

    @PostMapping("/checkout/supplement")
    public Map<String, Object> supplement(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.supplementCheckout(user, body);
    }

    @PostMapping("/recording/start")
    public Map<String, Object> recordingStart(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.startRecording(user, body);
    }

    @PostMapping("/recording/stop")
    public Map<String, Object> recordingStop(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.stopRecording(user, body);
    }

    @GetMapping("/recordings/{id}")
    public Map<String, Object> recording(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @PathVariable long id) {
        return facade.recording(user, id);
    }

    @PostMapping("/review/submit")
    public Map<String, Object> reviewSubmit(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user, @RequestBody Map<String, Object> body) {
        return facade.submitReview(user, body);
    }

    private static Map<String, Object> safe(Map<String, Object> body) {
        return body == null ? Collections.emptyMap() : body;
    }
}
