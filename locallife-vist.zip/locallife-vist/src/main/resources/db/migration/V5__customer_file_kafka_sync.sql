CREATE TABLE IF NOT EXISTS customer_file_snapshot (
    customer_id VARCHAR(128) NOT NULL PRIMARY KEY,
    content_hash CHAR(64) NOT NULL,
    payload_json JSON NOT NULL,
    updated_at DATETIME(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS customer_event_consumption (
    event_id VARCHAR(200) NOT NULL PRIMARY KEY,
    customer_id VARCHAR(128) NOT NULL,
    event_type VARCHAR(32) NOT NULL,
    event_version BIGINT NOT NULL,
    consumed_at DATETIME(6) NOT NULL,
    KEY idx_customer_event_customer_version (customer_id, event_version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
