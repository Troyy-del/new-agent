package com.locallife.visit.domain;

import java.time.Instant;

public class VisitPlan {
    public long id;
    public String creatorId;
    public String visitForm;
    public String objectType;
    public String customerId;
    public String customerName;
    public String customerType;
    public Boolean adIsTarget;
    public String purposeCode;
    public String purposeLabel;
    public Instant planTime;
    public String planAddress;
    public Double longitude;
    public Double latitude;
    public String companionsJson = "[]";
    public String travelApplyId;
    public PlanStatus status = PlanStatus.PLANNED;
    public Instant checkinTime;
    public String checkinAddress;
    public Double checkinLongitude;
    public Double checkinLatitude;
    public Instant checkoutTime;
    public String checkoutAddress;
    public Double checkoutLongitude;
    public Double checkoutLatitude;
    public String visitSummary;
    public String contactsJson;
    public boolean supplemented;
    public String checkinAbnormalReason;
    public String checkoutAbnormalReason;
    public String checkinPhotoUrl;
    public String checkoutPhotoUrl;
    public ReviewStatus reviewStatus = ReviewStatus.DRAFT;
    public String reviewerId;
    public String reviewComment;
    public Instant reviewedAt;
    public Instant archivedAt;
    public long version;
    public Instant createdAt;
    public Instant updatedAt;
}
