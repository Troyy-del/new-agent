package com.locallife.visit.api;

import com.locallife.visit.service.AliyunNlsTokenService;
import com.locallife.visit.service.AliyunOssAudioService;
import com.locallife.visit.service.VisitMobileFacadeService;
import com.locallife.visit.support.ApiResponse;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/visit/asr")
@ConditionalOnProperty(prefix = "visit.asr", name = "enabled", havingValue = "true")
public class VisitAsrController {
    private final AliyunNlsTokenService tokens;
    private final AliyunOssAudioService audio;
    private final VisitMobileFacadeService facade;

    public VisitAsrController(AliyunNlsTokenService tokens, AliyunOssAudioService audio, VisitMobileFacadeService facade) {
        this.tokens = tokens;
        this.audio = audio;
        this.facade = facade;
    }

    @GetMapping("/realtime-session")
    public Map<String, Object> realtimeSession() {
        return ApiResponse.ok(tokens.realtimeSession());
    }

    @PostMapping("/audio")
    public Map<String, Object> upload(@RequestHeader(value = "X-User-Id", defaultValue = "demo-user") String user,
                                      @RequestBody Map<String, Object> body) {
        long recordingId = Long.parseLong(String.valueOf(body.get("recordingId")));
        facade.recording(user, recordingId);
        return ApiResponse.ok(audio.upload(recordingId, text(body, "fileName"), text(body, "contentType"), text(body, "dataBase64")));
    }

    private static String text(Map<String, Object> body, String key) {
        Object value = body.get(key);
        return value == null ? null : String.valueOf(value);
    }
}
