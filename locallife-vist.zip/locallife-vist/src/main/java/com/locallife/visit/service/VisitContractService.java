package com.locallife.visit.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.locallife.visit.domain.PlanStatus;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.handler.VisitHandlerSupport;
import com.locallife.visit.repository.BusinessDirectoryRepository;
import com.locallife.visit.repository.SupportingRepository;
import com.locallife.visit.repository.VisitPlanRepository;
import com.locallife.visit.support.BizException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Compatibility layer for the concrete HTTP contracts used by visit-assistant. */
@Service
public class VisitContractService {
    private final VisitPlanRepository plans;
    private final BusinessDirectoryRepository directory;
    private final SupportingRepository supporting;
    private final ObjectMapper json;
    private final double checkoutRadius;

    public VisitContractService(VisitPlanRepository plans, BusinessDirectoryRepository directory,
                                SupportingRepository supporting, ObjectMapper json,
                                @Value("${visit.checkout-radius-meters:1000}") double checkoutRadius) {
        this.plans = plans;
        this.directory = directory;
        this.supporting = supporting;
        this.json = json;
        this.checkoutRadius = checkoutRadius;
    }

    public VisitPlan plan(long id) {
        return plans.find(id).orElseThrow(() -> new BizException("PLAN_NOT_FOUND", "拜访计划不存在", HttpStatus.NOT_FOUND));
    }

    public Map<String, Object> detail(long id) {
        VisitPlan plan = plan(id);
        Map<String, Object> result = new LinkedHashMap<>();
        Map<String, Object> basic = new LinkedHashMap<>();
        basic.put("visitType", plan.visitForm);
        basic.put("visitObject", plan.objectType);
        basic.put("businessLicense", plan.customerName);
        basic.put("businessLicenseCode", plan.customerId);
        basic.put("targetCustomerId", plan.customerId);
        basic.put("isNewCustomer", "new".equalsIgnoreCase(plan.customerType) ? "1" : "0");
        basic.put("adIsTarget", plan.adIsTarget);
        basic.put("visitPurpose", plan.purposeCode);
        basic.put("visitPurposeLabel", plan.purposeLabel);
        basic.put("visitStatus", visitStatus(plan.status));
        result.put("basicInfo", basic);

        Map<String, Object> checkin = new LinkedHashMap<>();
        checkin.put("planVisitTime", millis(plan.planTime));
        checkin.put("planVisitAddress", address(plan.planAddress, plan.longitude, plan.latitude));
        checkin.put("actualVisitTime", millis(plan.checkinTime));
        checkin.put("checkinTime", millis(plan.checkinTime));
        checkin.put("checkinAddress", address(plan.checkinAddress, plan.checkinLongitude, plan.checkinLatitude));
        checkin.put("checkoutTime", millis(plan.checkoutTime));
        checkin.put("checkoutAddress", address(plan.checkoutAddress, plan.checkoutLongitude, plan.checkoutLatitude));
        checkin.put("checkinPhotoUrl", plan.checkinPhotoUrl);
        checkin.put("checkoutPhotoUrl", plan.checkoutPhotoUrl);
        checkin.put("checkinAbnormalReason", plan.checkinAbnormalReason);
        checkin.put("checkoutAbnormalReason", plan.checkoutAbnormalReason);
        if ("store".equals(plan.objectType)) checkin.put("storePoiId", plan.customerId);
        result.put("visitCheckinInfo", checkin);

        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("visitSummary", plan.visitSummary);
        result.put("visitSummaryInfo", summary);
        result.put("visitId", String.valueOf(plan.id));
        result.put("visitPlanId", String.valueOf(plan.id));
        result.put("targetCustomerId", plan.customerId);
        result.put("targetCustomerName", plan.customerName);
        result.put("agentId", "agent".equals(plan.objectType) ? plan.customerId : null);
        result.put("agentName", "agent".equals(plan.objectType) ? plan.customerName : null);
        result.put("providerId", "provider".equals(plan.objectType) ? plan.customerId : null);
        result.put("providerName", "provider".equals(plan.objectType) ? plan.customerName : null);
        result.put("contacts", readContacts(plan.contactsJson));
        result.put("supplementAllowed", canSupplement(plan) ? 1 : 0);
        result.put("isCheckedOut", plan.status == PlanStatus.CHECKED_OUT || plan.status == PlanStatus.LOGGED ? 1 : 0);
        if (plan.travelApplyId != null) result.put("travelInfo", directory.travelApplication(plan.travelApplyId));
        return result;
    }

    public Map<String, Object> list(String user, Map<String, Object> request) {
        List<String> clock = filter(request, "clockStatus");
        List<String> visit = filter(request, "visitStatus");
        List<PlanStatus> statuses = null;
        if (clock.contains("1")) statuses = Collections.singletonList(PlanStatus.CHECKED_IN);
        else if (clock.contains("0")) statuses = Collections.singletonList(PlanStatus.PLANNED);
        else if (visit.size() == 1 && visit.contains("2")) statuses = Collections.singletonList(PlanStatus.CHECKED_OUT);

        Map<String, Object> time = map(request.get("timeCondition"));
        Instant planStart = instant(time.get("plannedVisitTimeStart"));
        Instant planEnd = instant(time.get("plannedVisitTimeEnd"));
        Instant checkinStart = instant(time.get("signInTimeStart"));
        Instant checkinEnd = instant(time.get("signInTimeEnd"));
        int limit = pageSize(request);
        List<VisitPlan> found = plans.findByFilters(user, statuses, planStart, planEnd, checkinStart, checkinEnd, limit);
        List<Map<String, Object>> list = new ArrayList<>();
        List<Map<String, Object>> rows = new ArrayList<>();
        for (VisitPlan plan : found) {
            Map<String, Object> item = listItem(plan);
            list.add(item);
            rows.add(Collections.singletonMap("data", item));
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("list", list);
        result.put("dataRow", rows);
        result.put("total", list.size());
        return result;
    }

    public Map<String, Object> pendingTravel(String user, Object param, int limit) {
        List<VisitPlan> found = plans.findByFilters(user, Collections.singletonList(PlanStatus.PENDING_SUPPLEMENT), null, null, null, null, limit);
        String keyword = param == null ? "" : String.valueOf(param).trim();
        List<Map<String, Object>> list = new ArrayList<>();
        for (VisitPlan plan : found) {
            Map<String, Object> travel = directory.travelApplication(plan.travelApplyId);
            if (!keyword.isEmpty() && travel != null && !String.valueOf(travel).contains(keyword)) continue;
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("visitId", String.valueOf(plan.id));
            item.put("visitPlanId", String.valueOf(plan.id));
            item.put("planVisitTime", plan.planTime == null ? "" : DateTimeFormatter.ISO_LOCAL_DATE.withZone(ZoneId.of("Asia/Shanghai")).format(plan.planTime));
            item.put("travelApply", write(travel == null ? Collections.emptyMap() : travel));
            list.add(item);
        }
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("total", list.size());
        payload.put("list", list);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("dataJson", write(payload));
        result.put("list", list);
        return result;
    }

    public List<Map<String, Object>> travelApplications(String user) {
        return directory.travelApplications(user);
    }

    public void saveTravelApplication(String applyNo, String user, List<?> cities, LocalDate start, LocalDate end) {
        directory.saveTravelApplication(applyNo, user, cities, start, end);
    }

    public List<Map<String, Object>> employees(String keyword, int limit) {
        return directory.employees(keyword, limit);
    }

    public List<Map<String, Object>> contacts(String objectType, String objectId) {
        return directory.contacts(objectType, objectId);
    }

    public Map<String, Object> saveContact(String objectType, String objectId, String objectName, Map<String, Object> contact) {
        if (objectType == null || objectId == null) throw new BizException("MISSING_VISIT_OBJECT", "拜访对象不能为空");
        if (text(contact.get("name")) == null) throw new BizException("MISSING_CONTACT_NAME", "联系人姓名不能为空");
        return directory.saveContact(objectType, objectId, objectName, contact);
    }

    public Map<String, Object> preCheckCheckout(Map<String, Object> request) {
        long id = longValue(first(request, "visitPlanIdStr", "visitPlanId", "visitId"));
        VisitPlan plan = plan(id);
        List<Map<String, Object>> abnormal = new ArrayList<>();
        if (plan.status != PlanStatus.CHECKED_IN) {
            abnormal.add(abnormal("invalid_status", "当前状态不可签退", "只有已签到未签退的拜访可以签退。"));
        } else {
            Double longitude = number(request.get("longitude"));
            Double latitude = number(request.get("latitude"));
            if (longitude == null || latitude == null) {
                abnormal.add(abnormal("checkout_location_required", "缺少当前位置", "签退需要提供经纬度。"));
            } else if (plan.checkinLongitude != null && plan.checkinLatitude != null &&
                    VisitHandlerSupport.distance(latitude, longitude, plan.checkinLatitude, plan.checkinLongitude) > checkoutRadius) {
                abnormal.add(abnormal("checkout_distance_abnormal", "超出签退范围", "超出签到地1km范围则无法签退。"));
            }
            if (plan.checkinTime != null && Instant.now().isAfter(checkoutDeadline(plan.checkinTime))) {
                abnormal.add(abnormal("checkout_expired", "已超出可签退时间", "仅可在签到时间的第二天上午6:00前完成签退。"));
            }
        }
        List<String> tags = new ArrayList<>();
        for (Map<String, Object> item : abnormal) tags.add(String.valueOf(item.get("abnormalType")));
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("canCheckout", abnormal.isEmpty());
        result.put("hasAbnormal", !abnormal.isEmpty());
        result.put("abnormalList", abnormal);
        result.put("abnormalTags", tags);
        result.put("abnormalReason", abnormal.isEmpty() ? "" : String.valueOf(abnormal.get(0).get("title")));
        return result;
    }

    @Transactional
    public Map<String, Object> submitCheckout(Map<String, Object> request) {
        Map<String, Object> check = preCheckCheckout(request);
        if (!Boolean.TRUE.equals(check.get("canCheckout"))) throw new BizException("CHECKOUT_PRECHECK_FAILED", String.valueOf(check.get("abnormalReason")), HttpStatus.CONFLICT);
        long id = longValue(first(request, "visitPlanIdStr", "visitPlanId", "visitId"));
        VisitPlan plan = plan(id);
        plans.markStatus(id, plan.version, PlanStatus.CHECKED_IN, PlanStatus.CHECKED_OUT,
                text(first(request, "address", "currentAddress")), number(request.get("longitude")), number(request.get("latitude")));
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("success", true);
        result.put("visitPlanId", String.valueOf(id));
        result.put("message", "签退成功，别忘了填写拜访日志！");
        return result;
    }

    public Map<String, Object> supplementAllowed(long id) {
        VisitPlan plan = plan(id);
        boolean allowed = canSupplement(plan);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("allowed", allowed);
        result.put("message", allowed ? "可以补录签退" : "当前计划不可补录签退");
        return result;
    }

    @Transactional
    public Map<String, Object> supplementCheckout(long id) {
        VisitPlan plan = plan(id);
        if (!canSupplement(plan)) throw new BizException("SUPPLEMENT_NOT_ALLOWED", "当前计划不可补录签退", HttpStatus.CONFLICT);
        String address = plan.checkinAddress == null ? plan.planAddress : plan.checkinAddress;
        plans.supplementCheckout(id, plan.version, address);
        VisitPlan updated = plan(id);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("success", true);
        result.put("checkoutTime", millis(updated.checkoutTime));
        result.put("checkoutAddress", updated.checkoutAddress);
        return result;
    }

    @Transactional
    public Map<String, Object> fillLog(Map<String, Object> request) {
        long id = longValue(first(request, "visitId", "visitPlanId", "id"));
        VisitPlan plan = plan(id);
        if (plan.status != PlanStatus.CHECKED_OUT && plan.status != PlanStatus.LOGGED)
            throw new BizException("INVALID_FSM_TRANSITION", "仅已签退计划可填写或修改日志", HttpStatus.CONFLICT);
        String summary = text(request.get("visitSummary"));
        if (summary == null || summary.trim().isEmpty()) throw new BizException("MISSING_VISIT_SUMMARY", "拜访纪要不能为空");
        Object contactsValue = request.get("contacts");
        Map<String, Object> contactsObject = map(contactsValue);
        List<Map<String, Object>> phone = contactsValue instanceof List ? listOfMaps(contactsValue) : listOfMaps(contactsObject.get("contact"));
        List<Map<String, Object>> wechat = listOfMaps(contactsObject.get("wechatContact"));
        if (phone.isEmpty() && wechat.isEmpty()) throw new BizException("MISSING_CONTACTS", "至少需要一个联系人");
        List<Map<String, Object>> resolved = new ArrayList<>();
        for (Map<String, Object> contact : phone) {
            if (contact.get("id") == null || String.valueOf(contact.get("id")).trim().isEmpty())
                resolved.add(directory.saveContact(plan.objectType, plan.customerId, plan.customerName, contact));
            else resolved.add(contact);
        }
        Map<String, Object> snapshots = new LinkedHashMap<>();
        snapshots.put("contact", resolved);
        snapshots.put("wechatContact", wechat);
        plans.saveLog(id, plan.version, summary, write(snapshots));
        directory.replaceContactSnapshots(id, resolved, wechat);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("success", true);
        result.put("visitId", String.valueOf(id));
        return result;
    }

    public Map<String, Object> llmStatus(long planId) {
        Map<String, Object> recording = latestRecording(planId);
        int status = recording == null ? 0 : (recording.get("summary") == null ? 1 : 2);
        return Collections.singletonMap("llmStatus", status);
    }

    public Map<String, Object> audioDetail(long planId) {
        Map<String, Object> recording = latestRecording(planId);
        if (recording == null) throw new BizException("RECORDING_NOT_FOUND", "该拜访暂无录音", HttpStatus.NOT_FOUND);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("cdnUrl", recording.get("audioUrl"));
        result.put("llmSummary", recording.get("summary"));
        result.put("transcript", recording.get("transcript"));
        return result;
    }

    public long createPendingTravel(String user, String applyNo, Instant planTime) {
        if (directory.travelApplication(applyNo) == null) throw new BizException("TRAVEL_APPLICATION_NOT_FOUND", "差旅申请不存在", HttpStatus.NOT_FOUND);
        VisitPlan plan = new VisitPlan();
        plan.id = SupportingRepository.newId();
        plan.creatorId = user;
        plan.visitForm = "travel";
        plan.travelApplyId = applyNo;
        plan.planTime = planTime;
        plan.status = PlanStatus.PENDING_SUPPLEMENT;
        plan.createdAt = Instant.now();
        plan.updatedAt = plan.createdAt;
        plans.insertPendingTravel(plan);
        return plan.id;
    }

    private Map<String, Object> latestRecording(long planId) {
        return supporting.latestRecordingByPlan(planId);
    }

    private Map<String, Object> listItem(VisitPlan plan) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("visitId", String.valueOf(plan.id));
        item.put("visitPlanId", String.valueOf(plan.id));
        item.put("businessLicense", plan.customerName);
        item.put("businessLicenseName", plan.customerName);
        item.put("visitObject", plan.objectType);
        item.put("visitType", plan.visitForm);
        item.put("visitStatus", visitStatus(plan.status));
        item.put("clockStatus", clockStatus(plan.status));
        item.put("planVisitTime", plan.planTime == null ? "" : String.valueOf(millis(plan.planTime)));
        item.put("actualVisitTime", plan.checkinTime == null ? "" : String.valueOf(millis(plan.checkinTime)));
        item.put("planVisitAddress", plan.planAddress);
        item.put("actualVisitAddress", address(plan.checkinAddress, plan.checkinLongitude, plan.checkinLatitude));
        item.put("operations", operations(plan.status));
        return item;
    }

    private boolean canSupplement(VisitPlan plan) { return plan.status == PlanStatus.CHECKED_IN && plan.checkoutTime == null; }

    private static Instant checkoutDeadline(Instant checkin) {
        ZonedDateTime local = checkin.atZone(ZoneId.of("Asia/Shanghai"));
        return local.toLocalDate().plusDays(1).atTime(6, 0).atZone(local.getZone()).toInstant();
    }

    private static Map<String, Object> abnormal(String type, String title, String content) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("abnormalType", type); item.put("title", title); item.put("content", content); item.put("buttons", Collections.singletonList("好的"));
        return item;
    }

    private static List<String> operations(PlanStatus status) {
        if (status == PlanStatus.PLANNED) return Arrays.asList("cancel_visit", "checkin");
        if (status == PlanStatus.CHECKED_IN) return Arrays.asList("checkout", "record");
        if (status == PlanStatus.CHECKED_OUT) return Collections.singletonList("fill_log");
        if (status == PlanStatus.LOGGED) return Collections.singletonList("edit_log");
        return Collections.emptyList();
    }

    private static String clockStatus(PlanStatus status) {
        if (status == PlanStatus.PLANNED) return "0";
        if (status == PlanStatus.CHECKED_IN) return "1";
        if (status == PlanStatus.CHECKED_OUT || status == PlanStatus.LOGGED) return "2";
        return "-1";
    }

    private static String visitStatus(PlanStatus status) {
        if (status == PlanStatus.PENDING_SUPPLEMENT) return "1";
        if (status == PlanStatus.CHECKED_OUT) return "2";
        if (status == PlanStatus.LOGGED) return "3";
        if (status == PlanStatus.CANCELED) return "5";
        return "4";
    }

    private Map<String, Object> readContacts(String value) {
        if (value == null) { Map<String, Object> empty = new LinkedHashMap<>(); empty.put("contact", Collections.emptyList()); empty.put("wechatContact", Collections.emptyList()); return empty; }
        try { return json.readValue(value, new TypeReference<Map<String, Object>>() { }); }
        catch (Exception e) { return Collections.emptyMap(); }
    }

    private String write(Object value) {
        try { return json.writeValueAsString(value); }
        catch (Exception e) { throw new BizException("INVALID_JSON", "JSON 序列化失败"); }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Object value) { return value instanceof Map ? (Map<String, Object>) value : new LinkedHashMap<>(); }
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> listOfMaps(Object value) { return value instanceof List ? (List<Map<String, Object>>) value : Collections.emptyList(); }
    private static List<String> filter(Map<String, Object> request, String key) {
        Object value = request.get("filterCondition");
        if (!(value instanceof List)) return Collections.emptyList();
        for (Object item : (List<?>) value) if (item instanceof Map && key.equals(String.valueOf(((Map<?, ?>) item).get("key")))) {
            Object values = ((Map<?, ?>) item).get("value");
            if (values instanceof List) { List<String> result = new ArrayList<>(); for (Object v : (List<?>) values) result.add(String.valueOf(v)); return result; }
        }
        return Collections.emptyList();
    }
    private static int pageSize(Map<String, Object> request) {
        Map<String, Object> page = map(request.get("pageInfo"));
        Object value = first(page, "pageSize", "limit");
        try { return value == null ? 20 : Integer.parseInt(String.valueOf(value)); } catch (Exception e) { return 20; }
    }
    private static Object first(Map<?, ?> map, String... keys) { for (String key : keys) if (map.get(key) != null) return map.get(key); return null; }
    private static String text(Object value) { return value == null ? null : String.valueOf(value); }
    private static long longValue(Object value) { if (value == null) throw new BizException("MISSING_ID", "拜访计划ID不能为空"); try { return Long.parseLong(String.valueOf(value)); } catch (Exception e) { throw new BizException("INVALID_ID", "拜访计划ID格式错误"); } }
    private static Double number(Object value) { if (value instanceof Number) return ((Number) value).doubleValue(); try { return value == null ? null : Double.valueOf(String.valueOf(value)); } catch (Exception e) { return null; } }
    private static Instant instant(Object value) { if (value instanceof Number) return Instant.ofEpochMilli(((Number) value).longValue()); try { return value == null ? null : Instant.ofEpochMilli(Long.parseLong(String.valueOf(value))); } catch (Exception e) { return null; } }
    private static Long millis(Instant value) { return value == null ? null : value.toEpochMilli(); }
    private static Map<String, Object> address(String text, Double longitude, Double latitude) { Map<String, Object> result = new LinkedHashMap<>(); result.put("address", text); result.put("longitude", longitude); result.put("latitude", latitude); return result; }
}
