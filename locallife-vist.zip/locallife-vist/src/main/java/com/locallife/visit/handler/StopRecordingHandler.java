package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.repository.SupportingRepository;
import com.locallife.visit.service.RecordingPipelineService;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

@Component
public class StopRecordingHandler implements VisitActionHandler {
    private final SupportingRepository supporting;
    private final VisitHandlerSupport support;
    private final RecordingPipelineService pipeline;

    public StopRecordingHandler(SupportingRepository supporting, VisitHandlerSupport support, RecordingPipelineService pipeline) { this.supporting = supporting; this.support = support; this.pipeline = pipeline; }
    public Set<String> actions() { return Collections.singleton("stop_recording"); }
    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.RECORD);
        long recordingId = VisitHandlerSupport.longValue(params.get("recordingId"), "recordingId");
        Map<String,Object> recording=supporting.recording(recordingId);
        if(recording==null) throw new com.locallife.visit.support.BizException("RECORDING_NOT_FOUND","录音任务不存在");
        com.locallife.visit.domain.VisitPlan plan=support.detail(((Number)recording.get("visitPlanId")).longValue());
        support.owner(plan,session.userId);
        pipeline.finish(recordingId,session.userId,VisitHandlerSupport.text(params,"audioUrl"),VisitHandlerSupport.text(params,"transcript"));
        return supporting.recording(recordingId);
    }
}
