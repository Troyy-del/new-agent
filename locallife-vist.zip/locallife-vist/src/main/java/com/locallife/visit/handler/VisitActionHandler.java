package com.locallife.visit.handler;

import com.locallife.visit.domain.BizSession;

import java.util.Map;
import java.util.Set;

/** One independently testable business action in the visit workflow. */
public interface VisitActionHandler {
    Set<String> actions();

    Object handle(BizSession session, Map<String, Object> params);
}
