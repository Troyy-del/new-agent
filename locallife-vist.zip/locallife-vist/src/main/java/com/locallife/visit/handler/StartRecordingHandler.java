package com.locallife.visit.handler;

import com.locallife.visit.domain.ActiveSkill;
import com.locallife.visit.domain.BizSession;
import com.locallife.visit.domain.PlanStatus;
import com.locallife.visit.domain.VisitPlan;
import com.locallife.visit.repository.SupportingRepository;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

@Component
public class StartRecordingHandler implements VisitActionHandler {
    private final SupportingRepository supporting;
    private final VisitHandlerSupport support;

    public StartRecordingHandler(SupportingRepository supporting, VisitHandlerSupport support) { this.supporting = supporting; this.support = support; }
    public Set<String> actions() { return Collections.singleton("start_recording"); }
    public Object handle(BizSession session, Map<String, Object> params) {
        support.requireSkill(session, ActiveSkill.RECORD);
        VisitPlan plan = support.detail(support.requiredPlan(session));
        support.owner(plan, session.userId);
        if (plan.status != PlanStatus.CHECKED_IN) throw VisitHandlerSupport.transition("仅签到后、签退前可开始录音");
        long recordingId = supporting.insertRecording(plan.id);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("recordingId", recordingId);
        result.put("status", "RECORDING");
        return result;
    }
}
