#!/bin/sh
set -eu

keychain_account="locallife-visit-asr"
export ALIYUN_AK_ID="$(security find-generic-password -a "$keychain_account" -s locallife-visit-asr-access-key-id -w)"
export ALIYUN_AK_SECRET="$(security find-generic-password -a "$keychain_account" -s locallife-visit-asr-access-key-secret -w)"
export NLS_APP_KEY="PrROtQNSRB8d3Akw"
export ALIYUN_ASR_ENABLED="true"
export ALIYUN_ASR_REGION="cn-beijing"
export ALIYUN_FILETRANS_DOMAIN="filetrans.cn-beijing.aliyuncs.com"
export ALIYUN_OSS_ENDPOINT="https://oss-cn-beijing.aliyuncs.com"
export ALIYUN_OSS_BUCKET="lzf-fzx"

exec mvn spring-boot:run
