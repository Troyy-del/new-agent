package com.locallife.visit.service;

import com.locallife.visit.integration.CustomerVectorHit;
import com.locallife.visit.integration.MilvusCustomerVectorStore;
import com.locallife.visit.integration.MilvusEmbeddingClient;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CustomerSearchService {
    private final ObjectProvider<MilvusEmbeddingClient> embeddings;
    private final ObjectProvider<MilvusCustomerVectorStore> vectors;

    public CustomerSearchService(ObjectProvider<MilvusEmbeddingClient> embeddings,
                                 ObjectProvider<MilvusCustomerVectorStore> vectors) {
        this.embeddings = embeddings;
        this.vectors = vectors;
    }

    public List<Map<String, Object>> search(String query, String type, int limit) {
        // at least 1
        int actualLimit = Math.max(1, Math.min(limit, 100));
        MilvusEmbeddingClient embedding = embeddings.getIfAvailable();
        MilvusCustomerVectorStore vectorStore = vectors.getIfAvailable();
        if (vectorStore == null) return Collections.emptyList();
        List<CustomerVectorHit> hits = query == null || query.trim().isEmpty()
                ? vectorStore.list(type, actualLimit)
                : vectorStore.search(embedding.embed(query), type, actualLimit);
        List<Map<String, Object>> result = new ArrayList<>();
        for (CustomerVectorHit hit : hits) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", hit.customerId); item.put("objectType", hit.objectType); item.put("name", hit.standardName);
            item.put("address", hit.address); item.put("city", hit.city);
            if (query != null && !query.trim().isEmpty()) item.put("similarity", hit.score);
            result.add(item);
        }
        return result;
    }
}
