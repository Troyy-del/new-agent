package com.locallife.visit.domain;

public enum ReviewStatus {
    DRAFT, PENDING, APPROVED, REJECTED, ARCHIVED
}
